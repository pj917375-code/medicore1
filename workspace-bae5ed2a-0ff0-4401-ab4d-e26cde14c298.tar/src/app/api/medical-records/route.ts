import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, buildWhere, parseBody, handler } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { medicalRecordSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit, notify } from '@/lib/services'
import { z } from 'zod'

const recCreateSchema = medicalRecordSchema.extend({ appointmentId: z.string().optional() })

/** GET /api/medical-records — EMR list. Patients see only their own records. */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['patientId', 'doctorId', 'visitType'].includes(k)) filters[k] = v
  }
  let extra: Record<string, unknown> = {}
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    extra = { patientId: patient?.id || 'none' }
  }
  const where = buildWhere(['diagnosis', 'symptoms'], q.search, filters, extra)
  const [total, rows] = await Promise.all([
    db.medicalRecord.count({ where }),
    db.medicalRecord.findMany({
      where, orderBy: { createdAt: 'desc' },
      include: {
        patient: { select: { id: true, firstName: true, lastName: true, code: true } },
        doctor: { include: { user: { select: { name: true } } } },
        prescriptions: { select: { id: true, code: true, status: true } },
      },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})

/** POST /api/medical-records — doctor adds consultation record. */
export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES['medical-records'] as any)
  const data = await parseBody(req, recCreateSchema)
  const rec = await db.medicalRecord.create({
    data: {
      patientId: data.patientId, doctorId: data.doctorId,
      appointmentId: data.appointmentId || null,
      visitType: data.visitType, symptoms: data.symptoms, diagnosis: data.diagnosis,
      treatmentPlan: data.treatmentPlan, clinicalNotes: data.clinicalNotes,
      bloodPressure: data.bloodPressure, heartRate: data.heartRate,
      temperature: data.temperature, weight: data.weight,
      followUpDate: data.followUpDate || null,
    },
    include: {
      patient: { select: { firstName: true, lastName: true, code: true } },
      doctor: { include: { user: { select: { name: true } } } },
    },
  })
  if (data.appointmentId) {
    await db.appointment.update({ where: { id: data.appointmentId }, data: { status: 'COMPLETED' } }).catch(() => {})
  }
  await audit(req, session, 'CREATE', 'MedicalRecord', rec.id, `Diagnosis: ${data.diagnosis}`)
  await notify({
    userId: (await db.patient.findUnique({ where: { id: data.patientId } }))?.userId || undefined,
    title: 'New medical record',
    message: `A consultation record was added to your medical file (Diagnosis: ${data.diagnosis}).`,
    type: 'SYSTEM',
  })
  return ok(rec, undefined, 201)
})
