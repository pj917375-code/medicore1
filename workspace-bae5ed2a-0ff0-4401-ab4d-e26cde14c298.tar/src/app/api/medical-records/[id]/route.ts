import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers, withId } from '@/lib/crud'
import { medicalRecordUpdateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'

const handlers = createCrudHandlers({
  delegate: db.medicalRecord,
  resource: 'MedicalRecord',
  searchFields: ['diagnosis', 'symptoms'],
  include: {
    patient: { select: { id: true, firstName: true, lastName: true, code: true } },
    doctor: { include: { user: { select: { name: true } } } },
    prescriptions: true,
  },
  writeRoles: WRITE_ROLES['medical-records'] as any,
  updateSchema: medicalRecordUpdateSchema,
})

export const GET = withId(handlers).GET
export const PUT = withId(handlers).PUT
export const DELETE = withId(handlers).DELETE
