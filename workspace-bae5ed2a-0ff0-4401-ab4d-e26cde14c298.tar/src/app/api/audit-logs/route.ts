import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, buildWhere, handler } from '@/lib/api'
import { requireAuth } from '@/lib/auth'

/** GET /api/audit-logs — security audit trail (admins only). */
export const GET = handler(async (req: NextRequest) => {
  requireAuth(req, ['SUPER_ADMIN', 'ADMIN'])
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['action', 'entity'].includes(k)) filters[k] = v
  }
  const where = buildWhere(['userName', 'details'], q.search, filters)
  const [total, rows] = await Promise.all([
    db.auditLog.count({ where }),
    db.auditLog.findMany({
      where, orderBy: { createdAt: 'desc' },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})
