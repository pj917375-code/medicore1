import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, buildWhere, handler } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { z } from 'zod'
import { parseBody } from '@/lib/api'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'
import { ApiError } from '@/lib/api'

const doctorCreateSchema = z.object({
  email: z.string().trim().email(),
  name: z.string().trim().min(2).max(80),
  password: z.string().min(8).max(100).optional(),
  specialization: z.string().min(2).max(100),
  qualification: z.string().min(2).max(200),
  licenseNo: z.string().min(2).max(50),
  experienceYears: z.coerce.number().min(0).max(80),
  consultationFee: z.coerce.number().min(0),
  departmentId: z.string().min(1),
  availability: z.string().optional(),
  shiftTime: z.string().optional(),
})

/** GET /api/doctors — list + search. Also allows patients to browse. */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['status', 'departmentId', 'specialization'].includes(k)) filters[k] = v
  }
  const where = buildWhere(['code', 'specialization', 'qualification'], q.search, filters)
  // Patients only see active doctors
  if (session.role === 'PATIENT') (where as any).status = 'ACTIVE'
  const [total, rows] = await Promise.all([
    db.doctor.count({ where }),
    db.doctor.findMany({
      where, orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { name: true, email: true, phone: true, isActive: true } },
        department: true,
        _count: { select: { appointments: true } },
      },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})

/** POST /api/doctors — creates user account + doctor profile atomically. */
export const POST = handler(async (req: NextRequest) => {
  requireAuth(req, WRITE_ROLES.doctors as any)
  const data = await parseBody(req, doctorCreateSchema)
  const existing = await db.user.findUnique({ where: { email: data.email.toLowerCase() } })
  if (existing) throw new ApiError(409, 'A user with this email already exists')
  const count = await db.doctor.count()
  const result = await db.$transaction(async (tx) => {
    const user = await tx.user.create({
      data: {
        email: data.email.toLowerCase(), name: data.name, role: 'DOCTOR',
        passwordHash: await import('bcryptjs').then((b) => b.hash(data.password || 'Doctor@123', 10)),
        phone: null,
      },
    })
    return tx.doctor.create({
      data: {
        userId: user.id, code: `D-${String(1001 + count)}`,
        specialization: data.specialization, qualification: data.qualification,
        licenseNo: data.licenseNo, experienceYears: data.experienceYears,
        consultationFee: data.consultationFee, departmentId: data.departmentId,
        availability: data.availability || 'Mon,Tue,Wed,Thu,Fri',
        shiftTime: data.shiftTime || '09:00-17:00',
      },
      include: { user: { select: { name: true, email: true } }, department: true },
    })
  })
  await audit(req, null, 'CREATE', 'Doctor', result.id, `${data.name} (${data.specialization})`)
  return ok(result, undefined, 201)
})
