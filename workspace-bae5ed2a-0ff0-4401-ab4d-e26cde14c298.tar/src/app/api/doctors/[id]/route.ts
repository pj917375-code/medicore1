import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers, withId } from '@/lib/crud'
import { doctorUpdateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'

const handlers = createCrudHandlers({
  delegate: db.doctor,
  resource: 'Doctor',
  searchFields: ['code', 'specialization'],
  include: {
    user: { select: { name: true, email: true, phone: true, isActive: true } },
    department: true,
    appointments: { orderBy: { scheduledAt: 'desc' }, take: 10, include: { patient: { select: { firstName: true, lastName: true, code: true } } } },
  },
  writeRoles: WRITE_ROLES.doctors as any,
  updateSchema: doctorUpdateSchema,
})

export const GET = withId(handlers).GET
export const PUT = withId(handlers).PUT
export const DELETE = withId(handlers).DELETE
