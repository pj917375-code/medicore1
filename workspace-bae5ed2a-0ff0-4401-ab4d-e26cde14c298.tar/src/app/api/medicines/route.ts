import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers } from '@/lib/crud'
import { medicineSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { notify } from '@/lib/services'

const handlers = createCrudHandlers({
  delegate: db.medicine,
  resource: 'Medicine',
  searchFields: ['name', 'category', 'manufacturer', 'batchNo'],
  filterFields: ['category'],
  readRoles: undefined, // any signed-in staff can view inventory
  writeRoles: WRITE_ROLES.medicines as any,
  createSchema: medicineSchema,
  updateSchema: medicineSchema.partial(),
  afterUpdate: async (row: any) => {
    if (row.stockQty <= row.reorderLevel) {
      await notify({
        targetRoles: ['PHARMACIST', 'ADMIN'],
        title: 'Low stock alert',
        message: `${row.name} stock is low (${row.stockQty}/${row.reorderLevel} reorder level).`,
        type: 'PRESCRIPTION',
      })
    }
  },
})

export const GET = handlers.GET_list
export const POST = handlers.POST
