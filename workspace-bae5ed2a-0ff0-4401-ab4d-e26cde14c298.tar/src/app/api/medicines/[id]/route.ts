import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers, withId } from '@/lib/crud'
import { medicineUpdateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'

const handlers = createCrudHandlers({
  delegate: db.medicine,
  resource: 'Medicine',
  searchFields: ['name'],
  writeRoles: WRITE_ROLES.medicines as any,
  updateSchema: medicineUpdateSchema,
})

export const GET = withId(handlers).GET
export const PUT = withId(handlers).PUT
export const DELETE = withId(handlers).DELETE
