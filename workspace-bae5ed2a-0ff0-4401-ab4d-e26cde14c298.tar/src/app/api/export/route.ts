import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, handler } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { audit } from '@/lib/services'

const csvEscape = (v: unknown) => {
  const s = String(v ?? '')
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
}
const toCsv = (rows: Record<string, unknown>[]) => {
  if (!rows.length) return 'No data'
  const headers = Object.keys(rows[0])
  return [headers.join(','), ...rows.map((r) => headers.map((h) => csvEscape(r[h])).join(','))].join('\n')
}

/**
 * GET /api/export?type=patients|appointments|invoices|payments|medicines|lab-tests
 * — CSV export for reports module.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req, ['SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'RECEPTIONIST'] as any)
  const type = new URL(req.url).searchParams.get('type') || 'patients'
  let rows: Record<string, unknown>[] = []

  switch (type) {
    case 'patients':
      rows = (await db.patient.findMany()).map((p: any) => ({
        Code: p.code, Name: `${p.firstName} ${p.lastName}`, Gender: p.gender, DOB: p.dob?.toISOString()?.slice(0, 10), BloodGroup: p.bloodGroup, Phone: p.phone, Email: p.email, Status: p.status, CreatedAt: p.createdAt.toISOString().slice(0, 10),
      }))
      break
    case 'appointments':
      rows = (await db.appointment.findMany({ include: { patient: true, doctor: { include: { user: true } } } })).map((a: any) => ({
        Code: a.code, Patient: `${a.patient.firstName} ${a.patient.lastName}`, Doctor: a.doctor.user.name, ScheduledAt: a.scheduledAt.toISOString(), Status: a.status, Reason: a.reason,
      }))
      break
    case 'invoices':
      rows = (await db.invoice.findMany({ include: { patient: true } })).map((i: any) => ({
        InvoiceNo: i.invoiceNo, Patient: `${i.patient.firstName} ${i.patient.lastName}`, Subtotal: i.subtotal, Tax: i.tax, Total: i.total, AmountPaid: i.amountPaid, Status: i.status, CreatedAt: i.createdAt.toISOString().slice(0, 10),
      }))
      break
    case 'payments':
      rows = (await db.payment.findMany({ include: { invoice: { include: { patient: true } } } })).map((p: any) => ({
        Reference: p.reference, Invoice: p.invoice.invoiceNo, Patient: `${p.invoice.patient.firstName} ${p.invoice.patient.lastName}`, Amount: p.amount, Method: p.method, PaidAt: p.paidAt.toISOString().slice(0, 10), ReceivedBy: p.receivedBy,
      }))
      break
    case 'medicines':
      rows = (await db.medicine.findMany()).map((m: any) => ({
        Name: m.name, Category: m.category, Manufacturer: m.manufacturer, UnitPrice: m.unitPrice, Stock: m.stockQty, ReorderLevel: m.reorderLevel, BatchNo: m.batchNo, ExpiryDate: m.expiryDate?.toISOString()?.slice(0, 10),
      }))
      break
    case 'lab-tests':
      rows = (await db.labTest.findMany({ include: { patient: true, doctor: { include: { user: true } } } })).map((l: any) => ({
        Code: l.code, Patient: `${l.patient.firstName} ${l.patient.lastName}`, Test: l.testName, Category: l.category, Priority: l.priority, Status: l.status, RequestedBy: l.doctor.user.name, RequestedAt: l.requestedAt.toISOString().slice(0, 10),
      }))
      break
    default:
      return Response.json({ success: false, error: { message: 'Unknown export type' } }, { status: 400 })
  }
  await audit(req, session, 'EXPORT', type, undefined, `Exported ${rows.length} rows`)
  const csv = toCsv(rows)
  return new Response(csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="medicore-${type}-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  })
})
