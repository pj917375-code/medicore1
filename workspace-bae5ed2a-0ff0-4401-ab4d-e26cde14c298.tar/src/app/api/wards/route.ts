import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, handler } from '@/lib/api'
import { requireAuth } from '@/lib/auth'

/** GET /api/wards — wards with bed counts and occupancy. */
export const GET = handler(async (req: NextRequest) => {
  requireAuth(req)
  const q = parseQuery(req.url)
  const wards = await db.ward.findMany({
    orderBy: { name: 'asc' },
    include: { beds: { orderBy: { bedNumber: 'asc' } } },
  })
  const shaped = wards.map((w) => {
    const occupied = w.beds.filter((b) => b.status === 'OCCUPIED').length
    return {
      ...w,
      totalBeds: w.beds.length,
      occupiedBeds: occupied,
      availableBeds: w.beds.filter((b) => b.status === 'AVAILABLE').length,
      occupancyRate: w.beds.length ? Math.round((occupied / w.beds.length) * 100) : 0,
    }
  })
  const filtered = q.filters.type ? shaped.filter((w) => w.type === q.filters.type) : shaped
  return ok(filtered, { total: filtered.length })
})
