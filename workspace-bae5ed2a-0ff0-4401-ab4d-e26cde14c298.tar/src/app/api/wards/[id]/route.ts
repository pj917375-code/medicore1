import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { wardSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'
import { z } from 'zod'

export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES.wards as any)
  const data = await parseBody(req, wardSchema)
  const ward = await db.ward.create({ data })
  await audit(req, session, 'CREATE', 'Ward', ward.id, ward.name)
  return ok(ward, undefined, 201)
})

export const GET = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  requireAuth(req)
  const ward = await db.ward.findUnique({ where: { id }, include: { beds: { orderBy: { bedNumber: 'asc' } } } })
  if (!ward) throw new ApiError(404, 'Ward not found')
  return ok(ward)
})

export const PUT = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.wards as any)
  const data = await parseBody(req, wardSchema.partial())
  const ward = await db.ward.update({ where: { id }, data })
  await audit(req, session, 'UPDATE', 'Ward', id)
  return ok(ward)
})

export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.wards as any)
  const beds = await db.bed.count({ where: { wardId: id, status: 'OCCUPIED' } })
  if (beds > 0) throw new ApiError(400, 'Cannot delete a ward with occupied beds')
  await db.ward.delete({ where: { id } })
  await audit(req, session, 'DELETE', 'Ward', id)
  return ok({ id })
})
