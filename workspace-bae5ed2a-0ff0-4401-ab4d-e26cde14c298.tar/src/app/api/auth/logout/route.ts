import { NextRequest } from 'next/server'
import { handler, ok } from '@/lib/api'
import { clearAuthCookie, getSession } from '@/lib/auth'
import { audit } from '@/lib/services'

export const POST = handler(async (req: NextRequest) => {
  const session = getSession(req)
  if (session) await audit(req, session, 'LOGOUT', 'Auth', session.userId)
  const res = ok({ message: 'Signed out successfully' })
  clearAuthCookie(res)
  return res
})
