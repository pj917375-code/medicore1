import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handler, ok, parseBody } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { profileSchema } from '@/lib/schemas'

export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const user = await db.user.findUnique({
    where: { id: session.userId },
    select: { id: true, email: true, name: true, role: true, phone: true, avatarColor: true, createdAt: true, lastLoginAt: true },
  })
  return ok(user)
})

export const PUT = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const data = await parseBody(req, profileSchema)
  const user = await db.user.update({
    where: { id: session.userId },
    data: { name: data.name, phone: data.phone || null, avatarColor: data.avatarColor || undefined },
    select: { id: true, email: true, name: true, role: true, phone: true, avatarColor: true },
  })
  return ok(user)
})
