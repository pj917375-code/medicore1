import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handler, ok, parseBody, ApiError } from '@/lib/api'
import { requireAuth, verifyPassword, hashPassword } from '@/lib/auth'
import { changePasswordSchema } from '@/lib/schemas'
import { audit } from '@/lib/services'

export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const { currentPassword, newPassword } = await parseBody(req, changePasswordSchema)
  const user = await db.user.findUnique({ where: { id: session.userId } })
  if (!user || !(await verifyPassword(currentPassword, user.passwordHash))) {
    throw new ApiError(400, 'Current password is incorrect')
  }
  await db.user.update({ where: { id: session.userId }, data: { passwordHash: await hashPassword(newPassword) } })
  await audit(req, session, 'UPDATE', 'Auth', session.userId, 'Password changed')
  return ok({ message: 'Password updated successfully' })
})
