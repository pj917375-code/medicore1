import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handler, ok, parseBody, ApiError, rateLimit } from '@/lib/api'
import { loginSchema } from '@/lib/schemas'
import { verifyPassword, signToken, setAuthCookie } from '@/lib/auth'
import { audit } from '@/lib/services'

export const POST = handler(async (req: NextRequest) => {
  rateLimit(req, 'login', 20, 60_000) // brute-force protection
  const { email, password } = await parseBody(req, loginSchema)
  const user = await db.user.findUnique({ where: { email: email.toLowerCase() } })
  if (!user || !(await verifyPassword(password, user.passwordHash))) {
    throw new ApiError(401, 'Invalid email or password')
  }
  if (!user.isActive) throw new ApiError(403, 'This account has been deactivated')

  const session = { userId: user.id, email: user.email, name: user.name, role: user.role as any }
  const token = signToken(session)
  await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } })
  await audit(req, session, 'LOGIN', 'Auth', user.id, `${user.name} signed in`)

  const res = ok({ token, user: { ...session, phone: user.phone, avatarColor: user.avatarColor } })
  setAuthCookie(res, token)
  return res
})
