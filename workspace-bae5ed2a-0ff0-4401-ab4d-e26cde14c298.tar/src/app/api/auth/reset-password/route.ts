import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handler, ok, parseBody, ApiError, rateLimit } from '@/lib/api'
import { hashPassword } from '@/lib/auth'
import { resetSchema } from '@/lib/schemas'
import { audit } from '@/lib/services'

export const POST = handler(async (req: NextRequest) => {
  rateLimit(req, 'reset', 10, 60_000)
  const { token, password } = await parseBody(req, resetSchema)
  const rec = await db.passwordResetToken.findUnique({ where: { token }, include: { user: true } })
  if (!rec || rec.usedAt || rec.expiresAt < new Date()) {
    throw new ApiError(400, 'This reset link is invalid or has expired')
  }
  await db.user.update({ where: { id: rec.userId }, data: { passwordHash: await hashPassword(password) } })
  await db.passwordResetToken.update({ where: { id: rec.id }, data: { usedAt: new Date() } })
  await audit(req, { userId: rec.userId, name: rec.user.name, role: rec.user.role, email: rec.user.email } as any, 'UPDATE', 'Auth', rec.userId, 'Password reset via token')
  return ok({ message: 'Password has been reset. You can now sign in.' })
})
