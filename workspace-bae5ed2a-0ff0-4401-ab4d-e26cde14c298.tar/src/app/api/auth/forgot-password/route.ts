import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handler, ok, parseBody, rateLimit } from '@/lib/api'
import { forgotSchema } from '@/lib/schemas'

/**
 * Request a password reset token. In the demo environment (no SMTP
 * configured) the reset link is returned in the response and logged —
 * wire Nodemailer here in production via SMTP_* env variables.
 */
export const POST = handler(async (req: NextRequest) => {
  rateLimit(req, 'forgot', 5, 60_000)
  const { email } = await parseBody(req, forgotSchema)
  const user = await db.user.findUnique({ where: { email: email.toLowerCase() } })
  if (user) {
    const token = crypto.randomUUID() + crypto.randomUUID().slice(0, 8)
    await db.passwordResetToken.create({
      data: { userId: user.id, token, expiresAt: new Date(Date.now() + 30 * 60 * 1000) },
    })
    const link = `${req.nextUrl.origin}/?reset=${token}`
    console.log(`[mail:outbox] Password reset for ${email}: ${link}`)
    return ok({
      message: 'Password reset link generated. In the demo environment the link is shown below.',
      demoResetLink: link,
    })
  }
  return ok({ message: 'If an account exists for this email, a reset link has been sent.' })
})
