import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handler, ok, parseBody, ApiError, rateLimit } from '@/lib/api'
import { registerSchema } from '@/lib/schemas'
import { hashPassword, signToken, setAuthCookie } from '@/lib/auth'
import { audit, notify } from '@/lib/services'

/** Public self-registration — creates a PATIENT account with a linked patient profile. */
export const POST = handler(async (req: NextRequest) => {
  rateLimit(req, 'register', 10, 60_000)
  const { email, name, password, phone } = await parseBody(req, registerSchema)
  const existing = await db.user.findUnique({ where: { email: email.toLowerCase() } })
  if (existing) throw new ApiError(409, 'An account with this email already exists')

  const user = await db.user.create({
    data: {
      email: email.toLowerCase(), name, role: 'PATIENT', phone: phone || null,
      passwordHash: await hashPassword(password),
    },
  })
  const count = await db.patient.count()
  const code = `P-${String(count + 1).padStart(6, '0')}`
  await db.patient.create({
    data: {
      userId: user.id, code,
      firstName: name.split(' ')[0], lastName: name.split(' ').slice(1).join(' ') || '.',
      email: user.email, phone: phone || null, gender: 'OTHER',
    },
  })
  await audit(req, { userId: user.id, name, role: 'PATIENT', email } as any, 'REGISTER', 'User', user.id)
  await notify({
    targetRoles: ['ADMIN', 'RECEPTIONIST'],
    title: 'New patient registration',
    message: `${name} created a patient portal account (${code}).`,
    type: 'PATIENT',
  })
  const session = { userId: user.id, email: user.email, name: user.name, role: 'PATIENT' as const }
  const token = signToken(session)
  const res = ok({ token, user: { ...session, avatarColor: user.avatarColor } }, undefined, 201)
  setAuthCookie(res, token)
  return res
})
