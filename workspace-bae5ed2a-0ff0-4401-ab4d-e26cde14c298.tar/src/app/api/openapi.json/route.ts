import { ok } from '@/lib/api'

/** GET /api/openapi.json — Swagger/OpenAPI 3.0 specification for the entire HMS API. */
export const GET = () => {
  const listParams = '?page=1&pageSize=10&search=&sortBy=createdAt&sortOrder=desc&<field>=<value>'
  const spec = {
    openapi: '3.0.3',
    info: {
      title: 'MediCore HMS REST API',
      version: '1.0.0',
      description:
        'Health Management System API. JWT authentication (httpOnly cookie or Bearer header). ' +
        'All list endpoints support pagination (page, pageSize), search (search), sorting (sortBy, sortOrder) and filtering by declared fields. ' +
        'Role-Based Access Control is enforced server-side.',
    },
    servers: [{ url: '/' }],
    components: {
      securitySchemes: {
        bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
        cookieAuth: { type: 'apiKey', in: 'cookie', name: 'hms_token' },
      },
      schemas: {
        ApiResponse: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            data: {},
            meta: { type: 'object', properties: { page: { type: 'integer' }, pageSize: { type: 'integer' }, total: { type: 'integer' }, totalPages: { type: 'integer' } } },
            error: { type: 'object', properties: { message: { type: 'string' }, details: {} } },
          },
        },
      },
    },
    security: [{ bearerAuth: [] }, { cookieAuth: [] }],
    paths: {
      '/api/auth/register': { post: { summary: 'Self-register a patient portal account', tags: ['Auth'], security: [], responses: { 201: { description: 'Created' }, 409: { description: 'Email taken' } } } },
      '/api/auth/login': { post: { summary: 'Sign in (sets JWT cookie + returns token)', tags: ['Auth'], security: [], responses: { 200: { description: 'OK' }, 401: { description: 'Invalid credentials' } } } },
      '/api/auth/logout': { post: { summary: 'Sign out (clears cookie)', tags: ['Auth'], responses: { 200: { description: 'OK' } } } },
      '/api/auth/me': { get: { summary: 'Current session profile', tags: ['Auth'], responses: { 200: { description: 'OK' } } }, put: { summary: 'Update own profile', tags: ['Auth'], responses: { 200: { description: 'OK' } } } },
      '/api/auth/change-password': { post: { summary: 'Change own password', tags: ['Auth'], responses: { 200: { description: 'OK' }, 400: { description: 'Wrong current password' } } } },
      '/api/auth/forgot-password': { post: { summary: 'Request password reset token (demo returns link)', tags: ['Auth'], security: [], responses: { 200: { description: 'OK' } } } },
      '/api/auth/reset-password': { post: { summary: 'Reset password with token', tags: ['Auth'], security: [], responses: { 200: { description: 'OK' }, 400: { description: 'Invalid/expired token' } } } },
      '/api/dashboard/statistics': { get: { summary: 'Headline KPIs (facility or patient scope)', tags: ['Dashboard'], responses: { 200: { description: 'OK' } } } },
      '/api/dashboard/revenue': { get: { summary: 'Monthly revenue vs billed + payment methods (admins/doctors)', tags: ['Dashboard'], responses: { 200: { description: 'OK' } } } },
      '/api/dashboard/appointments': { get: { summary: 'Daily appointment volume, status and department splits', tags: ['Dashboard'], responses: { 200: { description: 'OK' } } } },
      '/api/patients': { get: { summary: `List patients — ${listParams}`, tags: ['Patients'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Register patient (ADMIN, RECEPTIONIST, DOCTOR)', tags: ['Patients'], responses: { 201: { description: 'Created' } } } },
      '/api/patients/{id}': { get: { summary: 'Patient 360° profile (appointments, records, invoices...)', tags: ['Patients'], responses: { 200: { description: 'OK' }, 404: { description: 'Not found' } } }, put: { summary: 'Update patient', tags: ['Patients'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Delete patient', tags: ['Patients'], responses: { 200: { description: 'OK' } } } },
      '/api/doctors': { get: { summary: 'List doctors', tags: ['Doctors'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Add doctor (creates user + profile)', tags: ['Doctors'], responses: { 201: { description: 'Created' } } } },
      '/api/doctors/{id}': { get: { summary: 'Doctor detail', tags: ['Doctors'], responses: { 200: { description: 'OK' } } }, put: { summary: 'Update doctor', tags: ['Doctors'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Remove doctor', tags: ['Doctors'], responses: { 200: { description: 'OK' } } } },
      '/api/appointments': { get: { summary: 'List appointments (dateFrom/dateTo supported)', tags: ['Appointments'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Book appointment', tags: ['Appointments'], responses: { 201: { description: 'Created' } } } },
      '/api/appointments/{id}': { get: { summary: 'Appointment detail', tags: ['Appointments'], responses: { 200: { description: 'OK' } } }, put: { summary: 'Reschedule / confirm / complete / cancel / no-show', tags: ['Appointments'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Cancel or delete (patients cancel own)', tags: ['Appointments'], responses: { 200: { description: 'OK' } } } },
      '/api/medical-records': { get: { summary: 'EMR records (patients see own)', tags: ['EMR'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Add consultation record (DOCTOR)', tags: ['EMR'], responses: { 201: { description: 'Created' } } } },
      '/api/medical-records/{id}': { get: { summary: 'Record detail', tags: ['EMR'], responses: { 200: { description: 'OK' } } }, put: { summary: 'Update record', tags: ['EMR'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Delete record', tags: ['EMR'], responses: { 200: { description: 'OK' } } } },
      '/api/prescriptions': { get: { summary: 'List prescriptions with items', tags: ['Pharmacy'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Issue prescription (DOCTOR)', tags: ['Pharmacy'], responses: { 201: { description: 'Created' } } } },
      '/api/prescriptions/{id}': { get: { summary: 'Prescription detail', tags: ['Pharmacy'], responses: { 200: { description: 'OK' } } }, put: { summary: 'Update status/notes', tags: ['Pharmacy'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Delete prescription', tags: ['Pharmacy'], responses: { 200: { description: 'OK' } } } },
      '/api/prescriptions/{id}/dispense': { post: { summary: 'Dispense (PHARMACIST) — decrements stock atomically', tags: ['Pharmacy'], responses: { 200: { description: 'OK' }, 409: { description: 'Out of stock / wrong status' } } } },
      '/api/medicines': { get: { summary: 'Inventory list', tags: ['Pharmacy'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Add medicine', tags: ['Pharmacy'], responses: { 201: { description: 'Created' } } } },
      '/api/medicines/{id}': { put: { summary: 'Update medicine / restock', tags: ['Pharmacy'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Remove medicine', tags: ['Pharmacy'], responses: { 200: { description: 'OK' } } } },
      '/api/lab-tests': { get: { summary: 'Lab workflow list', tags: ['Laboratory'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Request lab test (DOCTOR)', tags: ['Laboratory'], responses: { 201: { description: 'Created' } } } },
      '/api/lab-tests/{id}': { get: { summary: 'Lab test detail', tags: ['Laboratory'], responses: { 200: { description: 'OK' } } }, put: { summary: 'Advance workflow status', tags: ['Laboratory'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Cancel lab test', tags: ['Laboratory'], responses: { 200: { description: 'OK' } } } },
      '/api/lab-tests/{id}/result': { post: { summary: 'Upload results (LAB_TECHNICIAN)', tags: ['Laboratory'], responses: { 201: { description: 'Created' } } } },
      '/api/lab-tests/{id}/review': { post: { summary: 'Doctor reviews results', tags: ['Laboratory'], responses: { 200: { description: 'OK' } } } },
      '/api/invoices': { get: { summary: 'Invoice list (patients see own)', tags: ['Billing'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Generate invoice', tags: ['Billing'], responses: { 201: { description: 'Created' } } } },
      '/api/invoices/{id}': { get: { summary: 'Invoice detail', tags: ['Billing'], responses: { 200: { description: 'OK' } } }, put: { summary: 'Update invoice status', tags: ['Billing'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Delete invoice', tags: ['Billing'], responses: { 200: { description: 'OK' } } } },
      '/api/invoices/{id}/payments': { get: { summary: 'Payments for invoice', tags: ['Billing'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Record payment (auto status update)', tags: ['Billing'], responses: { 201: { description: 'Created' } } } },
      '/api/payments': { get: { summary: 'All payment transactions', tags: ['Billing'], responses: { 200: { description: 'OK' } } } },
      '/api/wards': { get: { summary: 'Wards with live occupancy', tags: ['Wards & Beds'], responses: { 200: { description: 'OK' } } } },
      '/api/wards/{id}': { get: { summary: 'Ward detail', tags: ['Wards & Beds'], responses: { 200: { description: 'OK' } } }, put: { summary: 'Update ward', tags: ['Wards & Beds'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Delete ward (no occupied beds)', tags: ['Wards & Beds'], responses: { 200: { description: 'OK' } } } },
      '/api/beds': { get: { summary: 'Bed map with current occupant', tags: ['Wards & Beds'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Add bed', tags: ['Wards & Beds'], responses: { 201: { description: 'Created' } } } },
      '/api/beds/{id}': { put: { summary: 'Update bed status/rate', tags: ['Wards & Beds'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Remove bed', tags: ['Wards & Beds'], responses: { 200: { description: 'OK' } } } },
      '/api/admissions': { get: { summary: 'Admissions list', tags: ['Wards & Beds'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Admit patient (occupies bed, transactional)', tags: ['Wards & Beds'], responses: { 201: { description: 'Created' } } } },
      '/api/admissions/{id}': { put: { summary: 'Transfer bed or discharge', tags: ['Wards & Beds'], responses: { 200: { description: 'OK' } } } },
      '/api/staff': { get: { summary: 'Staff directory', tags: ['Staff'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Onboard staff (user + profile)', tags: ['Staff'], responses: { 201: { description: 'Created' } } } },
      '/api/staff/{id}': { get: { summary: 'Staff detail + attendance', tags: ['Staff'], responses: { 200: { description: 'OK' } } }, put: { summary: 'Update staff', tags: ['Staff'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Deactivate staff', tags: ['Staff'], responses: { 200: { description: 'OK' } } } },
      '/api/staff/attendance': { get: { summary: 'Attendance records', tags: ['Staff'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Mark attendance (upsert)', tags: ['Staff'], responses: { 201: { description: 'Created' } } } },
      '/api/users': { get: { summary: 'User directory (ADMIN)', tags: ['Users'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Create user', tags: ['Users'], responses: { 201: { description: 'Created' } } } },
      '/api/users/{id}': { put: { summary: 'Update user / reset password', tags: ['Users'], responses: { 200: { description: 'OK' } } }, delete: { summary: 'Deactivate user', tags: ['Users'], responses: { 200: { description: 'OK' } } } },
      '/api/departments': { get: { summary: 'Departments', tags: ['Organization'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Create department', tags: ['Organization'], responses: { 201: { description: 'Created' } } } },
      '/api/notifications': { get: { summary: 'Notifications for current user/role', tags: ['Notifications'], responses: { 200: { description: 'OK' } } } },
      '/api/notifications/{id}': { put: { summary: 'Mark read / mark all read', tags: ['Notifications'], responses: { 200: { description: 'OK' } } } },
      '/api/audit-logs': { get: { summary: 'Audit trail (ADMIN)', tags: ['Security'], responses: { 200: { description: 'OK' } } } },
      '/api/documents': { get: { summary: 'List patient documents', tags: ['Documents'], responses: { 200: { description: 'OK' } } }, post: { summary: 'Upload document (PDF/PNG/JPEG/WebP, ≤5MB)', tags: ['Documents'], responses: { 201: { description: 'Created' } } } },
      '/api/documents/{id}': { get: { summary: 'Download document', tags: ['Documents'], responses: { 200: { description: 'File' } } }, delete: { summary: 'Delete document', tags: ['Documents'], responses: { 200: { description: 'OK' } } } },
      '/api/export': { get: { summary: 'CSV export (type=patients|appointments|invoices|payments|medicines|lab-tests)', tags: ['Reports'], responses: { 200: { description: 'CSV file' } } } },
    },
  }
  return ok(spec)
}
