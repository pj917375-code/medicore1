import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, buildWhere, parseBody, handler } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { labTestSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit, notify } from '@/lib/services'
import { z } from 'zod'

const labCreateSchema = labTestSchema

/** GET /api/lab-tests — lab workflow list, scoped per role. */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['status', 'patientId', 'doctorId', 'category', 'priority'].includes(k)) filters[k] = v
  }
  let extra: Record<string, unknown> = {}
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    extra = { patientId: patient?.id || 'none' }
  } else if (session.role === 'DOCTOR') {
    const doctor = await db.doctor.findUnique({ where: { userId: session.userId } })
    extra = { doctorId: doctor?.id || 'none' }
  }
  const where = buildWhere(['testName', 'code'], q.search, filters, extra)
  const [total, rows] = await Promise.all([
    db.labTest.count({ where }),
    db.labTest.findMany({
      where, orderBy: { requestedAt: 'desc' },
      include: {
        patient: { select: { id: true, firstName: true, lastName: true, code: true } },
        doctor: { include: { user: { select: { name: true } } } },
        result: true,
      },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})

/** POST /api/lab-tests — doctor requests a lab test. */
export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES['lab-tests'] as any)
  const data = await parseBody(req, labCreateSchema)
  const count = await db.labTest.count()
  const lt = await db.labTest.create({
    data: {
      code: `LAB-${String(count + 1).padStart(6, '0')}`,
      patientId: data.patientId, doctorId: data.doctorId,
      testName: data.testName, category: data.category,
      sampleType: data.sampleType, priority: data.priority, notes: data.notes,
    },
    include: {
      patient: { select: { firstName: true, lastName: true, code: true } },
      doctor: { include: { user: { select: { name: true } } } },
    },
  })
  await audit(req, session, 'CREATE', 'LabTest', lt.id, `${lt.code} — ${data.testName}`)
  await notify({
    targetRoles: ['LAB_TECHNICIAN', 'ADMIN'],
    title: data.priority === 'URGENT' ? 'URGENT lab request' : 'New lab request',
    message: `${data.testName} requested for ${lt.patient.firstName} ${lt.patient.lastName} by Dr. ${lt.doctor.user.name}.`,
    type: 'LAB',
  })
  return ok(lt, undefined, 201)
})
