import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { labResultSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit, notify } from '@/lib/services'

/** POST /api/lab-tests/:id/result — technician uploads results, marks COMPLETED. */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES['lab-results'] as any)
  const data = await parseBody(req, labResultSchema)
  const lt = await db.labTest.findUnique({ where: { id }, include: { patient: true, doctor: { include: { user: true } } } })
  if (!lt) throw new ApiError(404, 'Lab test not found')
  if (lt.result) throw new ApiError(409, 'Results have already been uploaded for this test')

  const result = await db.$transaction(async (tx) => {
    const r = await tx.labResult.create({
      data: {
        labTestId: id, resultSummary: data.resultSummary,
        values: data.values ? JSON.stringify(data.values) : null,
        technologist: data.technologist || session.name,
      },
    })
    await tx.labTest.update({ where: { id }, data: { status: 'COMPLETED' } })
    return r
  })

  await audit(req, session, 'CREATE', 'LabResult', result.id, `${lt.code} results uploaded`)
  await notify({
    userId: lt.doctor.userId || undefined,
    title: 'Lab results ready',
    message: `Results for ${lt.testName} (${lt.code}) are ready for your review.`,
    type: 'LAB',
  })
  return ok(result, undefined, 201)
})
