import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers, withId } from '@/lib/crud'
import { labTestUpdateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { notify } from '@/lib/services'

const handlers = createCrudHandlers({
  delegate: db.labTest,
  resource: 'LabTest',
  searchFields: ['testName', 'code'],
  include: {
    patient: { select: { id: true, firstName: true, lastName: true, code: true } },
    doctor: { include: { user: { select: { name: true } } } },
    result: true,
  },
  writeRoles: ['SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'LAB_TECHNICIAN', 'NURSE'] as any,
  updateSchema: labTestUpdateSchema,
  afterUpdate: async (row: any) => {
    // Notify doctor when tech completes the sample/processing pipeline
    if (['SAMPLE_COLLECTED', 'PROCESSING'].includes(row.status)) {
      await notify({
        targetRoles: ['LAB_TECHNICIAN'],
        title: 'Lab status updated',
        message: `${row.code} (${row.testName}) is now ${row.status.replace('_', ' ').toLowerCase()}.`,
        type: 'LAB',
      })
    }
  },
})

export const GET = withId(handlers).GET
export const PUT = withId(handlers).PUT
export const DELETE = withId(handlers).DELETE
