import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'

/** POST /api/lab-tests/:id/review — doctor reviews completed results. */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES['lab-review'] as any)
  const lt = await db.labTest.findUnique({ where: { id }, include: { result: true } })
  if (!lt) throw new ApiError(404, 'Lab test not found')
  if (!lt.result) throw new ApiError(400, 'Results have not been uploaded yet')
  if (lt.status === 'REVIEWED') throw new ApiError(400, 'Already reviewed')

  await db.$transaction([
    db.labResult.update({ where: { labTestId: id }, data: { reviewedBy: session.name, reviewedAt: new Date() } }),
    db.labTest.update({ where: { id }, data: { status: 'REVIEWED' } }),
  ])
  await audit(req, session, 'UPDATE', 'LabTest', id, `${lt.code} reviewed`)
  return ok({ message: 'Results reviewed', reviewedBy: session.name })
})
