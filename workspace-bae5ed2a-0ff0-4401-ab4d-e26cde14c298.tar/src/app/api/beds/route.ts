import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, buildWhere, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { bedSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'

/** GET /api/beds — bed map with ward info; filter by wardId/status. */
export const GET = handler(async (req: NextRequest) => {
  requireAuth(req)
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['status', 'wardId'].includes(k)) filters[k] = v
  }
  const where = buildWhere(['bedNumber'], q.search, filters)
  const rows = await db.bed.findMany({
    where, orderBy: [{ wardId: 'asc' }, { bedNumber: 'asc' }],
    include: {
      ward: true,
      admissions: {
        where: { status: 'ADMITTED' },
        include: { patient: { select: { firstName: true, lastName: true, code: true } } },
        take: 1,
      },
    },
  })
  return ok(rows, { total: rows.length })
})

export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES.beds as any)
  const data = await parseBody(req, bedSchema)
  const bed = await db.bed.create({ data, include: { ward: true } })
  await audit(req, session, 'CREATE', 'Bed', bed.id, bed.bedNumber)
  return ok(bed, undefined, 201)
})
