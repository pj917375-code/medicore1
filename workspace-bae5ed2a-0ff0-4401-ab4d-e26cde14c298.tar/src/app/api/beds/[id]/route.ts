import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers, withId } from '@/lib/crud'
import { bedUpdateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'

const handlers = createCrudHandlers({
  delegate: db.bed,
  resource: 'Bed',
  searchFields: ['bedNumber'],
  include: { ward: true },
  writeRoles: WRITE_ROLES.beds as any,
  updateSchema: bedUpdateSchema,
})

export const GET = withId(handlers).GET
export const PUT = withId(handlers).PUT
export const DELETE = withId(handlers).DELETE
