import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handler, ok } from '@/lib/api'
import { requireAuth } from '@/lib/auth'

const DAY = 24 * 60 * 60 * 1000

/** GET /api/dashboard/statistics — headline KPIs for the admin dashboard. */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const tomorrow = new Date(today.getTime() + DAY)

  // Patients can only see their own scope; staff see facility-wide stats.
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    if (!patient) return ok({})
    const [appointments, prescriptions, labTests, invoices] = await Promise.all([
      db.appointment.count({ where: { patientId: patient.id } }),
      db.prescription.count({ where: { patientId: patient.id } }),
      db.labTest.count({ where: { patientId: patient.id } }),
      db.invoice.aggregate({ where: { patientId: patient.id, status: { not: 'CANCELLED' } }, _sum: { total: true, amountPaid: true } }),
    ])
    const upcoming = await db.appointment.count({ where: { patientId: patient.id, scheduledAt: { gte: today }, status: { in: ['SCHEDULED', 'CONFIRMED'] } } })
    const outstanding = (invoices._sum.total || 0) - (invoices._sum.amountPaid || 0)
    return ok({
      scope: 'patient',
      myAppointments: appointments, upcomingAppointments: upcoming,
      myPrescriptions: prescriptions, myLabTests: labTests,
      outstandingBalance: outstanding,
    })
  }

  const [
    totalPatients, totalDoctors, totalStaff,
    todayAppointments, upcomingAppointments,
    availableBeds, totalBeds,
    totalAdmissions, dischargedPatients,
    revenueAgg, monthlyPatients,
    pendingPrescriptions, pendingLabs, unpaidInvoices,
  ] = await Promise.all([
    db.patient.count(),
    db.doctor.count({ where: { status: 'ACTIVE' } }),
    db.staff.count({ where: { status: 'ACTIVE' } }),
    db.appointment.count({ where: { scheduledAt: { gte: today, lt: tomorrow } } }),
    db.appointment.count({ where: { scheduledAt: { gte: tomorrow }, status: { in: ['SCHEDULED', 'CONFIRMED'] } } }),
    db.bed.count({ where: { status: 'AVAILABLE' } }),
    db.bed.count(),
    db.admission.count({ where: { status: 'ADMITTED' } }),
    db.admission.count({ where: { status: 'DISCHARGED' } }),
    db.invoice.aggregate({ where: { status: { not: 'CANCELLED' } }, _sum: { total: true, amountPaid: true } }),
    db.patient.count({ where: { createdAt: { gte: new Date(Date.now() - 30 * DAY) } } }),
    db.prescription.count({ where: { status: 'PENDING' } }),
    db.labTest.count({ where: { status: { in: ['REQUESTED', 'SAMPLE_COLLECTED', 'PROCESSING'] } } }),
    db.invoice.count({ where: { status: { in: ['UNPAID', 'PARTIALLY_PAID'] } } }),
  ])

  const totalRevenue = revenueAgg._sum.amountPaid || 0
  const billedRevenue = revenueAgg._sum.total || 0

  // Recent activity feed (audit trail)
  const recentActivity = await db.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 8 })

  return ok({
    scope: 'facility',
    totalPatients, totalDoctors, totalStaff,
    todayAppointments, upcomingAppointments,
    availableBeds, totalBeds, occupancyRate: totalBeds ? Math.round(((totalBeds - availableBeds) / totalBeds) * 100) : 0,
    totalAdmissions, dischargedPatients,
    totalRevenue, billedRevenue, outstandingBalance: Math.max(0, billedRevenue - totalRevenue),
    newPatients30d: monthlyPatients,
    pendingPrescriptions, pendingLabs, unpaidInvoices,
    recentActivity,
  })
})
