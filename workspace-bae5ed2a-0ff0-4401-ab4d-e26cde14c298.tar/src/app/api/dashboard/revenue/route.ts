import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handler, ok } from '@/lib/api'
import { requireAuth } from '@/lib/auth'

/** GET /api/dashboard/revenue — monthly revenue vs billed (last 12 months) + payment methods. */
export const GET = handler(async (req: NextRequest) => {
  requireAuth(req, ['SUPER_ADMIN', 'ADMIN', 'DOCTOR'])
  const since = new Date()
  since.setMonth(since.getMonth() - 11)
  since.setDate(1)
  since.setHours(0, 0, 0, 0)

  const [invoices, payments] = await Promise.all([
    db.invoice.findMany({ where: { createdAt: { gte: since }, status: { not: 'CANCELLED' } }, select: { total: true, amountPaid: true, createdAt: true } }),
    db.payment.findMany({ where: { paidAt: { gte: since } }, select: { amount: true, method: true } }),
  ])

  const monthly: Record<string, { month: string; billed: number; collected: number }> = {}
  for (let i = 0; i < 12; i++) {
    const d = new Date(since.getFullYear(), since.getMonth() + i, 1)
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
    monthly[key] = { month: d.toLocaleString('en-US', { month: 'short' }), billed: 0, collected: 0 }
  }
  for (const inv of invoices) {
    const key = `${inv.createdAt.getFullYear()}-${String(inv.createdAt.getMonth() + 1).padStart(2, '0')}`
    if (monthly[key]) {
      monthly[key].billed += inv.total
      monthly[key].collected += inv.amountPaid
    }
  }
  const methods: Record<string, number> = {}
  for (const p of payments) methods[p.method] = (methods[p.method] || 0) + p.amount

  return ok({
    monthly: Object.values(monthly),
    paymentMethods: Object.entries(methods).map(([method, amount]) => ({ method, amount: Math.round(amount) })),
  })
})
