import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { handler, ok } from '@/lib/api'
import { requireAuth } from '@/lib/auth'

const DAY = 24 * 60 * 60 * 1000

/** GET /api/dashboard/appointments — daily volume (14d), status split, department split. */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const since = new Date(today.getTime() - 13 * DAY)

  let patientFilter: Record<string, unknown> = {}
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    patientFilter = { patientId: patient?.id || 'none' }
  }

  const [appointments, byStatus, byDept] = await Promise.all([
    db.appointment.findMany({
      where: { scheduledAt: { gte: since, lt: new Date(today.getTime() + 8 * DAY) }, ...patientFilter },
      select: { scheduledAt: true, status: true },
    }),
    db.appointment.groupBy({ by: ['status'], _count: { _all: true }, where: patientFilter }),
    db.appointment.groupBy({
      by: ['departmentId'], _count: { _all: true },
      where: { departmentId: { not: null }, ...patientFilter },
    }),
  ])

  const days: { day: string; date: string; count: number; completed: number }[] = []
  for (let i = 0; i < 21; i++) {
    const d = new Date(since.getTime() + i * DAY)
    days.push({ day: d.toLocaleString('en-US', { weekday: 'short' }), date: d.toISOString().slice(0, 10), count: 0, completed: 0 })
  }
  for (const a of appointments) {
    const key = new Date(a.scheduledAt.getTime() - a.scheduledAt.getTimezoneOffset() * 60000).toISOString().slice(0, 10)
    const row = days.find((x) => x.date === key)
    if (row) {
      row.count++
      if (a.status === 'COMPLETED') row.completed++
    }
  }

  const deptIds = byDept.map((d) => d.departmentId!).filter(Boolean)
  const depts = deptIds.length ? await db.department.findMany({ where: { id: { in: deptIds } } }) : []
  const deptChart = byDept.map((d) => ({
    name: depts.find((x) => x.id === d.departmentId)?.name || 'Other',
    value: d._count._all,
  })).sort((a, b) => b.value - a.value)

  return ok({
    daily: days,
    byStatus: byStatus.map((s) => ({ status: s.status, count: s._count._all })),
    byDepartment: deptChart,
  })
})
