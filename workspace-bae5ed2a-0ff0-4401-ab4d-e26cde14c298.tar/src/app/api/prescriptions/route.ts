import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, buildWhere, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { prescriptionSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit, notify } from '@/lib/services'
import { z } from 'zod'

const rxCreateSchema = prescriptionSchema.extend({ medicalRecordId: z.string().optional() })

/** GET /api/prescriptions — scoped by role (doctor sees own, patient sees own). */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['status', 'patientId', 'doctorId'].includes(k)) filters[k] = v
  }
  let extra: Record<string, unknown> = {}
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    extra = { patientId: patient?.id || 'none' }
  } else if (session.role === 'DOCTOR') {
    const doctor = await db.doctor.findUnique({ where: { userId: session.userId } })
    extra = { doctorId: doctor?.id || 'none' }
  }
  const where = buildWhere(['code', 'notes'], q.search, filters, extra)
  const [total, rows] = await Promise.all([
    db.prescription.count({ where }),
    db.prescription.findMany({
      where, orderBy: { createdAt: 'desc' },
      include: {
        patient: { select: { id: true, firstName: true, lastName: true, code: true } },
        doctor: { include: { user: { select: { name: true } } } },
        items: { include: { medicine: true } },
      },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})

/** POST /api/prescriptions — doctor issues prescription (with line items). */
export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES.prescriptions as any)
  const data = await parseBody(req, rxCreateSchema)
  const count = await db.prescription.count()
  const rx = await db.prescription.create({
    data: {
      code: `RX-${String(count + 1).padStart(6, '0')}`,
      patientId: data.patientId, doctorId: data.doctorId,
      medicalRecordId: data.medicalRecordId || null,
      notes: data.notes,
      items: { create: data.items.map((it: any) => ({ ...it, medicineId: it.medicineId || null })) },
    },
    include: {
      patient: { select: { firstName: true, lastName: true, code: true } },
      doctor: { include: { user: { select: { name: true } } } },
      items: true,
    },
  })
  await audit(req, session, 'CREATE', 'Prescription', rx.id, `${rx.code} — ${data.items.length} medicine(s)`)
  await notify({
    targetRoles: ['PHARMACIST', 'ADMIN'],
    title: 'New prescription',
    message: `Prescription ${rx.code} for ${rx.patient.firstName} ${rx.patient.lastName} is awaiting dispensing.`,
    type: 'PRESCRIPTION',
  })
  return ok(rx, undefined, 201)
})
