import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit, notify } from '@/lib/services'

/**
 * POST /api/prescriptions/:id/dispense — pharmacist dispenses:
 * decrements medicine stock atomically and marks prescription DISPENSED.
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES['prescriptions-dispense'] as any)
  const rx = await db.prescription.findUnique({ where: { id }, include: { items: true, patient: true } })
  if (!rx) throw new ApiError(404, 'Prescription not found')
  if (rx.status !== 'PENDING') throw new ApiError(400, `Prescription is ${rx.status} and cannot be dispensed`)

  const dispensed = await db.$transaction(async (tx) => {
    for (const item of rx.items) {
      if (!item.medicineId) continue
      const med = await tx.medicine.findUnique({ where: { id: item.medicineId } })
      if (!med) continue
      if (med.stockQty <= 0) throw new ApiError(409, `${med.name} is out of stock`)
      const qty = Math.min(med.stockQty, 1)
      await tx.medicine.update({ where: { id: med.id }, data: { stockQty: { decrement: 1 } } })
      await tx.prescriptionItem.update({ where: { id: item.id }, data: { dispensedQty: item.dispensedQty + qty } })
      if (med.stockQty - 1 <= med.reorderLevel) {
        await tx.notification.create({
          data: {
            targetRoles: 'PHARMACIST,ADMIN',
            title: 'Low stock alert',
            message: `${med.name} has reached the reorder level (${med.stockQty - 1}/${med.reorderLevel}).`,
            type: 'PRESCRIPTION',
          },
        })
      }
    }
    return tx.prescription.update({ where: { id }, data: { status: 'DISPENSED' }, include: { items: true, patient: true, doctor: { include: { user: { select: { name: true } } } } } })
  })

  await audit(req, session, 'UPDATE', 'Prescription', id, `${rx.code} dispensed`)
  await notify({
    userId: rx.patient.userId || undefined,
    title: 'Prescription ready',
    message: `Prescription ${rx.code} has been dispensed by the pharmacy.`,
    type: 'PRESCRIPTION',
  })
  return ok(dispensed)
})
