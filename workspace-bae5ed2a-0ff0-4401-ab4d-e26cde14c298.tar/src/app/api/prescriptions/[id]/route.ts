import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers, withId } from '@/lib/crud'
import { WRITE_ROLES } from '@/lib/rbac'
import { z } from 'zod'

const handlers = createCrudHandlers({
  delegate: db.prescription,
  resource: 'Prescription',
  searchFields: ['code'],
  include: {
    patient: { select: { id: true, firstName: true, lastName: true, code: true } },
    doctor: { include: { user: { select: { name: true } } } },
    items: { include: { medicine: true } },
  },
  writeRoles: [...WRITE_ROLES.prescriptions, ...WRITE_ROLES['prescriptions-dispense']] as any,
  updateSchema: z.object({ status: z.enum(['PENDING', 'DISPENSED', 'CANCELLED']).optional(), notes: z.string().max(500).optional() }),
})

export const GET = withId(handlers).GET
export const PUT = withId(handlers).PUT
export const DELETE = withId(handlers).DELETE
