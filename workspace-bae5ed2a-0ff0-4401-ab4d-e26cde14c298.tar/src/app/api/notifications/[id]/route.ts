import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { notificationActionSchema } from '@/lib/schemas'
import { parseBody } from '@/lib/api'

/** PUT /api/notifications/:id — mark a notification read (or all with markAllRead). */
export const PUT = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req)
  const { markAllRead, isRead } = await parseBody(req, notificationActionSchema)

  if (markAllRead) {
    await db.notification.updateMany({
      where: { OR: [{ userId: session.userId }, { userId: null, targetRoles: { contains: session.role } }], isRead: false },
      data: { isRead: true },
    })
    return ok({ message: 'All notifications marked as read' })
  }
  const n = await db.notification.findUnique({ where: { id } })
  if (!n) throw new ApiError(404, 'Notification not found')
  if (n.userId && n.userId !== session.userId) throw new ApiError(403, 'Not your notification')
  const updated = await db.notification.update({ where: { id }, data: { isRead: isRead ?? true } })
  return ok(updated)
})
