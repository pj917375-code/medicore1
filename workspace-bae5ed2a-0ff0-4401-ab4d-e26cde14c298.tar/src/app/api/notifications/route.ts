import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, handler } from '@/lib/api'
import { requireAuth } from '@/lib/auth'

/**
 * GET /api/notifications — notifications visible to the current session:
 * personal + broadcast targeted at the user's role.
 */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const notifications = await db.notification.findMany({
    where: { OR: [{ userId: session.userId }, { userId: null, targetRoles: { contains: session.role } }] },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })
  const unread = notifications.filter((n) => !n.isRead).length
  return ok(notifications, { unread })
})
