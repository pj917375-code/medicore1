import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, buildWhere, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { admissionSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit, notify } from '@/lib/services'

/** GET /api/admissions — admissions with bed/ward/patient info. */
export const GET = handler(async (req: NextRequest) => {
  requireAuth(req)
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['status', 'patientId', 'doctorId'].includes(k)) filters[k] = v
  }
  const where = buildWhere(['reason'], q.search, filters)
  const [total, rows] = await Promise.all([
    db.admission.count({ where }),
    db.admission.findMany({
      where, orderBy: { admittedAt: 'desc' },
      include: {
        patient: { select: { id: true, firstName: true, lastName: true, code: true } },
        bed: { include: { ward: true } },
        doctor: { include: { user: { select: { name: true } } } },
      },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})

/** POST /api/admissions — admit patient into a free bed (transaction: bed → OCCUPIED). */
export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES.admissions as any)
  const data = await parseBody(req, admissionSchema)
  const bed = await db.bed.findUnique({ where: { id: data.bedId }, include: { ward: true } })
  if (!bed) throw new ApiError(404, 'Bed not found')
  if (bed.status !== 'AVAILABLE') throw new ApiError(409, `Bed ${bed.bedNumber} is not available (${bed.status})`)

  const admission = await db.$transaction(async (tx) => {
    await tx.bed.update({ where: { id: bed.id }, data: { status: 'OCCUPIED' } })
    return tx.admission.create({
      data: {
        patientId: data.patientId, bedId: data.bedId,
        doctorId: data.doctorId || null, reason: data.reason, notes: data.notes,
      },
      include: {
        patient: { select: { firstName: true, lastName: true, code: true } },
        bed: { include: { ward: true } },
        doctor: { include: { user: { select: { name: true } } } },
      },
    })
  })

  await audit(req, session, 'CREATE', 'Admission', admission.id, `${admission.patient.firstName} ${admission.patient.lastName} → ${bed.bedNumber}`)
  await notify({
    targetRoles: ['ADMIN', 'NURSE'],
    title: 'Patient admitted',
    message: `${admission.patient.firstName} ${admission.patient.lastName} admitted to ${bed.ward.name} / ${bed.bedNumber}.`,
    type: 'SYSTEM',
  })
  return ok(admission, undefined, 201)
})
