import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { admissionUpdateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit, notify } from '@/lib/services'

/** PUT /api/admissions/:id — transfer bed or discharge (frees the bed). */
export const PUT = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.admissions as any)
  const data = await parseBody(req, admissionUpdateSchema)
  const admission = await db.admission.findUnique({ where: { id }, include: { bed: { include: { ward: true } }, patient: true } })
  if (!admission) throw new ApiError(404, 'Admission not found')

  if (data.status === 'DISCHARGED') {
    if (admission.status === 'DISCHARGED') throw new ApiError(400, 'Patient is already discharged')
    const updated = await db.$transaction(async (tx) => {
      await tx.bed.update({ where: { id: admission.bedId }, data: { status: 'AVAILABLE' } })
      return tx.admission.update({
        where: { id }, data: { status: 'DISCHARGED', dischargedAt: new Date(), notes: data.notes || admission.notes },
        include: {
          patient: { select: { firstName: true, lastName: true, code: true } },
          bed: { include: { ward: true } }, doctor: { include: { user: { select: { name: true } } } },
        },
      })
    })
    await audit(req, session, 'UPDATE', 'Admission', id, `${admission.patient.firstName} discharged from ${admission.bed.bedNumber}`)
    await notify({
      targetRoles: ['ADMIN', 'NURSE'],
      title: 'Patient discharged',
      message: `${admission.patient.firstName} ${admission.patient.lastName} discharged from ${admission.bed.ward.name}. Bed ${admission.bed.bedNumber} is now available.`,
      type: 'SYSTEM',
    })
    return ok(updated)
  }

  // Bed transfer
  if (data.bedId && data.bedId !== admission.bedId) {
    const newBed = await db.bed.findUnique({ where: { id: data.bedId } })
    if (!newBed) throw new ApiError(404, 'New bed not found')
    if (newBed.status !== 'AVAILABLE') throw new ApiError(409, `Bed ${newBed.bedNumber} is not available`)
    const updated = await db.$transaction(async (tx) => {
      await tx.bed.update({ where: { id: admission.bedId }, data: { status: 'AVAILABLE' } })
      await tx.bed.update({ where: { id: newBed.id }, data: { status: 'OCCUPIED' } })
      return tx.admission.update({
        where: { id }, data: { bedId: newBed.id, notes: data.notes || admission.notes },
        include: {
          patient: { select: { firstName: true, lastName: true, code: true } },
          bed: { include: { ward: true } }, doctor: { include: { user: { select: { name: true } } } },
        },
      })
    })
    await audit(req, session, 'UPDATE', 'Admission', id, `Transferred to ${newBed.bedNumber}`)
    return ok(updated)
  }

  const updated = await db.admission.update({
    where: { id }, data: { notes: data.notes || admission.notes },
    include: { patient: { select: { firstName: true, lastName: true, code: true } }, bed: { include: { ward: true } }, doctor: { include: { user: { select: { name: true } } } } },
  })
  return ok(updated)
})

export const GET = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  requireAuth(req)
  const admission = await db.admission.findUnique({
    where: { id },
    include: { patient: true, bed: { include: { ward: true } }, doctor: { include: { user: { select: { name: true } } } } },
  })
  if (!admission) throw new ApiError(404, 'Admission not found')
  return ok(admission)
})
