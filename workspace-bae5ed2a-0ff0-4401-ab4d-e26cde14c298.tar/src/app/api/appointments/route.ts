import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, buildWhere, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { appointmentSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit, notify } from '@/lib/services'
import { z } from 'zod'

const apptCreateSchema = appointmentSchema.omit({ patientId: true }).extend({ patientId: z.string().optional() })

/** GET /api/appointments — scoped list. Patients only see their own. */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['status', 'doctorId', 'patientId', 'departmentId'].includes(k)) filters[k] = v
  }
  let extra: Record<string, unknown> = {}
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    extra = { patientId: patient?.id || 'none' }
  } else if (session.role === 'DOCTOR') {
    const doctor = await db.doctor.findUnique({ where: { userId: session.userId } })
    extra = { doctorId: doctor?.id || 'none' }
  }
  const dateFrom = new URL(req.url).searchParams.get('dateFrom')
  const dateTo = new URL(req.url).searchParams.get('dateTo')
  if (dateFrom || dateTo) {
    extra.scheduledAt = {
      ...(dateFrom ? { gte: new Date(dateFrom) } : {}),
      ...(dateTo ? { lte: new Date(`${dateTo}T23:59:59.999Z`) } : {}),
    }
  }
  const where = buildWhere(['reason', 'code'], q.search, filters, extra)
  const [total, rows] = await Promise.all([
    db.appointment.count({ where }),
    db.appointment.findMany({
      where, orderBy: { scheduledAt: q.sortOrder },
      include: {
        patient: { select: { id: true, firstName: true, lastName: true, code: true, phone: true } },
        doctor: { include: { user: { select: { name: true } } } },
        department: true,
      },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})

/** POST /api/appointments — book appointment + notify doctor & patient. */
export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES.appointments as any)
  const data = await parseBody(req, apptCreateSchema)
  // Patients book for themselves — resolve patientId from their portal account
  if (session.role === 'PATIENT') {
    const me = await db.patient.findUnique({ where: { userId: session.userId } })
    if (!me) throw new ApiError(400, 'No patient profile is linked to your account')
    data.patientId = me.id
  } else if (!data.patientId) {
    throw new ApiError(400, 'Patient is required')
  }
  const count = await db.appointment.count()
  const [doctor, patient] = await Promise.all([
    db.doctor.findUnique({ where: { id: data.doctorId }, include: { user: true } }),
    db.patient.findUnique({ where: { id: data.patientId } }),
  ])
  if (!doctor) throw new ApiError(404, 'Doctor not found')
  if (!patient) throw new ApiError(404, 'Patient not found')
  const appt = await db.appointment.create({
    data: {
      code: `APT-${String(count + 1).padStart(6, '0')}`,
      patientId: data.patientId, doctorId: data.doctorId,
      departmentId: data.departmentId || doctor.departmentId || null,
      scheduledAt: data.scheduledAt, durationMinutes: data.durationMinutes,
      reason: data.reason, notes: data.notes, createdBy: session.name,
    },
    include: {
      patient: { select: { firstName: true, lastName: true, code: true } },
      doctor: { include: { user: { select: { name: true } } } },
    },
  })
  await audit(req, session, 'CREATE', 'Appointment', appt.id, `${patient.firstName} ${patient.lastName} → ${doctor.user.name}`)
  await notify({
    targetRoles: ['ADMIN', 'RECEPTIONIST', 'DOCTOR'],
    title: 'Appointment booked',
    message: `${patient.firstName} ${patient.lastName} booked with Dr. ${doctor.user.name} on ${appt.scheduledAt.toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}.`,
    type: 'APPOINTMENT',
  })
  return ok(appt, undefined, 201)
})
