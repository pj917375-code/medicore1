import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers, withId } from '@/lib/crud'
import { appointmentUpdateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { notify } from '@/lib/services'
import { ok, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { audit } from '@/lib/services'

const handlers = createCrudHandlers({
  delegate: db.appointment,
  resource: 'Appointment',
  searchFields: ['reason', 'code'],
  include: {
    patient: { select: { id: true, firstName: true, lastName: true, code: true, phone: true } },
    doctor: { include: { user: { select: { name: true } } } },
    department: true,
  },
  writeRoles: WRITE_ROLES.appointments as any,
  updateSchema: appointmentUpdateSchema,
  afterUpdate: async (row: any) => {
    if (row.status === 'CONFIRMED') {
      await notify({
        targetRoles: ['ADMIN', 'RECEPTIONIST'],
        title: 'Appointment confirmed',
        message: `Appointment ${row.code} has been confirmed.`,
        type: 'APPOINTMENT',
      })
    }
  },
})

const dynamic = withId(handlers)

/** DELETE checks ownership for patients; COMPLETED appointments cannot be deleted. */
export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.appointments as any)
  const appt = await db.appointment.findUnique({ where: { id } })
  if (!appt) throw new ApiError(404, 'Record not found')
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    if (patient?.id !== appt.patientId) throw new ApiError(403, 'You can only cancel your own appointments')
    await db.appointment.update({ where: { id }, data: { status: 'CANCELLED' } })
    await audit(req, session, 'UPDATE', 'Appointment', id, 'Cancelled by patient')
    return ok({ id, status: 'CANCELLED' })
  }
  return dynamic.DELETE(req, ctx)
})

export const GET = dynamic.GET
export const PUT = dynamic.PUT
