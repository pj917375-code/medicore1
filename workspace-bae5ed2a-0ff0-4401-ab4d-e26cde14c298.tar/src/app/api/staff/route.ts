import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth, hashPassword } from '@/lib/auth'
import { staffSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'
import { buildWhere } from '@/lib/api'
import { z } from 'zod'

const staffCreateSchema = staffSchema

/** GET /api/staff — staff directory with attendance stats. */
export const GET = handler(async (req: NextRequest) => {
  requireAuth(req, ['SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'NURSE', 'RECEPTIONIST'])
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['shift', 'status', 'department'].includes(k)) filters[k] = v
  }
  const where = buildWhere(['employeeCode', 'title', 'department'], q.search, filters)
  const [total, rows] = await Promise.all([
    db.staff.count({ where }),
    db.staff.findMany({
      where, orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { name: true, email: true, phone: true, role: true, isActive: true } },
        attendance: { orderBy: { date: 'desc' }, take: 7 },
      },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})

/** POST /api/staff — onboard employee: user account + staff profile. */
export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES.staff as any)
  const data = await parseBody(req, staffCreateSchema)
  const existing = await db.user.findUnique({ where: { email: data.email.toLowerCase() } })
  if (existing) throw new ApiError(409, 'A user with this email already exists')
  const existingCode = await db.staff.findUnique({ where: { employeeCode: data.employeeCode } })
  if (existingCode) throw new ApiError(409, 'Employee code already in use')

  const staff = await db.$transaction(async (tx) => {
    const user = await tx.user.create({
      data: {
        email: data.email.toLowerCase(), name: data.name, role: data.role,
        passwordHash: await hashPassword(data.password || 'Staff@1234'),
      },
    })
    return tx.staff.create({
      data: {
        userId: user.id, employeeCode: data.employeeCode, title: data.title,
        department: data.department, shift: data.shift, joinedAt: new Date(),
      },
      include: { user: { select: { name: true, email: true, role: true } } },
    })
  })
  await audit(req, session, 'CREATE', 'Staff', staff.id, `${data.name} (${data.title})`)
  return ok(staff, undefined, 201)
})
