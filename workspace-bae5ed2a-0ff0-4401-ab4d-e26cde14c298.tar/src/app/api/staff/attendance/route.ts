import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, parseBody, buildWhere, handler } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { attendanceSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'
import { z } from 'zod'

const upsertSchema = attendanceSchema

/** GET /api/staff/attendance — attendance records (filter: date, staffId). */
export const GET = handler(async (req: NextRequest) => {
  requireAuth(req, ['SUPER_ADMIN', 'ADMIN', 'NURSE', 'RECEPTIONIST', 'DOCTOR'])
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['staffId', 'status'].includes(k)) filters[k] = v
  }
  const where = buildWhere(['date'], q.search, filters)
  const rows = await db.staffAttendance.findMany({
    where, orderBy: { date: 'desc' }, take: 200,
    include: { staff: { include: { user: { select: { name: true } } } } },
  })
  return ok(rows, { total: rows.length })
})

/** POST /api/staff/attendance — mark attendance (upsert per staff+day). */
export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES.staff as any)
  const data = await parseBody(req, upsertSchema)
  const record = await db.staffAttendance.upsert({
    where: { staffId_date: { staffId: data.staffId, date: data.date } },
    create: { staffId: data.staffId, date: data.date, status: data.status, checkIn: data.checkIn, checkOut: data.checkOut, notes: data.notes },
    update: { status: data.status, checkIn: data.checkIn, checkOut: data.checkOut, notes: data.notes },
    include: { staff: { include: { user: { select: { name: true } } } } },
  })
  await audit(req, session, 'CREATE', 'StaffAttendance', record.id, `${record.staff.user.name} ${data.date}: ${data.status}`)
  return ok(record, undefined, 201)
})
