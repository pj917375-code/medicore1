import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { staffUpdateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'

export const GET = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  requireAuth(req)
  const staff = await db.staff.findUnique({
    where: { id },
    include: {
      user: { select: { name: true, email: true, phone: true, role: true, isActive: true } },
      attendance: { orderBy: { date: 'desc' }, take: 30 },
    },
  })
  if (!staff) throw new ApiError(404, 'Staff member not found')
  return ok(staff)
})

export const PUT = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.staff as any)
  const data = await parseBody(req, staffUpdateSchema)
  const staff = await db.staff.update({ where: { id }, data, include: { user: true } })
  await audit(req, session, 'UPDATE', 'Staff', id)
  return ok(staff)
})

export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.staff as any)
  const staff = await db.staff.findUnique({ where: { id } })
  if (!staff) throw new ApiError(404, 'Staff member not found')
  await db.staff.delete({ where: { id } })
  await db.user.update({ where: { id: staff.userId }, data: { isActive: false } })
  await audit(req, session, 'DELETE', 'Staff', id)
  return ok({ id })
})
