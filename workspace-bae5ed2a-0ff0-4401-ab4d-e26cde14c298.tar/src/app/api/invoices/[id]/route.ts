import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers, withId } from '@/lib/crud'
import { invoiceUpdateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'

const handlers = createCrudHandlers({
  delegate: db.invoice,
  resource: 'Invoice',
  searchFields: ['invoiceNo'],
  include: {
    patient: { select: { id: true, firstName: true, lastName: true, code: true, email: true } },
    payments: true,
  },
  writeRoles: WRITE_ROLES.invoices as any,
  updateSchema: invoiceUpdateSchema,
})

export const GET = withId(handlers).GET
export const PUT = withId(handlers).PUT
export const DELETE = withId(handlers).DELETE
