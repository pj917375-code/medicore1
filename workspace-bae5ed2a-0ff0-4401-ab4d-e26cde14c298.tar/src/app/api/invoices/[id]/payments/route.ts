import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { paymentSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit, notify } from '@/lib/services'

/**
 * POST /api/invoices/:id/payments — record a payment transactionally,
 * auto-updating invoice status (PAID / PARTIALLY_PAID).
 */
export const POST = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.payments as any)
  const data = await parseBody(req, paymentSchema.omit({ invoiceId: true }))
  const invoice = await db.invoice.findUnique({ where: { id }, include: { patient: true } })
  if (!invoice) throw new ApiError(404, 'Invoice not found')
  if (invoice.status === 'CANCELLED') throw new ApiError(400, 'Cannot pay a cancelled invoice')
  const remaining = +(invoice.total - invoice.amountPaid).toFixed(2)
  if (data.amount > remaining + 0.01) throw new ApiError(400, `Amount exceeds outstanding balance ($${remaining})`)

  const result = await db.$transaction(async (tx) => {
    const payment = await tx.payment.create({
      data: {
        invoiceId: id, amount: data.amount, method: data.method,
        reference: data.reference || `TXN-${Date.now().toString().slice(-8)}`,
        receivedBy: session.name,
      },
    })
    const amountPaid = +(invoice.amountPaid + data.amount).toFixed(2)
    const status = amountPaid >= invoice.total - 0.01 ? 'PAID' : 'PARTIALLY_PAID'
    await tx.invoice.update({ where: { id }, data: { amountPaid, status } })
    return { payment, status, amountPaid }
  })

  await audit(req, session, 'CREATE', 'Payment', result.payment.id, `$${data.amount} on ${invoice.invoiceNo} (${data.method})`)
  await notify({
    userId: invoice.patient.userId || undefined,
    title: 'Payment received',
    message: `Payment of $${data.amount.toFixed(2)} received for invoice ${invoice.invoiceNo}.`,
    type: 'PAYMENT',
  })
  return ok({ ...result.payment, invoiceStatus: result.status, amountPaid: result.amountPaid }, undefined, 201)
})

/** GET /api/invoices/:id/payments — payment history for an invoice. */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  requireAuth(req)
  const payments = await db.payment.findMany({ where: { invoiceId: id }, orderBy: { paidAt: 'desc' } })
  return ok(payments)
})
