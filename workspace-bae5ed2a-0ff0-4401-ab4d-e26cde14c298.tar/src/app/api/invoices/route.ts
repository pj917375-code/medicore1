import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, buildWhere, parseBody, handler } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { invoiceSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit, notify } from '@/lib/services'

/** GET /api/invoices — billing list; patients see only their own invoices. */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['status', 'patientId'].includes(k)) filters[k] = v
  }
  let extra: Record<string, unknown> = {}
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    extra = { patientId: patient?.id || 'none' }
  }
  const where = buildWhere(['invoiceNo', 'notes'], q.search, filters, extra)
  const [total, rows] = await Promise.all([
    db.invoice.count({ where }),
    db.invoice.findMany({
      where, orderBy: { createdAt: 'desc' },
      include: {
        patient: { select: { id: true, firstName: true, lastName: true, code: true } },
        payments: true,
      },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})

/** POST /api/invoices — create invoice with line items. */
export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES.invoices as any)
  const data = await parseBody(req, invoiceSchema)
  const subtotal = data.items.reduce((s: number, it: any) => s + it.quantity * it.unitPrice, 0)
  const tax = data.tax || 0
  const total = +(subtotal + tax).toFixed(2)
  const count = await db.invoice.count()
  const inv = await db.invoice.create({
    data: {
      invoiceNo: `INV-${String(count + 1).padStart(6, '0')}`,
      patientId: data.patientId,
      items: JSON.stringify(data.items),
      subtotal: +subtotal.toFixed(2), tax, total,
      dueDate: data.dueDate || null, notes: data.notes,
    },
    include: { patient: { select: { firstName: true, lastName: true, code: true } } },
  })
  await audit(req, session, 'CREATE', 'Invoice', inv.id, `${inv.invoiceNo} — $${total}`)
  await notify({
    userId: (await db.patient.findUnique({ where: { id: data.patientId } }))?.userId || undefined,
    title: 'Invoice generated',
    message: `Invoice ${inv.invoiceNo} of $${total} has been issued to your account.`,
    type: 'PAYMENT',
  })
  return ok(inv, undefined, 201)
})
