import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers, withId } from '@/lib/crud'
import { patientSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { hashPassword } from '@/lib/auth'
import { ok, parseBody, ApiError, handler } from '@/lib/api'

const handlers = createCrudHandlers({
  delegate: db.patient,
  resource: 'Patient',
  searchFields: ['firstName', 'lastName', 'code'],
  include: {
    user: { select: { email: true, isActive: true } },
    appointments: { orderBy: { scheduledAt: 'desc' }, take: 5, include: { doctor: { include: { user: { select: { name: true } } } } } },
    medicalRecords: { orderBy: { createdAt: 'desc' }, take: 10, include: { doctor: { include: { user: { select: { name: true } } } } } },
    prescriptions: { orderBy: { createdAt: 'desc' }, take: 10 },
    labTests: { orderBy: { requestedAt: 'desc' }, take: 10, include: { result: true } },
    invoices: { orderBy: { createdAt: 'desc' }, take: 10 },
    admissions: { orderBy: { admittedAt: 'desc' }, take: 5, include: { bed: { include: { ward: true } }, doctor: { include: { user: { select: { name: true } } } } } },
    documents: { select: { id: true, name: true, category: true, size: true, createdAt: true } },
  },
  writeRoles: WRITE_ROLES.patients as any,
  updateSchema: patientSchema.partial(),
})

const dynamic = withId(handlers)

export const GET = dynamic.GET
export const PUT = async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const body = await req.json()
  // Optional: create a portal login for this patient
  if (body.createLogin && body.password) {
    const patient = await db.patient.findUnique({ where: { id }, include: { user: true } })
    if (!patient) throw new ApiError(404, 'Record not found')
    if (patient.user) throw new ApiError(409, 'This patient already has a portal account')
    const email = body.email || `${patient.firstName}.${patient.lastName}.p${patient.code}@medicore.local`
    const user = await db.user.create({
      data: {
        email: email.toLowerCase(), name: `${patient.firstName} ${patient.lastName}`,
        role: 'PATIENT', passwordHash: await hashPassword(body.password),
      },
    })
    await db.patient.update({ where: { id }, data: { userId: user.id } })
    return ok({ message: 'Portal account created', email })
  }
  return dynamic.PUT(req, ctx)
}
export const DELETE = dynamic.DELETE
