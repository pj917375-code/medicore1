import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { createCrudHandlers } from '@/lib/crud'
import { patientSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { notify } from '@/lib/services'
import { z } from 'zod'

const createSchema = patientSchema
  .extend({
    createLogin: z.boolean().optional(),
    password: z.string().min(8).optional(),
  })
  .transform(({ createLogin, password, ...rest }) => rest) // strip non-model fields before Prisma

const handlers = createCrudHandlers({
  delegate: db.patient,
  resource: 'Patient',
  autoCode: { field: 'code', prefix: 'P' },
  searchFields: ['firstName', 'lastName', 'code', 'phone', 'email'],
  filterFields: ['gender', 'status'],
  include: { user: { select: { email: true, isActive: true } } },
  readRoles: undefined, // any authenticated staff; PATIENT access handled via route below
  writeRoles: WRITE_ROLES.patients as any,
  createSchema,
  updateSchema: patientSchema.partial(),
  afterCreate: async (row: any) => {
    await notify({
      targetRoles: ['ADMIN', 'RECEPTIONIST'],
      title: 'New patient registered',
      message: `${row.firstName} ${row.lastName} (${row.code}) has been registered.`,
      type: 'PATIENT',
    })
  },
})

export const GET = handlers.GET_list
export const POST = handlers.POST
