import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { departmentSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'

export const PUT = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.wards as any)
  const data = await parseBody(req, departmentSchema.partial())
  const dept = await db.department.update({ where: { id }, data })
  await audit(req, session, 'UPDATE', 'Department', id)
  return ok(dept)
})

export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.wards as any)
  const doctors = await db.doctor.count({ where: { departmentId: id } })
  if (doctors > 0) throw new ApiError(400, 'Cannot delete a department that still has doctors assigned')
  await db.department.delete({ where: { id } })
  await audit(req, session, 'DELETE', 'Department', id)
  return ok({ id })
})
