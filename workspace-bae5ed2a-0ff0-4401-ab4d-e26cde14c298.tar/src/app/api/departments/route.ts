import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { departmentSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'

export const GET = handler(async (req: NextRequest) => {
  requireAuth(req)
  const q = parseQuery(req.url)
  const where = q.search ? { name: { contains: q.search } } : {}
  const rows = await db.department.findMany({
    where, orderBy: { name: 'asc' },
    include: { _count: { select: { doctors: true, appointments: true } } },
  })
  return ok(rows, { total: rows.length })
})

export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES.wards as any)
  const data = await parseBody(req, departmentSchema)
  const dept = await db.department.create({ data })
  await audit(req, session, 'CREATE', 'Department', dept.id, dept.name)
  return ok(dept, undefined, 201)
})
