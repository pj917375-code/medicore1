import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { audit } from '@/lib/services'
import { z } from 'zod'

const MAX_SIZE = 5 * 1024 * 1024 // 5 MB
const ALLOWED = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp']

const uploadSchema = z.object({
  patientId: z.string().min(1),
  name: z.string().min(1).max(200),
  category: z.enum(['REPORT', 'SCAN', 'PRESCRIPTION', 'OTHER']).default('REPORT'),
  mimeType: z.string(),
  dataBase64: z.string().max(MAX_SIZE * 1.4), // base64 overhead ~1.37x
})

/** GET /api/documents?patientId=... — list medical documents (metadata only). */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const patientId = new URL(req.url).searchParams.get('patientId')
  let where: Record<string, string> = {}
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    where = { patientId: patient?.id || 'none' }
  } else if (patientId) {
    where = { patientId }
  } else {
    throw new ApiError(400, 'patientId query parameter is required')
  }
  const rows = await db.medicalDocument.findMany({
    where,
    select: { id: true, patientId: true, name: true, category: true, mimeType: true, size: true, createdAt: true },
    orderBy: { createdAt: 'desc' },
  })
  return ok(rows, { total: rows.length })
})

/**
 * POST /api/documents — secure upload (base64 payload in demo; swap for
 * Cloudinary/S3 by replacing the storage call).
 */
export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, ['SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'NURSE', 'RECEPTIONIST'] as any)
  const data = await parseBody(req, uploadSchema)
  const size = Math.floor((data.dataBase64.length * 3) / 4)
  if (size > MAX_SIZE) throw new ApiError(413, 'File exceeds the 5 MB limit')
  if (!ALLOWED.includes(data.mimeType)) throw new ApiError(415, 'Only PDF, PNG, JPEG and WebP files are allowed')
  const patient = await db.patient.findUnique({ where: { id: data.patientId } })
  if (!patient) throw new ApiError(404, 'Patient not found')

  const doc = await db.medicalDocument.create({
    data: {
      patientId: data.patientId, name: data.name, category: data.category,
      mimeType: data.mimeType, size, data: data.dataBase64, uploadedBy: session.name,
    },
    select: { id: true, name: true, category: true, size: true, createdAt: true },
  })
  await audit(req, session, 'UPLOAD', 'MedicalDocument', doc.id, `${doc.name} for ${patient.code}`)
  return ok(doc, undefined, 201)
})
