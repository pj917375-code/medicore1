import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, handler, ApiError, fail } from '@/lib/api'
import { requireAuth } from '@/lib/auth'
import { audit } from '@/lib/services'

/** GET /api/documents/:id — download document content (access-controlled). */
export const GET = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req)
  const doc = await db.medicalDocument.findUnique({ where: { id } })
  if (!doc) throw new ApiError(404, 'Document not found')
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    if (patient?.id !== doc.patientId) throw new ApiError(403, 'Access denied')
  }
  const buf = Buffer.from(doc.data, 'base64')
  return new Response(new Uint8Array(buf), {
    headers: {
      'Content-Type': doc.mimeType,
      'Content-Disposition': `inline; filename="${doc.name.replace(/"/g, '')}"`,
    },
  })
})

/** DELETE /api/documents/:id — remove a document. */
export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, ['SUPER_ADMIN', 'ADMIN', 'DOCTOR'] as any)
  const doc = await db.medicalDocument.delete({ where: { id } })
  await audit(req, session, 'DELETE', 'MedicalDocument', id, doc.name)
  return ok({ id })
})
