import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, buildWhere, handler } from '@/lib/api'
import { requireAuth } from '@/lib/auth'

/** GET /api/payments — all payment transactions (revenue reporting). */
export const GET = handler(async (req: NextRequest) => {
  const session = requireAuth(req)
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['method'].includes(k)) filters[k] = v
  }
  let extra: Record<string, unknown> = {}
  if (session.role === 'PATIENT') {
    const patient = await db.patient.findUnique({ where: { userId: session.userId } })
    extra = { invoice: { patientId: patient?.id || 'none' } }
  }
  const where = buildWhere(['reference'], q.search, filters, extra)
  const [total, rows] = await Promise.all([
    db.payment.count({ where }),
    db.payment.findMany({
      where, orderBy: { paidAt: 'desc' },
      include: { invoice: { include: { patient: { select: { firstName: true, lastName: true, code: true } } } } },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})
