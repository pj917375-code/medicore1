import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseBody, handler, ApiError } from '@/lib/api'
import { requireAuth, hashPassword } from '@/lib/auth'
import { userUpdateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'

export const GET = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  requireAuth(req, WRITE_ROLES.users as any)
  const user = await db.user.findUnique({
    where: { id },
    select: { id: true, email: true, name: true, role: true, phone: true, isActive: true, lastLoginAt: true, createdAt: true },
  })
  if (!user) throw new ApiError(404, 'User not found')
  return ok(user)
})

export const PUT = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.users as any)
  const data = await parseBody(req, userUpdateSchema)
  const payload: Record<string, unknown> = {
    name: data.name, role: data.role, phone: data.phone,
    isActive: data.isActive,
  }
  if (data.password) payload.passwordHash = await hashPassword(data.password)
  // Prevent self-deactivation
  if (id === session.userId && data.isActive === false) throw new ApiError(400, 'You cannot deactivate your own account')
  const user = await db.user.update({
    where: { id }, data: payload,
    select: { id: true, email: true, name: true, role: true, phone: true, isActive: true },
  })
  await audit(req, session, 'UPDATE', 'User', id)
  return ok(user)
})

export const DELETE = handler(async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params
  const session = requireAuth(req, WRITE_ROLES.users as any)
  if (id === session.userId) throw new ApiError(400, 'You cannot delete your own account')
  await db.user.update({ where: { id }, data: { isActive: false } })
  await audit(req, session, 'DELETE', 'User', id, 'Deactivated')
  return ok({ id })
})
