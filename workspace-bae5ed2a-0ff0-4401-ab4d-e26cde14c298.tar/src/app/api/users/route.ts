import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, parseQuery, parseBody, buildWhere, handler, ApiError } from '@/lib/api'
import { requireAuth, hashPassword, passwordIssues } from '@/lib/auth'
import { userCreateSchema } from '@/lib/schemas'
import { WRITE_ROLES } from '@/lib/rbac'
import { audit } from '@/lib/services'

/** GET /api/users — admin user directory. */
export const GET = handler(async (req: NextRequest) => {
  requireAuth(req, WRITE_ROLES.users as any)
  const q = parseQuery(req.url)
  const filters: Record<string, string> = {}
  for (const [k, v] of Object.entries(q.filters)) {
    if (['role'].includes(k)) filters[k] = v
  }
  const where = buildWhere(['name', 'email'], q.search, filters)
  const [total, rows] = await Promise.all([
    db.user.count({ where }),
    db.user.findMany({
      where, orderBy: { createdAt: 'desc' },
      select: { id: true, email: true, name: true, role: true, phone: true, isActive: true, lastLoginAt: true, createdAt: true },
      skip: (q.page - 1) * q.pageSize, take: q.pageSize,
    }),
  ])
  return ok(rows, { page: q.page, pageSize: q.pageSize, total, totalPages: Math.max(1, Math.ceil(total / q.pageSize)) })
})

/** POST /api/users — create a staff/system user. */
export const POST = handler(async (req: NextRequest) => {
  const session = requireAuth(req, WRITE_ROLES.users as any)
  const data = await parseBody(req, userCreateSchema)
  const issue = passwordIssues(data.password)
  if (issue) throw new ApiError(422, issue)
  const existing = await db.user.findUnique({ where: { email: data.email.toLowerCase() } })
  if (existing) throw new ApiError(409, 'A user with this email already exists')
  const user = await db.user.create({
    data: { email: data.email.toLowerCase(), name: data.name, role: data.role, phone: data.phone || null, passwordHash: await hashPassword(data.password) },
    select: { id: true, email: true, name: true, role: true, phone: true, isActive: true },
  })
  await audit(req, session, 'CREATE', 'User', user.id, `${user.name} (${user.role})`)
  return ok(user, undefined, 201)
})
