'use client'
/**
 * MediCore HMS — single-page application root.
 * Handles auth gate and client-side view routing within the `/` route.
 */
import { useEffect, useState, useCallback } from 'react'
import { useAuth } from '@/lib/client/store'
import { AppShell } from '@/components/hms/layout'
import { LoginView } from '@/views/login'
import { DashboardView } from '@/views/dashboard'
import { PatientsView } from '@/views/patients'
import { DoctorsView } from '@/views/doctors'
import { AppointmentsView } from '@/views/appointments'
import { EmrView } from '@/views/emr'
import { PrescriptionsView } from '@/views/prescriptions'
import { PharmacyView } from '@/views/pharmacy'
import { LaboratoryView } from '@/views/laboratory'
import { BillingView } from '@/views/billing'
import { BedsView } from '@/views/beds'
import { StaffView } from '@/views/staff'
import { ReportsView } from '@/views/reports'
import { NotificationsView, AuditView, UsersView, ProfileView, ApiDocsView } from '@/views/misc'
import { Loader2 } from 'lucide-react'

export default function Home() {
  const { user, loading, hydrate } = useAuth()
  const [view, setView] = useState('dashboard')

  useEffect(() => {
    hydrate()
  }, [hydrate])

  const navigate = useCallback((v: string) => {
    setView(v)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [])

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground animate-pulse-soft">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-7 w-7"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" /><path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27" /></svg>
        </div>
        <p className="text-sm font-medium text-muted-foreground">Loading MediCore HMS...</p>
      </div>
    )
  }

  if (!user) return <LoginView />

  return (
    <AppShell active={view} onNavigate={navigate}>
      {view === 'dashboard' && <DashboardView onNavigate={navigate} />}
      {view === 'patients' && <PatientsView />}
      {view === 'doctors' && <DoctorsView />}
      {view === 'appointments' && <AppointmentsView />}
      {view === 'emr' && <EmrView />}
      {view === 'prescriptions' && <PrescriptionsView />}
      {view === 'pharmacy' && <PharmacyView />}
      {view === 'laboratory' && <LaboratoryView />}
      {view === 'billing' && <BillingView />}
      {view === 'beds' && <BedsView />}
      {view === 'staff' && <StaffView />}
      {view === 'reports' && <ReportsView />}
      {view === 'notifications' && <NotificationsView />}
      {view === 'users' && <UsersView />}
      {view === 'audit' && <AuditView />}
      {view === 'docs' && <ApiDocsView />}
      {view === 'profile' && <ProfileView />}
    </AppShell>
  )
}
