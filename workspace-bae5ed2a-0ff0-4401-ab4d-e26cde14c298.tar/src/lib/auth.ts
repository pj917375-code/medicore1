/**
 * Authentication: bcrypt password hashing, JWT issuing/verification,
 * session extraction from httpOnly cookie or Bearer header.
 */
import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import { NextRequest } from 'next/server'
import { ApiError } from './api'
import { ROLE_PERMISSIONS, type Role } from './rbac'

const JWT_SECRET = process.env.JWT_SECRET || 'medicore-dev-secret-change-in-production'
export const TOKEN_COOKIE = 'hms_token'
const TOKEN_TTL = '8h' // session expiration

export interface Session {
  userId: string
  email: string
  name: string
  role: Role
}

export const hashPassword = (pw: string) => bcrypt.hash(pw, 10)
export const verifyPassword = (pw: string, hash: string) => bcrypt.compare(pw, hash)

export function signToken(payload: Session): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_TTL })
}

export function verifyToken(token: string): Session | null {
  try {
    return jwt.verify(token, JWT_SECRET) as Session
  } catch {
    return null
  }
}

function extractToken(req: NextRequest): string | null {
  const auth = req.headers.get('authorization')
  if (auth?.startsWith('Bearer ')) return auth.slice(7)
  return req.cookies.get(TOKEN_COOKIE)?.value || null
}

export function getSession(req: NextRequest): Session | null {
  const token = extractToken(req)
  return token ? verifyToken(token) : null
}

/** Throws 401/403 unless the caller has one of the allowed roles. */
export function requireAuth(req: NextRequest, allowed?: Role[]): Session {
  const session = getSession(req)
  if (!session) throw new ApiError(401, 'Authentication required. Please sign in.')
  if (allowed && allowed.length && !allowed.includes(session.role)) {
    throw new ApiError(403, 'You do not have permission to perform this action')
  }
  return session
}

/** Permission matrix check — modules the role can access. */
export function can(session: Session, module: string): boolean {
  const perms = ROLE_PERMISSIONS[session.role]
  return !!perms?.includes(module)
}

export function setAuthCookie(response: Response, token: string) {
  response.headers.append(
    'Set-Cookie',
    `${TOKEN_COOKIE}=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${8 * 60 * 60}${
      process.env.NODE_ENV === 'production' ? '; Secure' : ''
    }`
  )
}

export function clearAuthCookie(response: Response) {
  response.headers.append('Set-Cookie', `${TOKEN_COOKIE}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0`)
}

export function passwordIssues(pw: string): string | null {
  if (pw.length < 8) return 'Password must be at least 8 characters'
  if (!/[A-Z]/.test(pw)) return 'Password must contain an uppercase letter'
  if (!/[0-9]/.test(pw)) return 'Password must contain a number'
  return null
}
