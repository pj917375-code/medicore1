/**
 * API framework: standardized responses, centralized error handling,
 * pagination/query parsing, and rate limiting.
 */
import { NextRequest } from 'next/server'
import { ZodError, ZodSchema } from 'zod'

export class ApiError extends Error {
  status: number
  details?: unknown
  constructor(status: number, message: string, details?: unknown) {
    super(message)
    this.status = status
    this.details = details
  }
}

export const ok = (data: unknown, meta?: unknown, status = 200) =>
  Response.json({ success: true, data, ...(meta ? { meta } : {}) }, { status })

export const fail = (status: number, message: string, details?: unknown) =>
  Response.json({ success: false, error: { message, details } }, { status })

export function handleError(e: unknown) {
  if (e instanceof ApiError) return fail(e.status, e.message, e.details)
  if (e instanceof ZodError) {
    const issues = e.issues.map((i) => ({ path: i.path.join('.'), message: i.message }))
    return fail(422, 'Validation failed', issues)
  }
  const msg = e instanceof Error ? e.message : 'Internal server error'
  if (msg.includes('Unique constraint')) return fail(409, 'A record with the same unique value already exists')
  if (msg.includes('Record to update not found') || msg.includes('No record was found')) return fail(404, 'Record not found')
  console.error('[API]', e)
  return fail(500, 'Internal server error')
}

/** Wrap a route handler with centralized error handling. */
export function handler(fn: (req: NextRequest, ctx: any) => Promise<Response>) {
  return async (req: NextRequest, ctx: any) => {
    try {
      return await fn(req, ctx)
    } catch (e) {
      return handleError(e)
    }
  }
}

export async function parseBody<T>(req: NextRequest, schema: ZodSchema<T>): Promise<T> {
  let json: unknown
  try {
    json = await req.json()
  } catch {
    throw new ApiError(400, 'Invalid JSON body')
  }
  return schema.parse(json)
}

export function parseQuery(url: string) {
  const sp = new URL(url).searchParams
  const page = Math.max(1, parseInt(sp.get('page') || '1') || 1)
  const pageSize = Math.min(100, Math.max(1, parseInt(sp.get('pageSize') || '10') || 10))
  const search = sp.get('search')?.trim() || ''
  const sortBy = sp.get('sortBy') || 'createdAt'
  const sortOrder = sp.get('sortOrder') === 'asc' ? 'asc' : 'desc'
  const filters: Record<string, string> = {}
  sp.forEach((v, k) => {
    if (!['page', 'pageSize', 'search', 'sortBy', 'sortOrder'].includes(k) && v) filters[k] = v
  })
  const since = sp.get('since')
  return { page, pageSize, search, sortBy, sortOrder, filters, since, sp }
}

/** Build a Prisma where clause: search over text fields + equality filters. */
export function buildWhere(searchFields: string[], search: string, filters: Record<string, string>, extra: Record<string, unknown> = {}) {
  const where: Record<string, unknown> = { ...extra }
  if (search) {
    where.OR = searchFields.map((f) => ({ [f]: { contains: search } }))
  }
  for (const [k, v] of Object.entries(filters)) {
    if (k.endsWith('Id') || ['status', 'role', 'gender', 'category', 'type', 'priority', 'shift', 'method', 'visitType', 'testName'].includes(k) || k === 'departmentId' || k === 'wardId') {
      where[k] = v
    } else {
      where[k] = { contains: v }
    }
  }
  return where
}

// ---- naive in-memory rate limiter (per IP + route bucket) ----
const buckets = new Map<string, { count: number; resetAt: number }>()
export function rateLimit(req: NextRequest, bucket: string, limit = 120, windowMs = 60_000) {
  const key = `${bucket}:${req.headers.get('x-forwarded-for') || 'local'}`
  const now = Date.now()
  const b = buckets.get(key)
  if (!b || b.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs })
    return
  }
  b.count++
  if (b.count > limit) throw new ApiError(429, 'Too many requests. Please slow down.')
}
