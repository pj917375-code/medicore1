/**
 * Cross-cutting services: audit logging, notifications (persisted +
 * real-time via Socket.IO service), and entity code generation.
 */
import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getSession, type Session } from './auth'

export async function audit(
  req: NextRequest,
  session: Session | null,
  action: string,
  entity: string,
  entityId?: string,
  details?: string
) {
  try {
    const s = session || getSession(req)
    await db.auditLog.create({
      data: {
        userId: s?.userId, userName: s?.name, action, entity, entityId,
        details: details?.slice(0, 500),
        ip: req.headers.get('x-forwarded-for') || 'local',
      },
    })
  } catch (e) {
    console.error('[audit] failed', e)
  }
}

export async function notify(input: {
  userId?: string | null
  targetRoles?: string[] | null
  title: string
  message: string
  type?: string
}) {
  try {
    await db.notification.create({
      data: {
        userId: input.userId || null,
        targetRoles: input.targetRoles?.join(',') || null,
        title: input.title, message: input.message,
        type: input.type || 'SYSTEM',
      },
    })
    // The Socket.IO notification service (mini-services/notification-service)
    // polls this table and pushes new rows to connected clients in real time.
  } catch (e) {
    console.error('[notify] failed', e)
  }
}

const counters = new Map<string, number>()
/** Generate a human-friendly entity code, e.g. P-000123 / RX-000045. */
export async function generateCode(
  prefix: string,
  countFn: () => Promise<number>
): Promise<string> {
  const n = (await countFn()) + 1
  return `${prefix}-${String(n).padStart(6, '0')}`
}
