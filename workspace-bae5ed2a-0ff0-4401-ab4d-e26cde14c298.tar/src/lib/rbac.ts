/**
 * Role-Based Access Control — the single source of truth shared by
 * backend route guards and the frontend navigation.
 */

export const ROLES = [
  'SUPER_ADMIN',
  'ADMIN',
  'DOCTOR',
  'NURSE',
  'RECEPTIONIST',
  'PHARMACIST',
  'LAB_TECHNICIAN',
  'PATIENT',
] as const

export type Role = (typeof ROLES)[number]

export const MODULES = [
  'dashboard',
  'patients',
  'doctors',
  'appointments',
  'emr',
  'prescriptions',
  'pharmacy',
  'laboratory',
  'billing',
  'beds',
  'staff',
  'reports',
  'notifications',
  'audit',
  'users',
  'profile',
  'docs',
] as const

export type Module = (typeof MODULES)[number]

// Which modules each role can see/use
export const ROLE_PERMISSIONS: Record<Role, readonly Module[]> = {
  SUPER_ADMIN: ['dashboard', 'patients', 'doctors', 'appointments', 'emr', 'prescriptions', 'pharmacy', 'laboratory', 'billing', 'beds', 'staff', 'reports', 'notifications', 'audit', 'users', 'profile', 'docs'],
  ADMIN: ['dashboard', 'patients', 'doctors', 'appointments', 'emr', 'prescriptions', 'pharmacy', 'laboratory', 'billing', 'beds', 'staff', 'reports', 'notifications', 'audit', 'users', 'profile', 'docs'],
  DOCTOR: ['dashboard', 'patients', 'appointments', 'emr', 'prescriptions', 'laboratory', 'beds', 'reports', 'notifications', 'profile', 'docs'],
  NURSE: ['dashboard', 'patients', 'appointments', 'emr', 'beds', 'laboratory', 'notifications', 'profile', 'docs'],
  RECEPTIONIST: ['dashboard', 'patients', 'doctors', 'appointments', 'billing', 'beds', 'notifications', 'profile', 'docs'],
  PHARMACIST: ['dashboard', 'prescriptions', 'pharmacy', 'notifications', 'profile', 'docs'],
  LAB_TECHNICIAN: ['dashboard', 'laboratory', 'patients', 'notifications', 'profile', 'docs'],
  PATIENT: ['dashboard', 'appointments', 'emr', 'prescriptions', 'laboratory', 'billing', 'notifications', 'profile', 'docs'],
}

export const ROLE_LABELS: Record<Role, string> = {
  SUPER_ADMIN: 'Super Administrator',
  ADMIN: 'Hospital Administrator',
  DOCTOR: 'Doctor',
  NURSE: 'Nurse',
  RECEPTIONIST: 'Receptionist',
  PHARMACIST: 'Pharmacist',
  LAB_TECHNICIAN: 'Lab Technician',
  PATIENT: 'Patient',
}

/** Write-operation role gates per API resource (enforced server-side). */
export const WRITE_ROLES = {
  patients: ['SUPER_ADMIN', 'ADMIN', 'RECEPTIONIST', 'DOCTOR'],
  doctors: ['SUPER_ADMIN', 'ADMIN'],
  appointments: ['SUPER_ADMIN', 'ADMIN', 'RECEPTIONIST', 'DOCTOR', 'PATIENT'],
  'medical-records': ['SUPER_ADMIN', 'ADMIN', 'DOCTOR'],
  prescriptions: ['SUPER_ADMIN', 'ADMIN', 'DOCTOR'],
  'prescriptions-dispense': ['SUPER_ADMIN', 'ADMIN', 'PHARMACIST'],
  medicines: ['SUPER_ADMIN', 'ADMIN', 'PHARMACIST'],
  'lab-tests': ['SUPER_ADMIN', 'ADMIN', 'DOCTOR'],
  'lab-results': ['SUPER_ADMIN', 'ADMIN', 'LAB_TECHNICIAN'],
  'lab-review': ['SUPER_ADMIN', 'ADMIN', 'DOCTOR'],
  invoices: ['SUPER_ADMIN', 'ADMIN', 'RECEPTIONIST'],
  payments: ['SUPER_ADMIN', 'ADMIN', 'RECEPTIONIST'],
  beds: ['SUPER_ADMIN', 'ADMIN', 'NURSE'],
  wards: ['SUPER_ADMIN', 'ADMIN'],
  admissions: ['SUPER_ADMIN', 'ADMIN', 'NURSE', 'DOCTOR'],
  staff: ['SUPER_ADMIN', 'ADMIN'],
  users: ['SUPER_ADMIN', 'ADMIN'],
} as const
