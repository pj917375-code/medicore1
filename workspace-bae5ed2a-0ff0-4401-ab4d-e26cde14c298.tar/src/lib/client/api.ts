'use client'
/**
 * Typed fetch wrapper for the HMS REST API.
 * Relative paths only; attaches the JWT from localStorage as Bearer
 * (cookie is also set server-side).
 */
export interface ApiMeta {
  page: number
  pageSize: number
  total: number
  totalPages: number
  unread?: number
}

export class ApiClientError extends Error {
  status: number
  details?: unknown
  constructor(status: number, message: string, details?: unknown) {
    super(message)
    this.status = status
    this.details = details
  }
}

const TOKEN_KEY = 'hms_token'

export const getToken = () => (typeof window !== 'undefined' ? localStorage.getItem(TOKEN_KEY) : null)
export const setToken = (t: string) => localStorage.setItem(TOKEN_KEY, t)
export const clearToken = () => localStorage.removeItem(TOKEN_KEY)

export async function api<T = any>(
  path: string,
  options: RequestInit & { silent?: boolean } = {}
): Promise<{ data: T; meta?: ApiMeta }> {
  const token = getToken()
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers as Record<string, string>),
  }
  const res = await fetch(path, { ...options, headers })
  let json: any = null
  try {
    json = await res.json()
  } catch {
    throw new ApiClientError(res.status, 'Unexpected server response')
  }
  if (!res.ok || !json?.success) {
    const message = json?.error?.message || `Request failed (${res.status})`
    throw new ApiClientError(res.status, message, json?.error?.details)
  }
  return { data: json.data, meta: json.meta }
}

/** List query builder. */
export function qs(params: Record<string, string | number | undefined>) {
  const sp = new URLSearchParams()
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== '') sp.set(k, String(v))
  }
  const s = sp.toString()
  return s ? `?${s}` : ''
}

export const money = (n: number | null | undefined) =>
  `$${(n ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`

export const fmtDate = (d: string | Date | null | undefined) =>
  d ? new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—'

export const fmtDateTime = (d: string | Date | null | undefined) =>
  d
    ? new Date(d).toLocaleString('en-US', {
        month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit',
      })
    : '—'

export const fmtTime = (d: string | Date | null | undefined) =>
  d ? new Date(d).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }) : '—'

export const fullName = (p?: { firstName?: string; lastName?: string; name?: string } | null) =>
  p?.firstName ? `${p.firstName} ${p.lastName}` : p?.name || '—'
