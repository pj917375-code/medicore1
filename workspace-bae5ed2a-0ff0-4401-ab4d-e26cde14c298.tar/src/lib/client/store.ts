'use client'
/**
 * Client auth store (Zustand) — session user + hydrate from API on boot.
 */
import { create } from 'zustand'
import { api, getToken, setToken, clearToken } from './api'
import type { Role } from '@/lib/rbac'

export interface AuthUser {
  id: string
  email: string
  name: string
  role: Role
  phone?: string | null
  avatarColor?: string
}

interface AuthState {
  user: AuthUser | null
  loading: boolean
  setUser: (u: AuthUser | null) => void
  login: (email: string, password: string) => Promise<AuthUser>
  register: (email: string, name: string, password: string, phone?: string) => Promise<AuthUser>
  logout: () => Promise<void>
  hydrate: () => Promise<void>
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  loading: true,
  setUser: (u) => set({ user: u, loading: false }),

  login: async (email, password) => {
    const { data } = await api<{ token: string; user: AuthUser }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    })
    setToken(data.token)
    set({ user: data.user, loading: false })
    return data.user
  },

  register: async (email, name, password, phone) => {
    const { data } = await api<{ token: string; user: AuthUser }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, name, password, phone }),
    })
    setToken(data.token)
    set({ user: data.user, loading: false })
    return data.user
  },

  logout: async () => {
    try {
      await api('/api/auth/logout', { method: 'POST' })
    } catch {}
    clearToken()
    set({ user: null, loading: false })
  },

  hydrate: async () => {
    if (!getToken()) {
      set({ loading: false })
      return
    }
    try {
      const { data } = await api<AuthUser>('/api/auth/me')
      set({ user: data as AuthUser, loading: false })
    } catch {
      clearToken()
      set({ user: null, loading: false })
    }
  },
}))
