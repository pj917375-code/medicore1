/**
 * Generic CRUD route factory with pagination, search, filtering, sorting,
 * role-based authorization, audit logging, and relational includes.
 * Every resource route composes this to keep behavior consistent.
 */
import { NextRequest } from 'next/server'
import { ZodSchema } from 'zod'
import { db } from '@/lib/db'
import { ok, parseBody, parseQuery, buildWhere, ApiError, rateLimit, handler } from './api'
import { requireAuth } from './auth'
import type { Role } from './rbac'
import { audit } from './services'

export interface CrudConfig {
  delegate: any // Prisma model delegate (e.g. db.patient)
  resource: string // audit entity name
  searchFields: string[]
  filterFields?: string[]
  include?: Record<string, boolean | object>
  readRoles?: Role[]
  writeRoles?: Role[]
  createSchema?: ZodSchema<any>
  updateSchema?: ZodSchema<any>
  autoCode?: { field: string; prefix: string } // generate PREFIX-000001 on create
  softDelete?: string // field name to set instead of hard delete
  afterCreate?: (row: any, session: any) => Promise<void>
  afterUpdate?: (row: any, session: any) => Promise<void>
  orderBy?: Record<string, string>
}

export function createCrudHandlers(cfg: CrudConfig) {
  const whereFor = (req: NextRequest) => {
    const q = parseQuery(req.url)
    const filters: Record<string, string> = {}
    for (const [k, v] of Object.entries(q.filters)) {
      if (cfg.filterFields?.includes(k)) filters[k] = v
    }
    return { q, where: buildWhere(cfg.searchFields, q.search, filters) }
  }

  async function list(req: NextRequest) {
    const session = requireAuth(req, cfg.readRoles)
    rateLimit(req, 'list', 300)
    const { q, where } = whereFor(req)
    const [total, rows] = await Promise.all([
      cfg.delegate.count({ where }),
      cfg.delegate.findMany({
        where,
        include: cfg.include,
        orderBy: q.sortBy === 'createdAt' ? { createdAt: q.sortOrder } : { [q.sortBy]: q.sortOrder },
        skip: (q.page - 1) * q.pageSize,
        take: q.pageSize,
      }),
    ])
    return ok(rows, {
      page: q.page, pageSize: q.pageSize, total,
      totalPages: Math.max(1, Math.ceil(total / q.pageSize)),
    })
  }

  async function getOne(req: NextRequest, id: string) {
    requireAuth(req, cfg.readRoles)
    const row = await cfg.delegate.findUnique({ where: { id }, include: cfg.include })
    if (!row) throw new ApiError(404, 'Record not found')
    return ok(row)
  }

  async function create(req: NextRequest) {
    const session = requireAuth(req, cfg.writeRoles)
    rateLimit(req, 'write', 120)
    if (!cfg.createSchema) throw new ApiError(405, 'Creation not supported for this resource')
    const data = await parseBody(req, cfg.createSchema)
    if (cfg.autoCode) {
      const count = await cfg.delegate.count()
      data[cfg.autoCode.field] = `${cfg.autoCode.prefix}-${String(count + 1).padStart(6, '0')}`
    }
    const row = await cfg.delegate.create({ data, include: cfg.include })
    await audit(req, session, 'CREATE', cfg.resource, row.id)
    if (cfg.afterCreate) await cfg.afterCreate(row, session)
    return ok(row, undefined, 201)
  }

  async function update(req: NextRequest, id: string) {
    const session = requireAuth(req, cfg.writeRoles)
    rateLimit(req, 'write', 120)
    if (!cfg.updateSchema) throw new ApiError(405, 'Update not supported for this resource')
    const data = await parseBody(req, cfg.updateSchema)
    const existing = await cfg.delegate.findUnique({ where: { id } })
    if (!existing) throw new ApiError(404, 'Record not found')
    const row = await cfg.delegate.update({ where: { id }, data, include: cfg.include })
    await audit(req, session, 'UPDATE', cfg.resource, id)
    if (cfg.afterUpdate) await cfg.afterUpdate(row, session)
    return ok(row)
  }

  async function remove(req: NextRequest, id: string) {
    const session = requireAuth(req, cfg.writeRoles)
    const existing = await cfg.delegate.findUnique({ where: { id } })
    if (!existing) throw new ApiError(404, 'Record not found')
    if (cfg.softDelete) {
      await cfg.delegate.update({ where: { id }, data: { [cfg.softDelete]: 'INACTIVE' } })
    } else {
      await cfg.delegate.delete({ where: { id } })
    }
    await audit(req, session, 'DELETE', cfg.resource, id)
    return ok({ id })
  }

  return {
    GET_list: handler(list) as any,
    GET_one: handler(getOne) as any,
    POST: handler(create) as any,
    PUT: handler(update) as any,
    DELETE: handler(remove) as any,
  }
}

/** Helper for dynamic [id] route files in Next.js App Router. */
export function withId(handlers: ReturnType<typeof createCrudHandlers>) {
  return {
    GET: async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
      const { id } = await ctx.params
      return handlers.GET_one(req, id)
    },
    PUT: async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
      const { id } = await ctx.params
      return handlers.PUT(req, id)
    },
    DELETE: async (req: NextRequest, ctx: { params: Promise<{ id: string }> }) => {
      const { id } = await ctx.params
      return handlers.DELETE(req, id)
    },
  }
}
