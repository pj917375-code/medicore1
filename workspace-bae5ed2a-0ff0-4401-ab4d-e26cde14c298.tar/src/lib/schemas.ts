/**
 * Shared Zod validation schemas for every resource.
 * Applied at the API boundary; error details returned as 422.
 */
import { z } from 'zod'

const str = (min = 1, max = 500) => z.string().trim().min(min).max(max)
const optStr = (max = 500) => z.string().trim().max(max).optional().or(z.literal(''))
const num = (min?: number, max?: number) =>
  min !== undefined ? z.coerce.number().min(min).max(max ?? 1e9) : z.coerce.number()
const optNum = (min?: number) => z.coerce.number().min(min ?? -1e9).optional()
const dt = () => z.coerce.date()
const optDt = () => z.coerce.date().optional().nullable()

export const loginSchema = z.object({
  email: z.string().trim().email('Please enter a valid email address'),
  password: str(1, 100),
})

export const registerSchema = z.object({
  email: z.string().trim().email('Please enter a valid email address'),
  name: str(2, 80),
  password: str(8, 100).regex(/[A-Z]/, 'Password must contain an uppercase letter').regex(/[0-9]/, 'Password must contain a number'),
  phone: optStr(30),
})

export const changePasswordSchema = z.object({
  currentPassword: str(1, 100),
  newPassword: str(8, 100).regex(/[A-Z]/, 'Password must contain an uppercase letter').regex(/[0-9]/, 'Password must contain a number'),
})

export const forgotSchema = z.object({ email: z.string().trim().email() })
export const resetSchema = z.object({ token: str(10, 200), password: str(8, 100).regex(/[A-Z]/).regex(/[0-9]/) })

export const profileSchema = z.object({
  name: str(2, 80),
  phone: optStr(30),
  avatarColor: optStr(20),
})

export const userCreateSchema = z.object({
  email: z.string().trim().email(),
  name: str(2, 80),
  password: str(8, 100),
  role: z.enum(['SUPER_ADMIN', 'ADMIN', 'DOCTOR', 'NURSE', 'RECEPTIONIST', 'PHARMACIST', 'LAB_TECHNICIAN', 'PATIENT']),
  phone: optStr(30),
})
export const userUpdateSchema = userCreateSchema.partial().omit({ password: true }).extend({ password: str(8, 100).optional(), isActive: z.boolean().optional() })

export const patientSchema = z.object({
  firstName: str(1, 60), lastName: str(1, 60),
  dob: optDt(), gender: z.enum(['MALE', 'FEMALE', 'OTHER']).default('OTHER'),
  bloodGroup: optStr(5), phone: optStr(30), email: optStr(120), address: optStr(300),
  emergencyContactName: optStr(80), emergencyContactPhone: optStr(30),
  allergies: optStr(500), chronicConditions: optStr(500),
  insuranceProvider: optStr(100), insuranceNumber: optStr(50),
  createLogin: z.boolean().optional(), password: str(8, 100).optional(),
})
export const patientUpdateSchema = patientSchema.partial().omit({ createLogin: true, password: true })

export const doctorSchema = z.object({
  userId: str(1), code: str(1, 20).optional(), specialization: str(2, 100),
  qualification: str(2, 200), licenseNo: str(2, 50), experienceYears: num(0, 80),
  consultationFee: num(0, 100000), departmentId: str(1),
  availability: optStr(100), shiftTime: optStr(40),
  status: z.enum(['ACTIVE', 'ON_LEAVE', 'INACTIVE']).optional(),
  rating: optNum(0),
})
export const doctorUpdateSchema = doctorSchema.partial().omit({ userId: true })

export const appointmentSchema = z.object({
  patientId: str(1), doctorId: str(1), departmentId: str(1).optional().or(z.literal('')),
  scheduledAt: dt(), durationMinutes: num(5, 480).default(30),
  reason: optStr(300), notes: optStr(1000),
})
export const appointmentUpdateSchema = appointmentSchema.partial().extend({
  status: z.enum(['SCHEDULED', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'NO_SHOW']).optional(),
})

export const medicalRecordSchema = z.object({
  patientId: str(1), doctorId: str(1), appointmentId: str(1).optional().or(z.literal('')),
  visitType: z.enum(['CONSULTATION', 'FOLLOW_UP', 'EMERGENCY', 'ADMISSION']).default('CONSULTATION'),
  symptoms: optStr(1000), diagnosis: str(2, 500), treatmentPlan: optStr(1000),
  clinicalNotes: optStr(2000), bloodPressure: optStr(10),
  heartRate: optNum(0), temperature: optNum(0), weight: optNum(0),
  followUpDate: optDt(),
})
export const medicalRecordUpdateSchema = medicalRecordSchema.partial()

export const prescriptionSchema = z.object({
  patientId: str(1), doctorId: str(1), medicalRecordId: str(1).optional().or(z.literal('')),
  notes: optStr(500),
  items: z.array(z.object({
    medicineId: str(1).optional().or(z.literal('')), medicineName: str(1, 200),
    dosage: str(1, 100), frequency: str(1, 100), duration: str(1, 100),
    instructions: optStr(200),
  })).min(1, 'At least one medicine is required'),
})
export const prescriptionUpdateSchema = z.object({
  status: z.enum(['PENDING', 'DISPENSED', 'CANCELLED']).optional(),
  notes: optStr(500),
})

export const medicineSchema = z.object({
  name: str(2, 200), category: str(2, 100), manufacturer: optStr(100),
  unit: optStr(20), unitPrice: num(0), stockQty: num(0, 1000000),
  reorderLevel: num(0, 100000), batchNo: optStr(50), expiryDate: optDt(),
})
export const medicineUpdateSchema = medicineSchema.partial()

export const labTestSchema = z.object({
  patientId: str(1), doctorId: str(1), testName: str(2, 200),
  category: z.enum(['HEMATOLOGY', 'BIOCHEMISTRY', 'MICROBIOLOGY', 'RADIOLOGY', 'GENERAL']).default('GENERAL'),
  sampleType: optStr(50), priority: z.enum(['ROUTINE', 'URGENT']).default('ROUTINE'),
  notes: optStr(500),
})
export const labTestUpdateSchema = labTestSchema.partial().extend({
  status: z.enum(['REQUESTED', 'SAMPLE_COLLECTED', 'PROCESSING', 'COMPLETED', 'REVIEWED', 'CANCELLED']).optional(),
})

export const labResultSchema = z.object({
  resultSummary: str(2, 2000),
  values: z.array(z.object({
    parameter: str(1, 100), value: str(1, 50), unit: optStr(30),
    referenceRange: optStr(50), flag: z.enum(['NORMAL', 'HIGH', 'LOW', 'CRITICAL']).default('NORMAL'),
  })).optional(),
  technologist: optStr(80),
})
export const labReviewSchema = z.object({ reviewedBy: str(1, 80) })

export const invoiceSchema = z.object({
  patientId: str(1),
  items: z.array(z.object({
    description: str(1, 200), type: z.enum(['CONSULTATION', 'LABORATORY', 'PHARMACY', 'ROOM', 'PROCEDURE', 'OTHER']),
    quantity: num(1, 1000), unitPrice: num(0),
  })).min(1, 'At least one line item is required'),
  tax: num(0, 100000).default(0),
  dueDate: optDt(), notes: optStr(500),
})
export const invoiceUpdateSchema = z.object({
  status: z.enum(['UNPAID', 'PARTIALLY_PAID', 'PAID', 'CANCELLED']).optional(),
  notes: optStr(500), dueDate: optDt(),
})

export const paymentSchema = z.object({
  invoiceId: str(1), amount: num(0.01, 1e7),
  method: z.enum(['CASH', 'CARD', 'BANK_TRANSFER', 'INSURANCE', 'MOBILE_MONEY']).default('CASH'),
  reference: optStr(60),
})

export const wardSchema = z.object({ name: str(2, 80), type: str(2, 40), floor: optStr(20) })
export const bedSchema = z.object({
  wardId: str(1), bedNumber: str(1, 20), dailyRate: num(0), status: z.enum(['AVAILABLE', 'OCCUPIED', 'MAINTENANCE']).optional(),
})
export const bedUpdateSchema = z.object({
  bedNumber: str(1, 20).optional(), dailyRate: num(0).optional(),
  status: z.enum(['AVAILABLE', 'OCCUPIED', 'MAINTENANCE']).optional(),
})

export const admissionSchema = z.object({
  patientId: str(1), bedId: str(1), doctorId: str(1).optional().or(z.literal('')),
  reason: optStr(300), notes: optStr(500),
})
export const admissionUpdateSchema = z.object({
  status: z.enum(['ADMITTED', 'DISCHARGED']).optional(),
  bedId: str(1).optional(), notes: optStr(500),
})

export const staffSchema = z.object({
  email: z.string().trim().email(), name: str(2, 80), password: str(8, 100).optional(),
  role: z.enum(['DOCTOR', 'NURSE', 'RECEPTIONIST', 'PHARMACIST', 'LAB_TECHNICIAN']),
  employeeCode: str(2, 20), title: str(2, 80), department: str(2, 80),
  shift: z.enum(['MORNING', 'EVENING', 'NIGHT']).default('MORNING'),
})
export const staffUpdateSchema = z.object({
  title: str(2, 80).optional(), department: str(2, 80).optional(),
  shift: z.enum(['MORNING', 'EVENING', 'NIGHT']).optional(),
  status: z.enum(['ACTIVE', 'ON_LEAVE', 'TERMINATED']).optional(),
})

export const attendanceSchema = z.object({
  staffId: str(1), date: str(10, 10),
  status: z.enum(['PRESENT', 'ABSENT', 'LEAVE']),
  checkIn: optStr(10), checkOut: optStr(10), notes: optStr(200),
})

export const departmentSchema = z.object({
  name: str(2, 80), description: optStr(300), location: optStr(100),
})

export const notificationActionSchema = z.object({ isRead: z.boolean().optional(), markAllRead: z.boolean().optional() })
