'use client'
/**
 * Login / registration / password recovery screen.
 */
import { useState } from 'react'
import { HeartPulse, Mail, Lock, Eye, EyeOff, Loader2, UserPlus, KeyRound, Stethoscope, ShieldCheck, Activity } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useAuth } from '@/lib/client/store'
import { api } from '@/lib/client/api'
import { toast } from 'sonner'

const DEMO_ACCOUNTS = [
  { role: 'Admin', email: 'admin@medicore.com', desc: 'Hospital Administrator' },
  { role: 'Doctor', email: 'doctor@medicore.com', desc: 'Dr. Evelyn Carter' },
  { role: 'Nurse', email: 'nurse@medicore.com', desc: 'Grace Bennett' },
  { role: 'Reception', email: 'reception@medicore.com', desc: 'Front Desk' },
  { role: 'Pharmacy', email: 'pharmacist@medicore.com', desc: 'Daniel Cho' },
  { role: 'Lab Tech', email: 'lab@medicore.com', desc: 'Priya Nair' },
  { role: 'Patient', email: 'patient@medicore.com', desc: 'John Murray (portal)' },
]

export function LoginView() {
  const { login, register } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [reg, setReg] = useState({ name: '', email: '', phone: '', password: '', confirm: '' })
  const [forgotOpen, setForgotOpen] = useState(false)
  const [forgotEmail, setForgotEmail] = useState('')
  const [forgotLoading, setForgotLoading] = useState(false)

  const submitLogin = async (e?: React.FormEvent) => {
    e?.preventDefault()
    if (!email.trim()) return toast.error('Please enter your email')
    if (!password) return toast.error('Please enter your password')
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return toast.error('Please enter a valid email address')
    setLoading(true)
    try {
      const user = await login(email.trim().toLowerCase(), password)
      toast.success(`Welcome back, ${user.name}`)
    } catch (err: any) {
      toast.error(err.message || 'Sign in failed')
    } finally {
      setLoading(false)
    }
  }

  const submitRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    if (reg.name.trim().length < 2) return toast.error('Please enter your full name')
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(reg.email)) return toast.error('Please enter a valid email address')
    if (reg.password.length < 8 || !/[A-Z]/.test(reg.password) || !/[0-9]/.test(reg.password)) {
      return toast.error('Password needs 8+ characters, an uppercase letter and a number')
    }
    if (reg.password !== reg.confirm) return toast.error('Passwords do not match')
    setLoading(true)
    try {
      const user = await register(reg.email.trim().toLowerCase(), reg.name.trim(), reg.password, reg.phone || undefined)
      toast.success(`Account created. Welcome, ${user.name}!`)
    } catch (err: any) {
      toast.error(err.message || 'Registration failed')
    } finally {
      setLoading(false)
    }
  }

  const submitForgot = async () => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(forgotEmail)) return toast.error('Please enter a valid email address')
    setForgotLoading(true)
    try {
      const { data } = await api<{ message: string; demoResetLink?: string }>('/api/auth/forgot-password', {
        method: 'POST', body: JSON.stringify({ email: forgotEmail.trim().toLowerCase() }),
      })
      toast.success(data.message)
      if (data.demoResetLink) {
        console.log('Demo reset link:', data.demoResetLink)
        toast('Demo reset link', { description: 'Printed to the browser console (F12) — paste it in the address bar.', duration: 10000 })
      }
      setForgotOpen(false)
    } catch (err: any) {
      toast.error(err.message)
    } finally {
      setForgotLoading(false)
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Brand panel */}
      <div className="relative hidden flex-col justify-between overflow-hidden bg-sidebar p-10 text-sidebar-foreground lg:flex">
        <div className="pointer-events-none absolute -right-32 -top-32 h-96 w-96 rounded-full bg-teal-500/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -left-24 h-80 w-80 rounded-full bg-cyan-400/10 blur-3xl" />
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground">
            <HeartPulse className="h-6 w-6" />
          </div>
          <div>
            <p className="text-lg font-bold">MediCore HMS</p>
            <p className="text-xs uppercase tracking-widest text-sidebar-foreground/60">Premium Health Suite</p>
          </div>
        </div>
        <div className="max-w-md space-y-6">
          <h1 className="text-3xl font-bold leading-tight">
            One platform for your entire care operation.
          </h1>
          <p className="text-sidebar-foreground/70">
            Patients, appointments, EMR, pharmacy, laboratory, billing and wards — unified,
            secure and real-time.
          </p>
          <div className="space-y-4">
            {[
              { icon: ShieldCheck, t: 'Role-based access for 8 user types', d: 'JWT auth, bcrypt hashing, audit trail' },
              { icon: Activity, t: 'Live analytics & real-time alerts', d: 'Dashboards, charts and Socket.IO notifications' },
              { icon: Stethoscope, t: 'Full clinical workflow', d: 'EMR, e-prescriptions, lab pipeline, ward management' },
            ].map((f) => (
              <div key={f.t} className="flex items-start gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-sidebar-accent">
                  <f.icon className="h-4.5 w-4.5 h-[18px] w-[18px] text-teal-400" />
                </div>
                <div>
                  <p className="text-sm font-semibold">{f.t}</p>
                  <p className="text-xs text-sidebar-foreground/60">{f.d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <p className="text-xs text-sidebar-foreground/50">Demo environment — seeded sample data only</p>
      </div>

      {/* Form panel */}
      <div className="flex items-center justify-center bg-background p-6 sm:p-10">
        <div className="w-full max-w-md space-y-6">
          <div className="space-y-1.5 text-center lg:text-left">
            <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-primary-foreground lg:hidden">
              <HeartPulse className="h-6 w-6" />
            </div>
            <h2 className="text-2xl font-bold">Sign in to MediCore</h2>
            <p className="text-sm text-muted-foreground">Use your staff credentials or patient portal account</p>
          </div>

          <Tabs defaultValue="login">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Sign in</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={submitLogin} className="space-y-4" noValidate>
                <div className="space-y-1.5">
                  <Label htmlFor="login-email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="login-email" type="email" autoComplete="email"
                      className="pl-9" placeholder="you@medicore.com"
                      value={email} onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="login-password">Password</Label>
                    <button type="button" onClick={() => setForgotOpen(true)} className="text-xs font-medium text-primary hover:underline">
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="login-password" type={showPw ? 'text' : 'password'} autoComplete="current-password"
                      className="px-9" placeholder="••••••••"
                      value={password} onChange={(e) => setPassword(e.target.value)}
                    />
                    <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label="Toggle password visibility">
                      {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Sign in
                </Button>
              </form>

              <div className="mt-5">
                <p className="mb-2 text-center text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Demo accounts — password <code className="rounded bg-muted px-1.5 py-0.5 font-mono">Demo@1234</code>
                </p>
                <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
                  {DEMO_ACCOUNTS.map((a) => (
                    <button
                      key={a.email}
                      type="button"
                      onClick={() => { setEmail(a.email); setPassword('Demo@1234') }}
                      className="rounded-lg border px-2 py-1.5 text-left transition-colors hover:border-primary hover:bg-accent"
                    >
                      <p className="text-xs font-semibold">{a.role}</p>
                      <p className="truncate text-[10px] text-muted-foreground">{a.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="register">
              <form onSubmit={submitRegister} className="space-y-4" noValidate>
                <div className="space-y-1.5">
                  <Label htmlFor="reg-name">Full name</Label>
                  <Input id="reg-name" placeholder="Jane Doe" value={reg.name} onChange={(e) => setReg({ ...reg, name: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="reg-email">Email</Label>
                  <Input id="reg-email" type="email" placeholder="jane@example.com" value={reg.email} onChange={(e) => setReg({ ...reg, email: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="reg-phone">Phone (optional)</Label>
                  <Input id="reg-phone" placeholder="+1 555 000 0000" value={reg.phone} onChange={(e) => setReg({ ...reg, phone: e.target.value })} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="reg-pass">Password</Label>
                    <Input id="reg-pass" type="password" placeholder="8+ chars, A-Z, 0-9" value={reg.password} onChange={(e) => setReg({ ...reg, password: e.target.value })} />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="reg-confirm">Confirm</Label>
                    <Input id="reg-confirm" type="password" placeholder="Repeat password" value={reg.confirm} onChange={(e) => setReg({ ...reg, confirm: e.target.value })} />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  <UserPlus className="mr-1 inline h-3.5 w-3.5" />
                  Patient self-registration creates a portal account linked to your medical file.
                </p>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Create account
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Forgot password dialog */}
      <Dialog open={forgotOpen} onOpenChange={setForgotOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <KeyRound className="h-4 w-4" /> Reset your password
            </DialogTitle>
            <DialogDescription>Enter your account email and we will generate a secure reset link.</DialogDescription>
          </DialogHeader>
          <Input
            type="email" placeholder="you@medicore.com" value={forgotEmail}
            onChange={(e) => setForgotEmail(e.target.value)}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setForgotOpen(false)}>Cancel</Button>
            <Button onClick={submitForgot} disabled={forgotLoading}>
              {forgotLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Send reset link
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
