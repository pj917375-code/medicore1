'use client'
/**
 * Remaining views: Notifications center, Audit logs, User accounts,
 * Profile settings, API documentation viewer.
 */
import { useEffect, useState, useCallback } from 'react'
import { Bell, ShieldCheck, UserCog, Settings, KeyRound, BookOpen, Loader2, Mail, Phone, ShieldAlert, Plus, Download, Pencil } from 'lucide-react'
import { DataTable, type Column } from '@/components/hms/data-table'
import { FormDialog, type FormField } from '@/components/hms/form-dialog'
import { PageHeader, StatusBadge, EmptyState } from '@/components/hms/ui'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/lib/client/store'
import { api, fmtDateTime } from '@/lib/client/api'
import { ROLE_LABELS, ROLES, type Role } from '@/lib/rbac'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

// ---------------- Notifications ----------------
interface Notif { id: string; title: string; message: string; type: string; isRead: boolean; createdAt: string }

export function NotificationsView() {
  const [notifs, setNotifs] = useState<Notif[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    try {
      const { data } = await api<Notif[]>('/api/notifications')
      setNotifs(data)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const markAll = async () => {
    try {
      await api('/api/notifications/all', { method: 'PUT', body: JSON.stringify({ markAllRead: true }) })
      load()
      toast.success('All notifications marked as read')
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const markOne = async (n: Notif) => {
    try {
      await api(`/api/notifications/${n.id}`, { method: 'PUT', body: JSON.stringify({ isRead: true }) })
      load()
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={Bell} title="Notifications" subtitle="System alerts, appointments, prescriptions, labs and payments"
        actions={notifs.some((n) => !n.isRead) && (
          <Button variant="outline" onClick={markAll}><ShieldCheck className="mr-2 h-4 w-4" /> Mark all read</Button>
        )}
      />
      <Card>
        <CardContent className="pt-6">
          {loading ? (
            <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : notifs.length === 0 ? (
            <EmptyState icon={Bell} title="No notifications" description="You are all caught up" />
          ) : (
            <ScrollArea className="scrollbar-thin max-h-[60vh]">
              <div className="space-y-2">
                {notifs.map((n) => (
                  <button
                    key={n.id}
                    onClick={() => markOne(n)}
                    className={cn('w-full rounded-lg border p-3 text-left transition-colors hover:bg-accent/60', !n.isRead && 'border-teal-500/40 bg-teal-500/5')}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <p className="font-semibold">{n.title}</p>
                      <Badge variant="outline" className="shrink-0 font-normal text-muted-foreground">{n.type}</Badge>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{n.message}</p>
                    <p className="mt-1.5 text-xs text-muted-foreground/70">{fmtDateTime(n.createdAt)}</p>
                  </button>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// ---------------- Audit logs ----------------
interface LogRow { id: string; userName?: string; action: string; entity: string; entityId?: string; details?: string; ip?: string; createdAt: string; [k: string]: any }

export function AuditView() {
  const [actionFilter, setActionFilter] = useState('')
  const columns: Column<LogRow>[] = [
    { key: 'createdAt', header: 'Time', render: (r) => fmtDateTime(r.createdAt) },
    { key: 'userName', header: 'User', render: (r) => <span className="font-medium">{r.userName || 'System'}</span> },
    { key: 'action', header: 'Action', render: (r) => <StatusBadge status={r.action === 'LOGIN' ? 'CONFIRMED' : r.action === 'DELETE' ? 'CRITICAL' : 'PENDING'} /> },
    { key: 'entity', header: 'Entity', render: (r) => r.entity },
    { key: 'details', header: 'Details', render: (r) => <span className="line-clamp-2 text-xs text-muted-foreground">{r.details || r.entityId || '—'}</span> },
    { key: 'ip', header: 'IP', render: (r) => <span className="font-mono text-xs">{r.ip || '—'}</span>, hideOnMobile: true },
  ]
  return (
    <div className="space-y-5">
      <PageHeader icon={ShieldCheck} title="Audit Logs" subtitle="Security-relevant activity trail (least-privilege: admins only)" />
      <DataTable
        endpoint="/api/audit-logs"
        columns={columns}
        searchPlaceholder="Search user or details..."
        refreshKey={actionFilter.length}
        extraQuery={{ action: actionFilter || undefined }}
        emptyTitle="No audit entries"
        emptyIcon={ShieldCheck}
        toolbar={
          <select className="h-9 rounded-md border bg-transparent px-2.5 text-sm" value={actionFilter} onChange={(e) => setActionFilter(e.target.value)} aria-label="Filter by action">
            <option value="">All actions</option>
            {['LOGIN', 'LOGOUT', 'CREATE', 'UPDATE', 'DELETE', 'EXPORT', 'UPLOAD', 'REGISTER'].map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
        }
      />
    </div>
  )
}

// ---------------- User accounts ----------------
interface UserRow { id: string; name: string; email: string; role: string; phone?: string; isActive: boolean; lastLoginAt?: string; createdAt: string; [k: string]: any }

export function UsersView() {
  const { user: me } = useAuth()
  const [refresh, setRefresh] = useState(0)
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<UserRow | null>(null)
  const [roleFilter, setRoleFilter] = useState('')

  const fields: FormField[] = editing
    ? [
        { name: 'name', label: 'Full name', type: 'text', required: true, defaultValue: editing.name },
        { name: 'role', label: 'Role', type: 'select', required: true, defaultValue: editing.role, optionsFrom: () => ROLES.map((r) => ({ value: r, label: ROLE_LABELS[r as Role] })) },
        { name: 'phone', label: 'Phone', type: 'text', defaultValue: editing.phone },
        { name: 'password', label: 'New password', type: 'password', help: 'Leave empty to keep the current password' },
        { name: 'isActive', label: '', type: 'checkbox', placeholder: 'Account active', defaultValue: editing.isActive },
      ]
    : [
        { name: 'name', label: 'Full name', type: 'text', required: true },
        { name: 'email', label: 'Email', type: 'email', required: true },
        { name: 'password', label: 'Password', type: 'password', required: true, help: '8+ chars, uppercase and number' },
        { name: 'role', label: 'Role', type: 'select', required: true, optionsFrom: () => ROLES.map((r) => ({ value: r, label: ROLE_LABELS[r as Role] })) },
        { name: 'phone', label: 'Phone', type: 'text' },
      ]

  const submit = async (values: Record<string, any>) => {
    try {
      if (editing) {
        const payload = { ...values, isActive: values.isActive !== false }
        if (!payload.password) delete payload.password
        await api(`/api/users/${editing.id}`, { method: 'PUT', body: JSON.stringify(payload) })
        toast.success('User updated')
      } else {
        await api('/api/users', { method: 'POST', body: JSON.stringify(values) })
        toast.success('User created')
      }
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message || 'Save failed')
      throw e
    }
  }

  const toggleActive = async (u: UserRow) => {
    try {
      await api(`/api/users/${u.id}`, { method: 'PUT', body: JSON.stringify({ isActive: !u.isActive }) })
      toast.success(`${u.name} ${u.isActive ? 'deactivated' : 'activated'}`)
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const columns: Column<UserRow>[] = [
    {
      key: 'name', header: 'User',
      render: (u) => (
        <div>
          <p className="font-semibold">{u.name} {u.id === me?.id && <Badge className="ml-1 text-[10px]">you</Badge>}</p>
          <p className="text-xs text-muted-foreground">{u.email}</p>
        </div>
      ),
    },
    { key: 'role', header: 'Role', render: (u) => <Badge variant="outline">{ROLE_LABELS[u.role as Role] || u.role}</Badge> },
    { key: 'phone', header: 'Phone', render: (u) => u.phone || '—', hideOnMobile: true },
    { key: 'lastLoginAt', header: 'Last login', render: (u) => fmtDateTime(u.lastLoginAt), hideOnMobile: true },
    { key: 'isActive', header: 'Status', render: (u) => <StatusBadge status={u.isActive ? 'ACTIVE' : 'INACTIVE'} /> },
  ]

  return (
    <div className="space-y-5">
      <PageHeader
        icon={UserCog} title="User Accounts" subtitle="System identities and role assignment"
        actions={<Button onClick={() => { setEditing(null); setFormOpen(true) }}><Plus className="mr-2 h-4 w-4" /> New user</Button>}
      />
      <DataTable
        endpoint="/api/users"
        columns={columns}
        searchPlaceholder="Search name or email..."
        refreshKey={refresh + roleFilter.length}
        extraQuery={{ role: roleFilter || undefined }}
        emptyTitle="No users"
        emptyIcon={UserCog}
        toolbar={
          <select className="h-9 rounded-md border bg-transparent px-2.5 text-sm" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} aria-label="Filter by role">
            <option value="">All roles</option>
            {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABELS[r as Role]}</option>)}
          </select>
        }
        rowActions={(u) => (
          <>
            <Button variant="ghost" size="icon" title="Edit" onClick={() => { setEditing(u); setFormOpen(true) }}><Pencil className="h-4 w-4" /></Button>
            {u.id !== me?.id && (
              <Button variant="ghost" size="icon" title={u.isActive ? 'Deactivate' : 'Activate'} onClick={() => toggleActive(u)}>
                <ShieldAlert className={u.isActive ? 'h-4 w-4 text-destructive' : 'h-4 w-4 text-emerald-600'} />
              </Button>
            )}
          </>
        )}
      />
      <FormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? `Edit ${editing.name}` : 'Create user'}
        fields={fields}
        initial={editing ? { ...editing, isActive: editing.isActive } : undefined}
        submitLabel={editing ? 'Save changes' : 'Create user'}
        onSubmit={submit}
      />
    </div>
  )
}

// ---------------- Profile ----------------
export function ProfileView() {
  const { user, setUser } = useAuth()
  const [profileOpen, setProfileOpen] = useState(false)
  const [pwOpen, setPwOpen] = useState(false)

  const profileFields: FormField[] = [
    { name: 'name', label: 'Full name', type: 'text', required: true, defaultValue: user?.name },
    { name: 'phone', label: 'Phone', type: 'text', defaultValue: user?.phone || '' },
  ]
  const pwFields: FormField[] = [
    { name: 'currentPassword', label: 'Current password', type: 'password', required: true },
    { name: 'newPassword', label: 'New password', type: 'password', required: true, help: '8+ characters with uppercase and number' },
  ]

  return (
    <div className="space-y-5">
      <PageHeader icon={Settings} title="My Profile" subtitle="Account settings and security" />
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="animate-fade-up">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold text-muted-foreground">Account</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3">
              <span className="flex h-14 w-14 items-center justify-center rounded-full text-lg font-bold text-white" style={{ background: user?.avatarColor || 'var(--primary)' }}>
                {user?.name.split(' ').map((s) => s[0]).slice(0, 2).join('')}
              </span>
              <div>
                <p className="text-lg font-bold">{user?.name}</p>
                <Badge variant="outline">{ROLE_LABELS[user?.role as Role]}</Badge>
              </div>
            </div>
            <p className="flex items-center gap-2 text-sm"><Mail className="h-4 w-4 text-muted-foreground" /> {user?.email}</p>
            {user?.phone && <p className="flex items-center gap-2 text-sm"><Phone className="h-4 w-4 text-muted-foreground" /> {user.phone}</p>}
            <Button variant="outline" onClick={() => setProfileOpen(true)}><Settings className="mr-2 h-4 w-4" /> Edit profile</Button>
          </CardContent>
        </Card>
        <Card className="animate-fade-up">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold text-muted-foreground">Security</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Passwords are hashed with bcrypt (10 rounds). Sessions expire after 8 hours. Every sign-in and data change is recorded in the audit trail.
            </p>
            <Button variant="outline" onClick={() => setPwOpen(true)}><KeyRound className="mr-2 h-4 w-4" /> Change password</Button>
          </CardContent>
        </Card>
      </div>

      <FormDialog
        open={profileOpen} onOpenChange={setProfileOpen}
        title="Edit profile" fields={profileFields} submitLabel="Save"
        onSubmit={async (v) => {
          const { data } = await api('/api/auth/me', { method: 'PUT', body: JSON.stringify(v) })
          setUser(data as any)
          toast.success('Profile updated')
        }}
      />
      <FormDialog
        open={pwOpen} onOpenChange={setPwOpen}
        title="Change password" fields={pwFields} submitLabel="Update password"
        onSubmit={async (v) => {
          await api('/api/auth/change-password', { method: 'POST', body: JSON.stringify(v) })
          toast.success('Password updated')
        }}
      />
    </div>
  )
}

// ---------------- API documentation ----------------
export function ApiDocsView() {
  const [spec, setSpec] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api('/api/openapi.json').then(({ data }) => setSpec(data)).catch(() => {}).finally(() => setLoading(false))
  }, [])

  const groups: Record<string, any[]> = {}
  if (spec) {
    for (const [path, def] of Object.entries<any>(spec.paths)) {
      for (const [method, op] of Object.entries<any>(def)) {
        const tag = op.tags?.[0] || 'Other'
        groups[tag] = groups[tag] || []
        groups[tag].push({ path, method, summary: op.summary, auth: !(op.security?.length === 0) })
      }
    }
  }
  const methodColor: Record<string, string> = {
    get: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
    post: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
    put: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
    delete: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={BookOpen} title="API Documentation" subtitle="OpenAPI 3.0 (Swagger) specification — every endpoint below is live"
        actions={
          <Button variant="outline" onClick={() => window.open('/api/openapi.json', '_blank')}>
            <Download className="mr-2 h-4 w-4" /> openapi.json
          </Button>
        }
      />
      <Card>
        <CardContent className="pt-6 text-sm text-muted-foreground">
          <p>
            Authentication: JWT via <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">Authorization: Bearer &lt;token&gt;</code> or the
            <code className="mx-1 rounded bg-muted px-1 py-0.5 font-mono text-xs">hms_token</code> httpOnly cookie (set at login).
            Standard envelope: <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">{'{ success, data, meta }'}</code> on success,{' '}
            <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">{'{ success: false, error: { message } }'}</code> on failure.
            Role-based access control is enforced server-side on every route.
          </p>
        </CardContent>
      </Card>

      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
      ) : (
        Object.entries(groups).map(([tag, ops]) => (
          <Card key={tag} className="animate-fade-up">
            <CardHeader className="pb-2"><CardTitle className="text-sm font-bold">{tag}</CardTitle></CardHeader>
            <CardContent className="space-y-1.5 pt-0">
              {ops.map((op) => (
                <div key={op.method + op.path} className="flex flex-col gap-1 rounded-lg border px-3 py-2 sm:flex-row sm:items-center sm:gap-3">
                  <span className={cn('w-16 rounded px-1.5 py-0.5 text-center text-[11px] font-bold uppercase', methodColor[op.method])}>{op.method}</span>
                  <code className="font-mono text-xs font-semibold">{op.path}</code>
                  <span className="text-xs text-muted-foreground">{op.summary}</span>
                  {!op.auth && <Badge variant="outline" className="shrink-0 text-[10px]">public</Badge>}
                </div>
              ))}
            </CardContent>
          </Card>
        ))
      )}
    </div>
  )
}
