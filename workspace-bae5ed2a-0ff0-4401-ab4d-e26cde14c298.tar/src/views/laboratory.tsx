'use client'
/**
 * Laboratory workflow: request → sample collected → processing →
 * results uploaded → doctor reviewed. Techs upload parameterized
 * results; doctors review; patients read their own results.
 */
import { useState } from 'react'
import { FlaskConical, Plus, CheckCircle2, FileCheck, Loader2, TestTube, FilePlus2 } from 'lucide-react'
import { DataTable, type Column } from '@/components/hms/data-table'
import { FormDialog, type FormField } from '@/components/hms/form-dialog'
import { PageHeader, StatusBadge } from '@/components/hms/ui'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useAuth } from '@/lib/client/store'
import { api, fmtDateTime } from '@/lib/client/api'
import { toast } from 'sonner'

interface ResultVal { parameter: string; value: string; unit?: string; referenceRange?: string; flag: 'NORMAL' | 'HIGH' | 'LOW' | 'CRITICAL' }
interface LabRow { id: string; code: string; testName: string; category: string; sampleType?: string; priority: string; status: string; requestedAt: string; patient: { firstName: string; lastName: string; code: string }; doctor: { user: { name: string } }; result?: { id: string; resultSummary: string; values?: string; technologist?: string; reviewedBy?: string }; [k: string]: any }

export function LaboratoryView() {
  const { user } = useAuth()
  const [formOpen, setFormOpen] = useState(false)
  const [refresh, setRefresh] = useState(0)
  const [patients, setPatients] = useState<any[]>([])
  const [doctors, setDoctors] = useState<any[]>([])
  const [statusFilter, setStatusFilter] = useState('')
  const [detail, setDetail] = useState<LabRow | null>(null)
  const [resultForm, setResultForm] = useState<{ summary: string; vals: ResultVal[]; technologist: string }>({ summary: '', vals: [{ parameter: '', value: '', unit: '', referenceRange: '', flag: 'NORMAL' }], technologist: user?.name || '' })
  const [saving, setSaving] = useState(false)

  const role = user?.role
  const canRequest = ['SUPER_ADMIN', 'ADMIN', 'DOCTOR'].includes(role || '')
  const canProcess = ['SUPER_ADMIN', 'ADMIN', 'LAB_TECHNICIAN'].includes(role || '')
  const canReview = ['SUPER_ADMIN', 'ADMIN', 'DOCTOR'].includes(role || '')

  const loadPickers = () => {
    if (canRequest) {
      api('/api/patients?pageSize=100').then(({ data }) => setPatients(data)).catch(() => {})
      api('/api/doctors?pageSize=100').then(({ data }) => setDoctors(data)).catch(() => {})
    }
  }

  const advance = async (l: LabRow, status: string) => {
    try {
      await api(`/api/lab-tests/${l.id}`, { method: 'PUT', body: JSON.stringify({ status }) })
      toast.success(`${l.code} → ${status.replace(/_/g, ' ').toLowerCase()}`)
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const review = async (l: LabRow) => {
    try {
      await api(`/api/lab-tests/${l.id}/review`, { method: 'POST', body: JSON.stringify({ reviewedBy: user?.name }) })
      toast.success(`${l.code} reviewed and signed off`)
      setRefresh((r) => r + 1)
      setDetail(null)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const uploadResult = async () => {
    if (!detail) return
    if (!resultForm.summary.trim()) return toast.error('Result summary is required')
    const vals = resultForm.vals.filter((v) => v.parameter.trim())
    setSaving(true)
    try {
      await api(`/api/lab-tests/${detail.id}/result`, {
        method: 'POST',
        body: JSON.stringify({ resultSummary: resultForm.summary, values: vals, technologist: resultForm.technologist }),
      })
      toast.success('Results uploaded — requesting doctor notified')
      setDetail(null)
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setSaving(false)
    }
  }

  const fields: FormField[] = [
    { name: 'patientId', label: 'Patient', type: 'select', required: true, optionsFrom: () => patients.map((p) => ({ value: p.id, label: `${p.firstName} ${p.lastName} (${p.code})` })) },
    ...(role !== 'DOCTOR' ? [{ name: 'doctorId', label: 'Requesting doctor', type: 'select' as const, required: true, optionsFrom: () => doctors.map((d) => ({ value: d.id, label: `Dr. ${d.user.name}` })) }] : []),
    { name: 'testName', label: 'Test name', type: 'text', required: true, placeholder: 'Complete Blood Count' },
    { name: 'category', label: 'Category', type: 'select', required: true, defaultValue: 'HEMATOLOGY', options: ['HEMATOLOGY', 'BIOCHEMISTRY', 'MICROBIOLOGY', 'RADIOLOGY', 'GENERAL'].map((c) => ({ value: c, label: c.replace('_', ' ') })) },
    { name: 'sampleType', label: 'Sample type', type: 'text', placeholder: 'Venous blood / Urine / Swab' },
    { name: 'priority', label: 'Priority', type: 'select', required: true, defaultValue: 'ROUTINE', options: [{ value: 'ROUTINE', label: 'Routine' }, { value: 'URGENT', label: 'Urgent' }] },
    { name: 'notes', label: 'Clinical notes', type: 'textarea', colSpan: 2 },
  ]

  const submit = async (values: Record<string, any>) => {
    try {
      await api('/api/lab-tests', { method: 'POST', body: JSON.stringify(values) })
      toast.success('Lab test requested — technicians notified')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message || 'Request failed')
      throw e
    }
  }

  const columns: Column<LabRow>[] = [
    {
      key: 'testName', header: 'Test',
      render: (l) => (
        <div>
          <p className="font-semibold">{l.testName} {l.priority === 'URGENT' && <StatusBadge status="URGENT" className="ml-1" />}</p>
          <p className="text-xs text-muted-foreground">{l.code} · {l.category}</p>
        </div>
      ),
    },
    { key: 'patient', header: 'Patient', render: (l) => `${l.patient.firstName} ${l.patient.lastName}` },
    { key: 'doctor', header: 'Requested by', render: (l) => `Dr. ${l.doctor?.user?.name}`, hideOnMobile: true },
    { key: 'requestedAt', header: 'Requested', render: (l) => fmtDateTime(l.requestedAt), hideOnMobile: true },
    { key: 'status', header: 'Status', render: (l) => <StatusBadge status={l.status} /> },
  ]

  const parsedVals: ResultVal[] = detail?.result?.values ? JSON.parse(detail.result.values) : []

  return (
    <div className="space-y-5">
      <PageHeader
        icon={FlaskConical} title="Laboratory Management" subtitle="Test requests, sample pipeline and digital results"
        actions={canRequest && <Button onClick={() => { setFormOpen(true); loadPickers() }}><Plus className="mr-2 h-4 w-4" /> Request test</Button>}
      />
      <DataTable
        endpoint="/api/lab-tests"
        columns={columns}
        searchPlaceholder="Search test name or ID..."
        refreshKey={refresh + statusFilter.length}
        extraQuery={{ status: statusFilter || undefined }}
        onRowClick={setDetail}
        emptyTitle="No lab tests"
        emptyIcon={TestTube}
        toolbar={
          <select className="h-9 rounded-md border bg-transparent px-2.5 text-sm" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label="Filter by status">
            <option value="">All statuses</option>
            {['REQUESTED', 'SAMPLE_COLLECTED', 'PROCESSING', 'COMPLETED', 'REVIEWED', 'CANCELLED'].map((s) => (
              <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>
            ))}
          </select>
        }
        rowActions={(l) => (
          <>
            {canProcess && l.status === 'REQUESTED' && (
              <Button variant="ghost" size="icon" title="Collect sample" onClick={() => advance(l, 'SAMPLE_COLLECTED')}><TestTube className="h-4 w-4 text-sky-600" /></Button>
            )}
            {canProcess && l.status === 'SAMPLE_COLLECTED' && (
              <Button variant="ghost" size="icon" title="Start processing" onClick={() => advance(l, 'PROCESSING')}><Loader2 className="h-4 w-4 text-amber-600" /></Button>
            )}
            {canProcess && l.status === 'PROCESSING' && (
              <Button variant="ghost" size="icon" title="Upload results" onClick={() => { setDetail(l); setResultForm({ summary: '', vals: [{ parameter: '', value: '', unit: '', referenceRange: '', flag: 'NORMAL' }], technologist: user?.name || '' }) }}><FilePlus2 className="h-4 w-4 text-teal-600" /></Button>
            )}
            {canReview && l.status === 'COMPLETED' && (
              <Button variant="ghost" size="icon" title="Review results" onClick={() => review(l)}><FileCheck className="h-4 w-4 text-emerald-600" /></Button>
            )}
          </>
        )}
      />

      {/* Detail dialog */}
      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="scrollbar-thin max-h-[85vh] overflow-y-auto sm:max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between gap-2">
              {detail?.testName} <StatusBadge status={detail?.status} />
            </DialogTitle>
          </DialogHeader>
          {detail && (
            <div className="space-y-3 text-sm">
              <p className="text-muted-foreground">
                {detail.code} · Patient {detail.patient.firstName} {detail.patient.lastName} ({detail.patient.code}) · Requested by Dr. {detail.doctor?.user?.name} on {fmtDateTime(detail.requestedAt)}
              </p>
              {detail.sampleType && <p><span className="font-medium">Sample:</span> {detail.sampleType}</p>}

              {detail.result ? (
                <>
                  <div className="rounded-lg bg-muted/60 p-3">{detail.result.resultSummary}</div>
                  {parsedVals.length > 0 && (
                    <table className="w-full rounded-lg border text-sm">
                      <thead>
                        <tr className="border-b bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
                          <th className="px-3 py-2">Parameter</th>
                          <th className="px-3 py-2">Value</th>
                          <th className="px-3 py-2">Reference</th>
                          <th className="px-3 py-2">Flag</th>
                        </tr>
                      </thead>
                      <tbody>
                        {parsedVals.map((v, i) => (
                          <tr key={i} className="border-b last:border-0">
                            <td className="px-3 py-2 font-medium">{v.parameter}</td>
                            <td className="px-3 py-2">{v.value} {v.unit}</td>
                            <td className="px-3 py-2 text-muted-foreground">{v.referenceRange || '—'}</td>
                            <td className="px-3 py-2"><StatusBadge status={v.flag} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Technologist: {detail.result.technologist || '—'} · Reviewed by: {detail.result.reviewedBy || 'Pending review'}
                  </p>
                  {canReview && detail.status === 'COMPLETED' && (
                    <Button className="w-full" onClick={() => review(detail)}><CheckCircle2 className="mr-2 h-4 w-4" /> Review & sign off</Button>
                  )}
                </>
              ) : canProcess ? (
                /* Result upload form */
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium">Result summary *</label>
                    <textarea className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" rows={2} value={resultForm.summary} onChange={(e) => setResultForm({ ...resultForm, summary: e.target.value })} placeholder="All parameters within normal limits..." />
                  </div>
                  {resultForm.vals.map((v, i) => (
                    <div key={i} className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                      <input className="rounded-md border bg-transparent px-2 py-1.5 text-sm" placeholder="Parameter" value={v.parameter} onChange={(e) => setResultForm({ ...resultForm, vals: resultForm.vals.map((x, j) => (i === j ? { ...x, parameter: e.target.value } : x)) })} />
                      <input className="rounded-md border bg-transparent px-2 py-1.5 text-sm" placeholder="Value" value={v.value} onChange={(e) => setResultForm({ ...resultForm, vals: resultForm.vals.map((x, j) => (i === j ? { ...x, value: e.target.value } : x)) })} />
                      <input className="rounded-md border bg-transparent px-2 py-1.5 text-sm" placeholder="Unit" value={v.unit} onChange={(e) => setResultForm({ ...resultForm, vals: resultForm.vals.map((x, j) => (i === j ? { ...x, unit: e.target.value } : x)) })} />
                      <input className="rounded-md border bg-transparent px-2 py-1.5 text-sm" placeholder="Ref. range" value={v.referenceRange} onChange={(e) => setResultForm({ ...resultForm, vals: resultForm.vals.map((x, j) => (i === j ? { ...x, referenceRange: e.target.value } : x)) })} />
                      <select className="rounded-md border bg-transparent px-2 py-1.5 text-sm" value={v.flag} onChange={(e) => setResultForm({ ...resultForm, vals: resultForm.vals.map((x, j) => (i === j ? { ...x, flag: e.target.value } : x)) })}>
                        {['NORMAL', 'HIGH', 'LOW', 'CRITICAL'].map((f) => <option key={f} value={f}>{f}</option>)}
                      </select>
                    </div>
                  ))}
                  <div className="flex justify-between">
                    <Button variant="outline" size="sm" onClick={() => setResultForm({ ...resultForm, vals: [...resultForm.vals, { parameter: '', value: '', unit: '', referenceRange: '', flag: 'NORMAL' }] })}>+ Add parameter</Button>
                  </div>
                  <Button className="w-full" onClick={uploadResult} disabled={saving}>
                    {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Upload results & notify doctor
                  </Button>
                </div>
              ) : (
                <p className="rounded-lg border border-dashed p-4 text-center text-muted-foreground">Results not yet uploaded</p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <FormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        title="Request laboratory test"
        fields={fields}
        submitLabel="Request test"
        onSubmit={submit}
      />
    </div>
  )
}
