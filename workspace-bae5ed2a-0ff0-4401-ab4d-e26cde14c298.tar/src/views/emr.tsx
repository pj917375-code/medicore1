'use client'
/**
 * Electronic Medical Records: consultation records with vitals,
 * diagnosis, treatment plan. Doctors create; patients read their own.
 */
import { useEffect, useState } from 'react'
import { ClipboardList, Plus, Stethoscope } from 'lucide-react'
import { DataTable, type Column } from '@/components/hms/data-table'
import { FormDialog, type FormField } from '@/components/hms/form-dialog'
import { PageHeader, StatusBadge } from '@/components/hms/ui'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/lib/client/store'
import { api, fmtDateTime, fullName } from '@/lib/client/api'
import { toast } from 'sonner'

interface RecordRow { id: string; visitType: string; symptoms?: string; diagnosis: string; treatmentPlan?: string; clinicalNotes?: string; bloodPressure?: string; heartRate?: number; temperature?: number; weight?: number; followUpDate?: string; createdAt: string; patient: { firstName: string; lastName: string; code: string }; doctor: { user: { name: string } }; [k: string]: any }

export function EmrView() {
  const { user } = useAuth()
  const [formOpen, setFormOpen] = useState(false)
  const [refresh, setRefresh] = useState(0)
  const [patients, setPatients] = useState<any[]>([])
  const [doctors, setDoctors] = useState<any[]>([])
  const isDoctor = ['SUPER_ADMIN', 'ADMIN', 'DOCTOR'].includes(user?.role || '')

  useEffect(() => {
    if (isDoctor) {
      api('/api/patients?pageSize=100').then(({ data }) => setPatients(data)).catch(() => {})
      api('/api/doctors?pageSize=100').then(({ data }) => setDoctors(data)).catch(() => {})
    }
  }, [isDoctor, refresh])

  // Doctors default to their own doctorId
  const myDoctorId = doctors.find((d) => d.user?.email === user?.email)?.id || ''

  const fields: FormField[] = [
    { name: 'patientId', label: 'Patient', type: 'select', required: true, optionsFrom: () => patients.map((p) => ({ value: p.id, label: `${p.firstName} ${p.lastName} (${p.code})` })) },
    ...(user?.role !== 'DOCTOR' ? [{ name: 'doctorId', label: 'Attending doctor', type: 'select' as const, required: true, optionsFrom: () => doctors.map((d) => ({ value: d.id, label: `Dr. ${d.user.name}` })) }] : []),
    { name: 'visitType', label: 'Visit type', type: 'select', required: true, defaultValue: 'CONSULTATION', options: [{ value: 'CONSULTATION', label: 'Consultation' }, { value: 'FOLLOW_UP', label: 'Follow-up' }, { value: 'EMERGENCY', label: 'Emergency' }, { value: 'ADMISSION', label: 'Admission' }] },
    { name: 'symptoms', label: 'Symptoms', type: 'textarea', colSpan: 2 },
    { name: 'diagnosis', label: 'Diagnosis', type: 'text', required: true, colSpan: 2 },
    { name: 'treatmentPlan', label: 'Treatment plan', type: 'textarea', colSpan: 2 },
    { name: 'bloodPressure', label: 'Blood pressure', type: 'text', placeholder: '120/80' },
    { name: 'heartRate', label: 'Heart rate (bpm)', type: 'number', min: 0, max: 250 },
    { name: 'temperature', label: 'Temperature (°C)', type: 'number', step: '0.1', min: 30, max: 45 },
    { name: 'weight', label: 'Weight (kg)', type: 'number', min: 0, max: 400 },
    { name: 'followUpDate', label: 'Follow-up date', type: 'date' },
    { name: 'clinicalNotes', label: 'Clinical notes', type: 'textarea', colSpan: 2 },
  ]

  const submit = async (values: Record<string, any>) => {
    const payload = { ...values, doctorId: values.doctorId || myDoctorId }
    try {
      await api('/api/medical-records', { method: 'POST', body: JSON.stringify(payload) })
      toast.success('Medical record added — linked to patient EMR')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message || 'Save failed')
      throw e
    }
  }

  const columns: Column<RecordRow>[] = [
    { key: 'patient', header: 'Patient', render: (r) => <span className="font-medium">{fullName(r.patient)} <span className="text-xs text-muted-foreground">{r.patient.code}</span></span> },
    { key: 'diagnosis', header: 'Diagnosis', render: (r) => <span className="font-medium">{r.diagnosis}</span> },
    { key: 'doctor', header: 'Doctor', render: (r) => `Dr. ${r.doctor?.user?.name}`, hideOnMobile: true },
    { key: 'vitals', header: 'Vitals', render: (r) => <span className="text-xs text-muted-foreground">BP {r.bloodPressure || '—'} · {r.heartRate || '—'} bpm · {r.temperature || '—'}°C</span>, hideOnMobile: true },
    { key: 'visitType', header: 'Visit', render: (r) => <StatusBadge status={r.visitType} /> },
    { key: 'createdAt', header: 'Recorded', render: (r) => fmtDateTime(r.createdAt), hideOnMobile: true },
  ]

  return (
    <div className="space-y-5">
      <PageHeader
        icon={ClipboardList} title="Electronic Medical Records" subtitle="Diagnoses, treatment plans, vitals and clinical notes"
        actions={isDoctor && (
          <Button onClick={() => setFormOpen(true)}><Plus className="mr-2 h-4 w-4" /> New record</Button>
        )}
      />
      <DataTable
        endpoint="/api/medical-records"
        columns={columns}
        searchPlaceholder="Search diagnosis or symptoms..."
        refreshKey={refresh}
        pageSize={10}
        emptyTitle="No medical records"
        emptyDescription={user?.role === 'PATIENT' ? 'Records appear here after your consultations' : 'Add a consultation record to build the patient EMR'}
        emptyIcon={Stethoscope}
      />
      {isDoctor && (
        <FormDialog
          open={formOpen}
          onOpenChange={setFormOpen}
          title="New medical record"
          description="Vitals, diagnosis and treatment plan are stored in the patient's permanent EMR."
          fields={fields}
          submitLabel="Add record"
          onSubmit={submit}
        />
      )}
    </div>
  )
}
