'use client'
/**
 * Doctor directory + registration. Admin adds doctors (creates their
 * user account); patients can browse doctors.
 */
import { useEffect, useState } from 'react'
import { Stethoscope, Plus, Pencil, Trash2, Star, CalendarDays, Building2 } from 'lucide-react'
import { DataTable, type Column } from '@/components/hms/data-table'
import { FormDialog, type FormField } from '@/components/hms/form-dialog'
import { PageHeader, StatusBadge } from '@/components/hms/ui'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { useAuth } from '@/lib/client/store'
import { api, money, fmtDate } from '@/lib/client/api'
import { toast } from 'sonner'

interface Dept { id: string; name: string }
interface DoctorRow { id: string; code: string; specialization: string; qualification: string; licenseNo: string; experienceYears: number; consultationFee: number; status: string; rating: number; availability: string; shiftTime: string; user: { name: string; email: string; phone?: string }; department?: Dept; _count?: { appointments: number }; [k: string]: any }

export function DoctorsView() {
  const { user } = useAuth()
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<DoctorRow | null>(null)
  const [refresh, setRefresh] = useState(0)
  const [departments, setDepartments] = useState<Dept[]>([])
  const canManage = ['SUPER_ADMIN', 'ADMIN'].includes(user?.role || '')

  useEffect(() => {
    api('/api/departments').then(({ data }) => setDepartments(data)).catch(() => {})
  }, [refresh])

  const fields: FormField[] = editing
    ? [
        { name: 'specialization', label: 'Specialization', type: 'text', required: true, defaultValue: editing.specialization },
        { name: 'qualification', label: 'Qualifications', type: 'text', required: true, defaultValue: editing.qualification },
        { name: 'experienceYears', label: 'Experience (years)', type: 'number', required: true, min: 0, max: 80, defaultValue: editing.experienceYears },
        { name: 'consultationFee', label: 'Consultation fee ($)', type: 'number', required: true, min: 0, defaultValue: editing.consultationFee },
        { name: 'departmentId', label: 'Department', type: 'select', required: true, defaultValue: editing.departmentId, optionsFrom: () => departments.map((d) => ({ value: d.id, label: d.name })) },
        { name: 'availability', label: 'Available days (CSV)', type: 'text', defaultValue: editing.availability, placeholder: 'Mon,Tue,Wed' },
        { name: 'shiftTime', label: 'Shift time', type: 'text', defaultValue: editing.shiftTime, placeholder: '09:00-17:00' },
        { name: 'status', label: 'Status', type: 'select', defaultValue: editing.status, options: [{ value: 'ACTIVE', label: 'Active' }, { value: 'ON_LEAVE', label: 'On leave' }, { value: 'INACTIVE', label: 'Inactive' }] },
      ]
    : [
        { name: 'name', label: 'Full name', type: 'text', required: true },
        { name: 'email', label: 'Email (login)', type: 'email', required: true },
        { name: 'password', label: 'Initial password', type: 'password', required: true, help: 'Doctor uses this to sign in (8+ chars, A-Z, 0-9)' },
        { name: 'specialization', label: 'Specialization', type: 'text', required: true },
        { name: 'qualification', label: 'Qualifications', type: 'text', required: true, placeholder: 'MD, MBBS, MRCP...' },
        { name: 'licenseNo', label: 'License number', type: 'text', required: true },
        { name: 'experienceYears', label: 'Experience (years)', type: 'number', required: true, min: 0, max: 80 },
        { name: 'consultationFee', label: 'Consultation fee ($)', type: 'number', required: true, min: 0 },
        { name: 'departmentId', label: 'Department', type: 'select', required: true, optionsFrom: () => departments.map((d) => ({ value: d.id, label: d.name })) },
        { name: 'availability', label: 'Available days (CSV)', type: 'text', defaultValue: 'Mon,Tue,Wed,Thu,Fri' },
        { name: 'shiftTime', label: 'Shift time', type: 'text', defaultValue: '09:00-17:00' },
      ]

  const submit = async (values: Record<string, any>) => {
    try {
      if (editing) {
        await api(`/api/doctors/${editing.id}`, { method: 'PUT', body: JSON.stringify(values) })
        toast.success('Doctor updated')
      } else {
        await api('/api/doctors', { method: 'POST', body: JSON.stringify(values) })
        toast.success('Doctor registered — login account created')
      }
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message || 'Save failed')
      throw e
    }
  }

  const remove = async (d: DoctorRow) => {
    if (!confirm(`Remove Dr. ${d.user.name}? Their login will be deactivated.`)) return
    try {
      await api(`/api/doctors/${d.id}`, { method: 'DELETE' })
      toast.success('Doctor removed')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const columns: Column<DoctorRow>[] = [
    {
      key: 'name', header: 'Doctor',
      render: (d) => (
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9">
            <AvatarFallback className="bg-cyan-700 text-xs font-bold text-white">{d.user.name.split(' ').map((s) => s[0]).slice(0, 2).join('')}</AvatarFallback>
          </Avatar>
          <div>
            <p className="font-semibold">{d.user.name}</p>
            <p className="text-xs text-muted-foreground">{d.code} · {d.user.email}</p>
          </div>
        </div>
      ),
    },
    { key: 'specialization', header: 'Specialization', render: (d) => <span className="font-medium">{d.specialization}</span> },
    { key: 'department', header: 'Department', render: (d) => d.department?.name || '—', hideOnMobile: true },
    { key: 'experienceYears', header: 'Experience', render: (d) => `${d.experienceYears} yrs`, hideOnMobile: true },
    { key: 'consultationFee', header: 'Fee', render: (d) => money(d.consultationFee), hideOnMobile: true },
    { key: 'rating', header: 'Rating', render: (d) => <span className="inline-flex items-center gap-1 text-amber-500"><Star className="h-3.5 w-3.5 fill-amber-400" /> {d.rating?.toFixed(1)}</span>, hideOnMobile: true },
    { key: 'status', header: 'Status', render: (d) => <StatusBadge status={d.status} /> },
  ]

  return (
    <div className="space-y-5">
      <PageHeader
        icon={Stethoscope} title="Doctor Management" subtitle="Specialists, qualifications, availability and fees"
        actions={canManage && (
          <Button onClick={() => { setEditing(null); setFormOpen(true) }}>
            <Plus className="mr-2 h-4 w-4" /> Add doctor
          </Button>
        )}
      />
      <DataTable
        endpoint="/api/doctors"
        columns={columns}
        searchPlaceholder="Search by code, specialization..."
        refreshKey={refresh}
        emptyTitle="No doctors found"
        emptyIcon={Stethoscope}
        rowActions={(d) => canManage && (
          <>
            <Button variant="ghost" size="icon" title="Edit" onClick={() => { setEditing(d); setFormOpen(true) }}><Pencil className="h-4 w-4" /></Button>
            <Button variant="ghost" size="icon" title="Remove" onClick={() => remove(d)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
          </>
        )}
      />
      <FormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? `Edit Dr. ${editing.user.name}` : 'Register new doctor'}
        description={editing ? 'Update profile, availability and fees.' : 'Creates a doctor login account and profile.'}
        fields={fields}
        initial={editing || undefined}
        submitLabel={editing ? 'Save changes' : 'Register doctor'}
        onSubmit={submit}
      />
    </div>
  )
}
