'use client'
/**
 * Staff management: employee directory, onboarding, shift/department
 * filters and daily attendance marking.
 */
import { useEffect, useState } from 'react'
import { UserCog, Plus, Pencil, Trash2, CalendarCheck } from 'lucide-react'
import { DataTable, type Column } from '@/components/hms/data-table'
import { FormDialog, type FormField } from '@/components/hms/form-dialog'
import { PageHeader, StatusBadge } from '@/components/hms/ui'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useAuth } from '@/lib/client/store'
import { api, fmtDate } from '@/lib/client/api'
import { toast } from 'sonner'

interface StaffRow { id: string; employeeCode: string; title: string; department: string; shift: string; status: string; joinedAt: string; user: { name: string; email: string; role: string }; attendance: { id: string; date: string; status: string }[]; [k: string]: any }

export function StaffView() {
  const { user } = useAuth()
  const [refresh, setRefresh] = useState(0)
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<StaffRow | null>(null)
  const [attendance, setAttendance] = useState<any[]>([])
  const canManage = ['SUPER_ADMIN', 'ADMIN'].includes(user?.role || '')

  const loadAttendance = () => api('/api/staff/attendance?pageSize=100').then(({ data }) => setAttendance(data)).catch(() => {})
  useEffect(() => { loadAttendance() }, [refresh])

  const fields: FormField[] = editing
    ? [
        { name: 'title', label: 'Job title', type: 'text', required: true, defaultValue: editing.title },
        { name: 'department', label: 'Department', type: 'text', required: true, defaultValue: editing.department },
        { name: 'shift', label: 'Shift', type: 'select', required: true, defaultValue: editing.shift, options: [{ value: 'MORNING', label: 'Morning' }, { value: 'EVENING', label: 'Evening' }, { value: 'NIGHT', label: 'Night' }] },
        { name: 'status', label: 'Status', type: 'select', required: true, defaultValue: editing.status, options: [{ value: 'ACTIVE', label: 'Active' }, { value: 'ON_LEAVE', label: 'On leave' }, { value: 'TERMINATED', label: 'Terminated' }] },
      ]
    : [
        { name: 'name', label: 'Full name', type: 'text', required: true },
        { name: 'email', label: 'Email (login)', type: 'email', required: true },
        { name: 'password', label: 'Initial password', type: 'password', required: true, help: '8+ chars, uppercase and number' },
        { name: 'role', label: 'System role', type: 'select', required: true, options: [{ value: 'NURSE', label: 'Nurse' }, { value: 'RECEPTIONIST', label: 'Receptionist' }, { value: 'PHARMACIST', label: 'Pharmacist' }, { value: 'LAB_TECHNICIAN', label: 'Lab Technician' }] },
        { name: 'employeeCode', label: 'Employee code', type: 'text', required: true, placeholder: 'N-2002' },
        { name: 'title', label: 'Job title', type: 'text', required: true, placeholder: 'Senior Nurse' },
        { name: 'department', label: 'Department', type: 'text', required: true },
        { name: 'shift', label: 'Shift', type: 'select', required: true, defaultValue: 'MORNING', options: [{ value: 'MORNING', label: 'Morning' }, { value: 'EVENING', label: 'Evening' }, { value: 'NIGHT', label: 'Night' }] },
      ]

  const submit = async (values: Record<string, any>) => {
    try {
      if (editing) {
        await api(`/api/staff/${editing.id}`, { method: 'PUT', body: JSON.stringify(values) })
        toast.success('Staff updated')
      } else {
        await api('/api/staff', { method: 'POST', body: JSON.stringify(values) })
        toast.success('Staff onboarded — login account created')
      }
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message || 'Save failed')
      throw e
    }
  }

  const remove = async (s: StaffRow) => {
    if (!confirm(`Remove ${s.user.name} from staff? Their account will be deactivated.`)) return
    try {
      await api(`/api/staff/${s.id}`, { method: 'DELETE' })
      toast.success('Staff removed and account deactivated')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const markAttendance = async (s: StaffRow, status: 'PRESENT' | 'ABSENT' | 'LEAVE') => {
    try {
      await api('/api/staff/attendance', {
        method: 'POST',
        body: JSON.stringify({ staffId: s.id, date: new Date().toISOString().slice(0, 10), status, checkIn: status === 'PRESENT' ? new Date().toTimeString().slice(0, 5) : undefined }),
      })
      toast.success(`${s.user.name} marked ${status.toLowerCase()} for today`)
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const columns: Column<StaffRow>[] = [
    {
      key: 'name', header: 'Employee',
      render: (s) => (
        <div>
          <p className="font-semibold">{s.user.name}</p>
          <p className="text-xs text-muted-foreground">{s.employeeCode} · {s.user.email}</p>
        </div>
      ),
    },
    { key: 'title', header: 'Title', render: (s) => <span className="font-medium">{s.title}</span> },
    { key: 'department', header: 'Department', render: (s) => s.department, hideOnMobile: true },
    { key: 'shift', header: 'Shift', render: (s) => <StatusBadge status={s.shift} />, hideOnMobile: true },
    { key: 'joinedAt', header: 'Joined', render: (s) => fmtDate(s.joinedAt), hideOnMobile: true },
    { key: 'status', header: 'Status', render: (s) => <StatusBadge status={s.status} /> },
  ]

  const today = new Date().toISOString().slice(0, 10)
  const presentToday = attendance.filter((a) => a.date === today && a.status === 'PRESENT').length

  return (
    <div className="space-y-5">
      <PageHeader
        icon={UserCog} title="Staff Management" subtitle="Employee directory, shifts and attendance"
        actions={canManage && (
          <Button onClick={() => { setEditing(null); setFormOpen(true) }}><Plus className="mr-2 h-4 w-4" /> Onboard staff</Button>
        )}
      />
      <Tabs defaultValue="directory">
        <TabsList>
          <TabsTrigger value="directory">Directory</TabsTrigger>
          <TabsTrigger value="attendance">Attendance ({presentToday} present today)</TabsTrigger>
        </TabsList>

        <TabsContent value="directory" className="mt-4">
          <DataTable
            endpoint="/api/staff"
            columns={columns}
            searchPlaceholder="Search employee, code, department..."
            refreshKey={refresh}
            emptyTitle="No staff records"
            emptyIcon={UserCog}
            rowActions={(s) => canManage && (
              <>
                <Button variant="ghost" size="icon" title="Mark present today" onClick={() => markAttendance(s, 'PRESENT')}><CalendarCheck className="h-4 w-4 text-emerald-600" /></Button>
                <Button variant="ghost" size="icon" title="Edit" onClick={() => { setEditing(s); setFormOpen(true) }}><Pencil className="h-4 w-4" /></Button>
                <Button variant="ghost" size="icon" title="Remove" onClick={() => remove(s)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </>
            )}
          />
        </TabsContent>

        <TabsContent value="attendance" className="mt-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold text-muted-foreground">Recent attendance records (last 7 days per employee)</CardTitle>
            </CardHeader>
            <CardContent className="max-h-96 space-y-2 overflow-y-auto scrollbar-thin pt-0">
              {attendance.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">No attendance records</p>}
              {attendance.map((a) => (
                <div key={a.id} className="flex items-center justify-between rounded-lg border px-3 py-2 text-sm">
                  <div>
                    <p className="font-medium">{a.staff?.user?.name}</p>
                    <p className="text-xs text-muted-foreground">{a.date}{a.checkIn && ` · In ${a.checkIn}`}{a.checkOut && ` · Out ${a.checkOut}`}</p>
                  </div>
                  <StatusBadge status={a.status} />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <FormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? `Edit ${editing.user.name}` : 'Onboard staff member'}
        fields={fields}
        initial={editing || undefined}
        submitLabel={editing ? 'Save changes' : 'Onboard staff'}
        onSubmit={submit}
      />
    </div>
  )
}
