'use client'
/**
 * Pharmacy management: medicine inventory with stock & expiry alerts,
 * add/edit/restock, category filter.
 */
import { useEffect, useState } from 'react'
import { Package, Plus, Pencil, Trash2, AlertTriangle, PackageX, Warehouse } from 'lucide-react'
import { DataTable, type Column } from '@/components/hms/data-table'
import { FormDialog, type FormField } from '@/components/hms/form-dialog'
import { PageHeader, StatusBadge, StatCard } from '@/components/hms/ui'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/lib/client/store'
import { api, money, fmtDate } from '@/lib/client/api'
import { toast } from 'sonner'

interface Med { id: string; name: string; category: string; manufacturer?: string; unit: string; unitPrice: number; stockQty: number; reorderLevel: number; batchNo?: string; expiryDate?: string; [k: string]: any }

export function PharmacyView() {
  const { user } = useAuth()
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<Med | null>(null)
  const [refresh, setRefresh] = useState(0)
  const [category, setCategory] = useState('')
  const [summary, setSummary] = useState({ total: 0, low: 0, expiring: 0, stockValue: 0 })
  const canManage = ['SUPER_ADMIN', 'ADMIN', 'PHARMACIST'].includes(user?.role || '')

  const analyze = (rows: Med[]) => {
    const soon = Date.now() + 30 * 24 * 3600 * 1000
    setSummary({
      total: rows.length,
      low: rows.filter((m) => m.stockQty <= m.reorderLevel).length,
      expiring: rows.filter((m) => m.expiryDate && new Date(m.expiryDate).getTime() < soon).length,
      stockValue: rows.reduce((s, m) => s + m.stockQty * m.unitPrice, 0),
    })
  }

  const fields: FormField[] = editing
    ? [
        { name: 'name', label: 'Medicine name', type: 'text', required: true, defaultValue: editing.name },
        { name: 'category', label: 'Category', type: 'text', required: true, defaultValue: editing.category },
        { name: 'manufacturer', label: 'Manufacturer', type: 'text', defaultValue: editing.manufacturer },
        { name: 'unit', label: 'Unit', type: 'text', defaultValue: editing.unit, placeholder: 'strip / bottle / vial' },
        { name: 'unitPrice', label: 'Unit price ($)', type: 'number', required: true, min: 0, step: '0.01', defaultValue: editing.unitPrice },
        { name: 'stockQty', label: 'Stock quantity', type: 'number', required: true, min: 0, defaultValue: editing.stockQty },
        { name: 'reorderLevel', label: 'Reorder level', type: 'number', required: true, min: 0, defaultValue: editing.reorderLevel },
        { name: 'batchNo', label: 'Batch number', type: 'text', defaultValue: editing.batchNo },
        { name: 'expiryDate', label: 'Expiry date', type: 'date', defaultValue: editing.expiryDate?.slice(0, 10) },
      ]
    : [
        { name: 'name', label: 'Medicine name', type: 'text', required: true },
        { name: 'category', label: 'Category', type: 'text', required: true, placeholder: 'Antibiotic, Analgesic...' },
        { name: 'manufacturer', label: 'Manufacturer', type: 'text' },
        { name: 'unit', label: 'Unit', type: 'text', defaultValue: 'strip' },
        { name: 'unitPrice', label: 'Unit price ($)', type: 'number', required: true, min: 0, step: '0.01' },
        { name: 'stockQty', label: 'Stock quantity', type: 'number', required: true, min: 0 },
        { name: 'reorderLevel', label: 'Reorder level', type: 'number', required: true, min: 0, defaultValue: 20 },
        { name: 'batchNo', label: 'Batch number', type: 'text' },
        { name: 'expiryDate', label: 'Expiry date', type: 'date' },
      ]

  const submit = async (values: Record<string, any>) => {
    try {
      if (editing) {
        await api(`/api/medicines/${editing.id}`, { method: 'PUT', body: JSON.stringify(values) })
        toast.success('Medicine updated')
      } else {
        await api('/api/medicines', { method: 'POST', body: JSON.stringify(values) })
        toast.success('Medicine added to inventory')
      }
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message || 'Save failed')
      throw e
    }
  }

  const remove = async (m: Med) => {
    if (!confirm(`Remove ${m.name} from inventory?`)) return
    try {
      await api(`/api/medicines/${m.id}`, { method: 'DELETE' })
      toast.success('Medicine removed')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const columns: Column<Med>[] = [
    {
      key: 'name', header: 'Medicine',
      render: (m) => (
        <div>
          <p className="font-semibold">{m.name}</p>
          <p className="text-xs text-muted-foreground">{m.manufacturer || '—'} · {m.batchNo || '—'}</p>
        </div>
      ),
    },
    { key: 'category', header: 'Category', render: (m) => <Badge variant="outline">{m.category}</Badge> },
    { key: 'unitPrice', header: 'Price', render: (m) => money(m.unitPrice), hideOnMobile: true },
    {
      key: 'stockQty', header: 'Stock',
      render: (m) => {
        const low = m.stockQty <= m.reorderLevel
        return (
          <span className={low ? 'inline-flex items-center gap-1 font-semibold text-rose-600 dark:text-rose-400' : 'font-semibold tabular-nums'}>
            {low && <AlertTriangle className="h-3.5 w-3.5" />} {m.stockQty}
            <span className="text-xs font-normal text-muted-foreground">/{m.unit}</span>
          </span>
        )
      },
    },
    {
      key: 'expiryDate', header: 'Expiry',
      render: (m) => {
        if (!m.expiryDate) return '—'
        const soon = Date.now() + 30 * 24 * 3600 * 1000
        const expiredSoon = new Date(m.expiryDate).getTime() < soon
        return <span className={expiredSoon ? 'font-medium text-amber-600 dark:text-amber-400' : ''}>{fmtDate(m.expiryDate)}</span>
      },
      hideOnMobile: true,
    },
    { key: 'reorder', header: 'Status', render: (m) => <StatusBadge status={m.stockQty <= m.reorderLevel ? 'PENDING' : 'ACTIVE'} /> },
  ]

  return (
    <div className="space-y-5">
      <PageHeader
        icon={Package} title="Pharmacy Management" subtitle="Medicine inventory, stock levels and expiry tracking"
        actions={canManage && (
          <Button onClick={() => { setEditing(null); setFormOpen(true) }}>
            <Plus className="mr-2 h-4 w-4" /> Add medicine
          </Button>
        )}
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Medicines" value={summary.total} icon={Warehouse} tone="teal" />
        <StatCard title="Low stock" value={summary.low} icon={PackageX} tone={summary.low ? 'rose' : 'default'} hint="At or below reorder level" />
        <StatCard title="Expiring ≤30 days" value={summary.expiring} icon={AlertTriangle} tone={summary.expiring ? 'amber' : 'default'} />
        <StatCard title="Inventory value" value={money(summary.stockValue)} icon={Package} tone="cyan" />
      </div>

      <DataTable
        endpoint="/api/medicines"
        columns={columns}
        searchPlaceholder="Search medicine, category, batch..."
        refreshKey={refresh + category.length}
        extraQuery={{ category: category || undefined }}
        onData={analyze}
        emptyTitle="No medicines in inventory"
        emptyIcon={Package}
        toolbar={
          <select className="h-9 rounded-md border bg-transparent px-2.5 text-sm" value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Filter by category">
            <option value="">All categories</option>
            {[...new Set(['Analgesic', 'Antibiotic', 'Antidiabetic', 'Antihypertensive', 'Bronchodilator', 'Antacid', 'Statin', 'Antihistamine', 'Sedative', 'Corticosteroid', 'Supplement', 'Rehydration'])].map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        }
        rowActions={(m) => canManage && (
          <>
            <Button variant="ghost" size="icon" title="Edit / restock" onClick={() => { setEditing(m); setFormOpen(true) }}><Pencil className="h-4 w-4" /></Button>
            <Button variant="ghost" size="icon" title="Remove" onClick={() => remove(m)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
          </>
        )}
      />
      <FormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? `Edit ${editing.name}` : 'Add medicine'}
        description={editing ? 'Adjust stock levels, pricing and expiry.' : 'New inventory item with reorder threshold.'}
        fields={fields}
        initial={editing || undefined}
        submitLabel={editing ? 'Save changes' : 'Add medicine'}
        onSubmit={submit}
      />
    </div>
  )
}
