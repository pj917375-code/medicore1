'use client'
/**
 * Appointment management: booking, rescheduling, status workflow
 * (confirm → complete / cancel / no-show) with doctor & department pickers.
 */
import { useEffect, useState } from 'react'
import { CalendarDays, Plus, CheckCircle2, XCircle, Clock, Ban, UserX, Pencil } from 'lucide-react'
import { DataTable, type Column } from '@/components/hms/data-table'
import { FormDialog, type FormField } from '@/components/hms/form-dialog'
import { PageHeader, StatusBadge } from '@/components/hms/ui'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/lib/client/store'
import { api, fmtDateTime } from '@/lib/client/api'
import { toast } from 'sonner'

interface Appt { id: string; code: string; scheduledAt: string; durationMinutes: number; reason?: string; status: string; patient: { firstName: string; lastName: string; code: string }; doctor: { user: { name: string }; specialization: string }; department?: { name: string }; [k: string]: any }
interface DoctorRow { id: string; user: { name: string }; specialization: string; departmentId?: string; consultationFee: number }
interface PatientRow { id: string; firstName: string; lastName: string; code: string }

export function AppointmentsView() {
  const { user } = useAuth()
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<Appt | null>(null)
  const [refresh, setRefresh] = useState(0)
  const [doctors, setDoctors] = useState<DoctorRow[]>([])
  const [patients, setPatients] = useState<PatientRow[]>([])
  const [statusFilter, setStatusFilter] = useState<string>('')
  const canManage = ['SUPER_ADMIN', 'ADMIN', 'RECEPTIONIST', 'DOCTOR'].includes(user?.role || '')

  useEffect(() => {
    api('/api/doctors?pageSize=100').then(({ data }) => setDoctors(data)).catch(() => {})
    if (canManage) api('/api/patients?pageSize=100').then(({ data }) => setPatients(data)).catch(() => {})
  }, [refresh, canManage])

  const doctorOptions = doctors.map((d) => ({ value: d.id, label: `Dr. ${d.user.name} — ${d.specialization}` }))
  const patientOptions = patients.map((p) => ({ value: p.id, label: `${p.firstName} ${p.lastName} (${p.code})` }))

  const fields: FormField[] = editing
    ? [
        { name: 'scheduledAt', label: 'Date & time', type: 'datetime', required: true, defaultValue: editing.scheduledAt?.slice(0, 16) },
        { name: 'durationMinutes', label: 'Duration (min)', type: 'number', min: 5, max: 480, defaultValue: editing.durationMinutes || 30 },
        { name: 'reason', label: 'Reason for visit', type: 'textarea', colSpan: 2, defaultValue: editing.reason },
        { name: 'notes', label: 'Notes', type: 'textarea', colSpan: 2, defaultValue: editing.notes },
        { name: 'status', label: 'Status', type: 'select', defaultValue: editing.status, options: ['SCHEDULED', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'NO_SHOW'].map((s) => ({ value: s, label: s.replace('_', ' ') })) },
      ]
    : [
        ...(user?.role === 'PATIENT' ? [] : [{ name: 'patientId', label: 'Patient', type: 'select' as const, required: true, optionsFrom: () => patientOptions }]),
        { name: 'doctorId', label: 'Doctor', type: 'select', required: true, optionsFrom: () => doctorOptions },
        { name: 'scheduledAt', label: 'Date & time', type: 'datetime', required: true },
        { name: 'durationMinutes', label: 'Duration (min)', type: 'number', min: 5, max: 480, defaultValue: 30 },
        { name: 'reason', label: 'Reason for visit', type: 'textarea', colSpan: 2 },
      ]

  const submit = async (values: Record<string, any>) => {
    const payload: any = {
      ...values,
      scheduledAt: values.scheduledAt ? new Date(values.scheduledAt).toISOString() : undefined,
    }
    try {
      if (editing) {
        await api(`/api/appointments/${editing.id}`, { method: 'PUT', body: JSON.stringify(payload) })
        toast.success('Appointment updated')
      } else {
        await api('/api/appointments', { method: 'POST', body: JSON.stringify(payload) })
        toast.success('Appointment booked — notifications sent')
      }
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message || 'Booking failed')
      throw e
    }
  }

  const setStatus = async (a: Appt, status: string) => {
    try {
      await api(`/api/appointments/${a.id}`, { method: 'PUT', body: JSON.stringify({ status }) })
      toast.success(`Appointment ${a.code} ${status === 'NO_SHOW' ? 'marked as no-show' : status.toLowerCase()}`)
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const cancel = async (a: Appt) => {
    if (!confirm(`Cancel appointment ${a.code}?`)) return
    try {
      await api(`/api/appointments/${a.id}`, { method: 'PUT', body: JSON.stringify({ status: 'CANCELLED' }) })
      toast.success('Appointment cancelled')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const columns: Column<Appt>[] = [
    { key: 'code', header: 'ID', render: (a) => <span className="font-mono text-xs">{a.code}</span>, hideOnMobile: true },
    { key: 'patient', header: 'Patient', render: (a) => <span className="font-medium">{a.patient?.firstName} {a.patient?.lastName}</span> },
    { key: 'doctor', header: 'Doctor', render: (a) => <span>Dr. {a.doctor?.user?.name}</span> },
    { key: 'scheduledAt', header: 'Scheduled', render: (a) => fmtDateTime(a.scheduledAt) },
    { key: 'status', header: 'Status', render: (a) => <StatusBadge status={a.status} /> },
  ]

  return (
    <div className="space-y-5">
      <PageHeader
        icon={CalendarDays} title="Appointment Management" subtitle="Book, reschedule and track appointments"
        actions={
          <Button onClick={() => { setEditing(null); setFormOpen(true) }}>
            <Plus className="mr-2 h-4 w-4" /> Book appointment
          </Button>
        }
      />
      <DataTable
        endpoint="/api/appointments"
        columns={columns}
        searchPlaceholder="Search by reason or ID..."
        refreshKey={refresh + statusFilter.length}
        extraQuery={{ status: statusFilter || undefined }}
        emptyTitle="No appointments found"
        emptyIcon={CalendarDays}
        toolbar={
          <select
            className="h-9 rounded-md border bg-transparent px-2.5 text-sm"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            aria-label="Filter by status"
          >
            <option value="">All statuses</option>
            {['SCHEDULED', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'NO_SHOW'].map((s) => (
              <option key={s} value={s}>{s.replace('_', ' ')}</option>
            ))}
          </select>
        }
        rowActions={(a) => (
          <>
            {canManage && a.status === 'SCHEDULED' && (
              <Button variant="ghost" size="icon" title="Confirm" onClick={() => setStatus(a, 'CONFIRMED')}><CheckCircle2 className="h-4 w-4 text-teal-600" /></Button>
            )}
            {canManage && ['SCHEDULED', 'CONFIRMED'].includes(a.status) && (
              <>
                <Button variant="ghost" size="icon" title="Mark completed" onClick={() => setStatus(a, 'COMPLETED')}><Clock className="h-4 w-4 text-emerald-600" /></Button>
                <Button variant="ghost" size="icon" title="No-show" onClick={() => setStatus(a, 'NO_SHOW')}><UserX className="h-4 w-4 text-amber-600" /></Button>
                <Button variant="ghost" size="icon" title="Reschedule / edit" onClick={() => { setEditing(a); setFormOpen(true) }}><Pencil className="h-4 w-4" /></Button>
              </>
            )}
            {['SCHEDULED', 'CONFIRMED'].includes(a.status) && (
              <Button variant="ghost" size="icon" title="Cancel" onClick={() => cancel(a)}><Ban className="h-4 w-4 text-destructive" /></Button>
            )}
          </>
        )}
      />
      <FormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? `Reschedule ${editing.code}` : 'Book new appointment'}
        fields={fields}
        initial={editing || undefined}
        submitLabel={editing ? 'Save changes' : 'Book appointment'}
        onSubmit={submit}
      />
    </div>
  )
}
