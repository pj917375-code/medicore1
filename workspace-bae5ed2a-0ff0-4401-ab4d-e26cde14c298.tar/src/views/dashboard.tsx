'use client'
/**
 * Role-specific dashboards. The /api/dashboard/statistics endpoint returns
 * facility scope for staff roles and personal scope for patients.
 */
import { useEffect, useState, useCallback } from 'react'
import {
  Users, Stethoscope, CalendarDays, BedDouble, Receipt, Activity, HeartPulse,
  Pill, FlaskConical, Clock, DollarSign, ClipboardList, TrendingUp, Loader2,
  Package, CreditCard,
} from 'lucide-react'
import { StatCard, PageHeader, StatusBadge, EmptyState, TableSkeleton } from '@/components/hms/ui'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ChartCard, RevenueChart, AppointmentsChart, DepartmentPie } from '@/components/hms/charts'
import { useAuth } from '@/lib/client/store'
import { api, money, fmtDateTime, fmtTime, fullName } from '@/lib/client/api'
import { toast } from 'sonner'

interface Stats { [k: string]: any }

export function DashboardView({ onNavigate }: { onNavigate: (v: string) => void }) {
  const { user } = useAuth()
  const [stats, setStats] = useState<Stats | null>(null)
  const [revenue, setRevenue] = useState<any>(null)
  const [apptChart, setApptChart] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await api<Stats>('/api/dashboard/statistics')
      setStats(data)
      if (['SUPER_ADMIN', 'ADMIN', 'DOCTOR'].includes(user?.role || '')) {
        api('/api/dashboard/revenue').then(({ data }) => setRevenue(data)).catch(() => {})
      }
      if (user?.role !== 'PHARMACIST') {
        api('/api/dashboard/appointments').then(({ data }) => setApptChart(data)).catch(() => {})
      }
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }, [user?.role])

  useEffect(() => {
    load()
  }, [load])

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => <TableSkeleton key={i} rows={2} cols={1} />)}
        </div>
        <TableSkeleton rows={6} />
      </div>
    )
  }
  if (!stats) return <EmptyState title="Unable to load dashboard" />

  if (stats.scope === 'patient') return <PatientDashboard stats={stats} onNavigate={onNavigate} />

  return (
    <div className="space-y-5">
      <PageHeader
        icon={HeartPulse}
        title={`Welcome back, ${user?.name.split(' ')[0]}`}
        subtitle={new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
        actions={
          <>
            <Button variant="outline" onClick={load}><Activity className="mr-2 h-4 w-4" /> Refresh</Button>
            <Button onClick={() => onNavigate('appointments')}><CalendarDays className="mr-2 h-4 w-4" /> Today's schedule</Button>
          </>
        }
      />

      {/* KPI cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Total Patients" value={stats.totalPatients ?? 0} icon={Users} tone="teal" trend={`+${stats.newPatients30d ?? 0} this month`} />
        <StatCard title="Active Doctors" value={stats.totalDoctors ?? 0} icon={Stethoscope} tone="cyan" hint={`${stats.totalStaff ?? 0} supporting staff`} />
        <StatCard title="Today's Appointments" value={stats.todayAppointments ?? 0} icon={CalendarDays} hint={`${stats.upcomingAppointments ?? 0} upcoming`} />
        <StatCard title="Bed Occupancy" value={`${stats.occupancyRate ?? 0}%`} icon={BedDouble} tone={stats.occupancyRate > 85 ? 'rose' : 'default'} hint={`${stats.availableBeds ?? 0}/${stats.totalBeds ?? 0} beds free`} />
        <StatCard title="Revenue Collected" value={money(stats.totalRevenue)} icon={DollarSign} tone="teal" hint={`${money(stats.billedRevenue)} billed`} />
        <StatCard title="Outstanding Balance" value={money(stats.outstandingBalance)} icon={CreditCard} tone={stats.unpaidInvoices > 0 ? 'amber' : 'default'} hint={`${stats.unpaidInvoices ?? 0} unpaid invoices`} />
        <StatCard title="Active Admissions" value={stats.totalAdmissions ?? 0} icon={ClipboardList} hint={`${stats.dischargedPatients ?? 0} discharged`} />
        <StatCard title="Pending Workflows" value={(stats.pendingPrescriptions ?? 0) + (stats.pendingLabs ?? 0)} icon={Clock} tone="amber" hint={`${stats.pendingPrescriptions ?? 0} Rx · ${stats.pendingLabs ?? 0} labs`} />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        {revenue && (
          <ChartCard title="Revenue — billed vs collected (12 months)" className="xl:col-span-2">
            <RevenueChart data={revenue.monthly} />
          </ChartCard>
        )}
        {apptChart && apptChart.byDepartment?.length > 0 && (
          <ChartCard title="Appointments by department">
            <DepartmentPie data={apptChart.byDepartment.slice(0, 6)} />
          </ChartCard>
        )}
      </div>
      {apptChart && <ChartCard title="Appointment volume (last 2 weeks + week ahead)"><AppointmentsChart data={apptChart.daily} /></ChartCard>}

      {/* Recent activity */}
      <Card className="animate-fade-up">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
            <TrendingUp className="h-4 w-4" /> Recent hospital activity
          </CardTitle>
        </CardHeader>
        <CardContent className="max-h-72 space-y-2 overflow-y-auto scrollbar-thin pt-0">
          {(stats.recentActivity || []).length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">No activity recorded yet</p>
          ) : (
            stats.recentActivity.map((a: any) => (
              <div key={a.id} className="flex items-start justify-between gap-3 rounded-lg border px-3 py-2">
                <div className="min-w-0">
                  <p className="text-sm">
                    <span className="font-semibold">{a.userName || 'System'}</span>{' '}
                    <span className="text-muted-foreground">{a.action.toLowerCase()} · {a.entity}</span>
                  </p>
                  {a.details && <p className="truncate text-xs text-muted-foreground">{a.details}</p>}
                </div>
                <span className="shrink-0 text-xs text-muted-foreground">{fmtDateTime(a.createdAt)}</span>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function PatientDashboard({ stats, onNavigate }: { stats: Stats; onNavigate: (v: string) => void }) {
  return (
    <div className="space-y-5">
      <PageHeader icon={HeartPulse} title="My health dashboard" subtitle="Your appointments, prescriptions and billing at a glance" />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="My Appointments" value={stats.myAppointments ?? 0} icon={CalendarDays} hint={`${stats.upcomingAppointments ?? 0} upcoming`} />
        <StatCard title="Prescriptions" value={stats.myPrescriptions ?? 0} icon={Pill} tone="teal" />
        <StatCard title="Lab Tests" value={stats.myLabTests ?? 0} icon={FlaskConical} tone="cyan" />
        <StatCard title="Outstanding Balance" value={money(stats.outstandingBalance)} icon={Receipt} tone={stats.outstandingBalance > 0 ? 'amber' : 'default'} />
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <Button variant="outline" className="h-24 flex-col gap-2" onClick={() => onNavigate('appointments')}>
          <CalendarDays className="h-6 w-6 text-primary" /> Book an appointment
        </Button>
        <Button variant="outline" className="h-24 flex-col gap-2" onClick={() => onNavigate('emr')}>
          <ClipboardList className="h-6 w-6 text-primary" /> View my records
        </Button>
        <Button variant="outline" className="h-24 flex-col gap-2" onClick={() => onNavigate('billing')}>
          <Receipt className="h-6 w-6 text-primary" /> Pay invoices
        </Button>
      </div>
    </div>
  )
}
