'use client'
/**
 * Billing & Payments: invoice generation from service line items,
 * payment recording with auto status, printable receipts.
 */
import { useState } from 'react'
import { Receipt, Plus, Printer, Ban, Wallet, Loader2, Trash2 } from 'lucide-react'
import { DataTable, type Column } from '@/components/hms/data-table'
import { PageHeader, StatusBadge, StatCard } from '@/components/hms/ui'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useAuth } from '@/lib/client/store'
import { api, money, fmtDate } from '@/lib/client/api'
import { toast } from 'sonner'

interface Item { description: string; type: string; quantity: number; unitPrice: number }
interface Inv { id: string; invoiceNo: string; items: string; subtotal: number; tax: number; total: number; amountPaid: number; status: string; dueDate?: string; createdAt: string; notes?: string; patient: { firstName: string; lastName: string; code: string; email?: string }; payments: { id: string; amount: number; method: string; reference?: string; paidAt: string }[]; [k: string]: any }

export function BillingView() {
  const { user } = useAuth()
  const [refresh, setRefresh] = useState(0)
  const [patients, setPatients] = useState<any[]>([])
  const [createOpen, setCreateOpen] = useState(false)
  const [payFor, setPayFor] = useState<Inv | null>(null)
  const [payAmount, setPayAmount] = useState('')
  const [payMethod, setPayMethod] = useState('CASH')
  const [payRef, setPayRef] = useState('')
  const [paySaving, setPaySaving] = useState(false)
  const [receiptFor, setReceiptFor] = useState<Inv | null>(null)
  const [create, setCreate] = useState<{ patientId: string; items: Item[]; tax: string; dueDate: string }>({ patientId: '', items: [{ description: '', type: 'CONSULTATION', quantity: 1, unitPrice: 0 }], tax: '5', dueDate: '' })
  const [creating, setCreating] = useState(false)
  const [statusFilter, setStatusFilter] = useState('')

  const canBill = ['SUPER_ADMIN', 'ADMIN', 'RECEPTIONIST'].includes(user?.role || '')

  const loadPatients = () => api('/api/patients?pageSize=100').then(({ data }) => setPatients(data)).catch(() => {})

  const parseItems = (inv: Inv): Item[] => {
    try {
      return JSON.parse(inv.items)
    } catch {
      return []
    }
  }

  const generateInvoice = async () => {
    const items = create.items.filter((i) => i.description.trim() && i.unitPrice > 0)
    if (!create.patientId) return toast.error('Please select a patient')
    if (items.length === 0) return toast.error('Add at least one line item with description and price')
    setCreating(true)
    try {
      await api('/api/invoices', {
        method: 'POST',
        body: JSON.stringify({
          patientId: create.patientId, items,
          tax: Number(create.tax) || 0,
          dueDate: create.dueDate || undefined,
        }),
      })
      toast.success('Invoice generated and patient notified')
      setCreateOpen(false)
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message || 'Failed to create invoice')
    } finally {
      setCreating(false)
    }
  }

  const recordPayment = async () => {
    if (!payFor) return
    const amount = Number(payAmount)
    if (!amount || amount <= 0) return toast.error('Enter a valid payment amount')
    setPaySaving(true)
    try {
      await api(`/api/invoices/${payFor.id}/payments`, {
        method: 'POST',
        body: JSON.stringify({ amount, method: payMethod, reference: payRef || undefined }),
      })
      toast.success(`Payment of ${money(amount)} recorded`)
      setPayFor(null)
      setPayAmount(''); setPayRef('')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setPaySaving(false)
    }
  }

  const cancelInvoice = async (inv: Inv) => {
    if (!confirm(`Cancel invoice ${inv.invoiceNo}?`)) return
    try {
      await api(`/api/invoices/${inv.id}`, { method: 'PUT', body: JSON.stringify({ status: 'CANCELLED' }) })
      toast.success('Invoice cancelled')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const columns: Column<Inv>[] = [
    { key: 'invoiceNo', header: 'Invoice', render: (i) => <span className="font-mono text-xs font-semibold">{i.invoiceNo}</span> },
    { key: 'patient', header: 'Patient', render: (i) => <span className="font-medium">{i.patient?.firstName} {i.patient?.lastName}</span> },
    { key: 'total', header: 'Total', render: (i) => <span className="font-semibold tabular-nums">{money(i.total)}</span> },
    { key: 'amountPaid', header: 'Paid', render: (i) => <span className="tabular-nums text-teal-600 dark:text-teal-400">{money(i.amountPaid)}</span> },
    { key: 'createdAt', header: 'Issued', render: (i) => fmtDate(i.createdAt), hideOnMobile: true },
    { key: 'status', header: 'Status', render: (i) => <StatusBadge status={i.status} /> },
  ]

  const outstanding = receiptFor ? +(receiptFor.total - receiptFor.amountPaid).toFixed(2) : 0

  return (
    <div className="space-y-5">
      <PageHeader
        icon={Receipt} title="Billing & Payments" subtitle="Invoices, payment records and printable receipts"
        actions={canBill && (
          <Button onClick={() => { setCreateOpen(true); loadPatients(); setCreate({ patientId: '', items: [{ description: '', type: 'CONSULTATION', quantity: 1, unitPrice: 0 }], tax: '5', dueDate: '' }) }}>
            <Plus className="mr-2 h-4 w-4" /> New invoice
          </Button>
        )}
      />

      <DataTable
        endpoint="/api/invoices"
        columns={columns}
        searchPlaceholder="Search invoice number..."
        refreshKey={refresh + statusFilter.length}
        extraQuery={{ status: statusFilter || undefined }}
        onRowClick={setReceiptFor}
        emptyTitle="No invoices"
        emptyIcon={Receipt}
        toolbar={
          <select className="h-9 rounded-md border bg-transparent px-2.5 text-sm" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label="Filter by status">
            <option value="">All statuses</option>
            {['UNPAID', 'PARTIALLY_PAID', 'PAID', 'CANCELLED'].map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
          </select>
        }
        rowActions={(i) => (
          <>
            {canBill && ['UNPAID', 'PARTIALLY_PAID'].includes(i.status) && (
              <Button variant="ghost" size="icon" title="Record payment" onClick={() => { setPayFor(i); setPayAmount(String(+(i.total - i.amountPaid).toFixed(2))) }}>
                <Wallet className="h-4 w-4 text-emerald-600" />
              </Button>
            )}
            <Button variant="ghost" size="icon" title="Print receipt" onClick={() => setReceiptFor(i)}><Printer className="h-4 w-4" /></Button>
            {canBill && i.status !== 'CANCELLED' && (
              <Button variant="ghost" size="icon" title="Cancel invoice" onClick={() => cancelInvoice(i)}><Ban className="h-4 w-4 text-destructive" /></Button>
            )}
          </>
        )}
      />

      {/* Create invoice dialog */}
      <Dialog open={createOpen} onOpenChange={(o) => !creating && setCreateOpen(o)}>
        <DialogContent className="scrollbar-thin max-h-[85vh] overflow-y-auto sm:max-w-xl">
          <DialogHeader><DialogTitle>Generate invoice</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Patient *</label>
                <select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={create.patientId} onChange={(e) => setCreate({ ...create, patientId: e.target.value })}>
                  <option value="">Select patient...</option>
                  {patients.map((p) => <option key={p.id} value={p.id}>{p.firstName} {p.lastName} ({p.code})</option>)}
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Due date</label>
                <input type="date" className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={create.dueDate} onChange={(e) => setCreate({ ...create, dueDate: e.target.value })} />
              </div>
            </div>
            {create.items.map((it, i) => (
              <div key={i} className="grid grid-cols-2 gap-2 rounded-lg border p-3 sm:grid-cols-8">
                <input className="col-span-2 rounded-md border bg-transparent px-2 py-1.5 text-sm sm:col-span-3" placeholder="Description" value={it.description} onChange={(e) => setCreate({ ...create, items: create.items.map((x, j) => (i === j ? { ...x, description: e.target.value } : x)) })} />
                <select className="col-span-2 rounded-md border bg-transparent px-2 py-1.5 text-sm sm:col-span-2" value={it.type} onChange={(e) => setCreate({ ...create, items: create.items.map((x, j) => (i === j ? { ...x, type: e.target.value } : x)) })}>
                  {['CONSULTATION', 'LABORATORY', 'PHARMACY', 'ROOM', 'PROCEDURE', 'OTHER'].map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
                <input type="number" min={1} className="rounded-md border bg-transparent px-2 py-1.5 text-sm" placeholder="Qty" value={it.quantity} onChange={(e) => setCreate({ ...create, items: create.items.map((x, j) => (i === j ? { ...x, quantity: Number(e.target.value) } : x)) })} />
                <input type="number" min={0} step="0.01" className="rounded-md border bg-transparent px-2 py-1.5 text-sm" placeholder="Price" value={it.unitPrice} onChange={(e) => setCreate({ ...create, items: create.items.map((x, j) => (i === j ? { ...x, unitPrice: Number(e.target.value) } : x)) })} />
                <Button variant="ghost" size="icon" className="justify-self-end" onClick={() => setCreate({ ...create, items: create.items.filter((_, j) => j !== i) })} title="Remove item">
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            ))}
            <div className="flex items-center justify-between">
              <Button variant="outline" size="sm" onClick={() => setCreate({ ...create, items: [...create.items, { description: '', type: 'OTHER', quantity: 1, unitPrice: 0 }] })}>+ Add item</Button>
              <p className="text-sm">
                Subtotal <span className="font-semibold">{money(create.items.reduce((s, i) => s + i.quantity * i.unitPrice, 0))}</span> · Tax%{' '}
                <input type="number" min={0} className="ml-1 w-16 rounded-md border bg-transparent px-2 py-1 text-sm" value={create.tax} onChange={(e) => setCreate({ ...create, tax: e.target.value })} />
              </p>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setCreateOpen(false)} disabled={creating}>Cancel</Button>
              <Button onClick={generateInvoice} disabled={creating}>
                {creating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Generate invoice
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment dialog */}
      <Dialog open={!!payFor} onOpenChange={(o) => !o && setPayFor(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Record payment — {payFor?.invoiceNo}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Total {money(payFor?.total)} · Paid {money(payFor?.amountPaid)} · Outstanding{' '}
              <span className="font-semibold text-foreground">{money(payFor ? payFor.total - payFor.amountPaid : 0)}</span>
            </p>
            <input type="number" min={0.01} step="0.01" className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" placeholder="Amount" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} />
            <select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={payMethod} onChange={(e) => setPayMethod(e.target.value)}>
              {['CASH', 'CARD', 'BANK_TRANSFER', 'INSURANCE', 'MOBILE_MONEY'].map((m) => <option key={m} value={m}>{m.replace(/_/g, ' ')}</option>)}
            </select>
            <input className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" placeholder="Reference (optional)" value={payRef} onChange={(e) => setPayRef(e.target.value)} />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setPayFor(null)}>Cancel</Button>
              <Button onClick={recordPayment} disabled={paySaving}>
                {paySaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Record payment
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Receipt dialog (printable) */}
      <Dialog open={!!receiptFor} onOpenChange={(o) => !o && setReceiptFor(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              Receipt {receiptFor?.invoiceNo}
              <StatusBadge status={receiptFor?.status} />
            </DialogTitle>
          </DialogHeader>
          {receiptFor && (
            <div className="space-y-3 text-sm">
              <div className="rounded-xl border p-4" id="receipt-print">
                <div className="mb-3 flex items-center justify-between border-b pb-3">
                  <div>
                    <p className="font-bold">MediCore Hospital</p>
                    <p className="text-xs text-muted-foreground">100 Health Ave, Springfield</p>
                  </div>
                  <div className="text-right text-xs text-muted-foreground">
                    <p>{fmtDate(receiptFor.createdAt)}</p>
                    <p>{receiptFor.patient.code}</p>
                  </div>
                </div>
                <p className="mb-2"><span className="text-muted-foreground">Billed to:</span> <span className="font-medium">{receiptFor.patient.firstName} {receiptFor.patient.lastName}</span></p>
                <table className="w-full">
                  <tbody>
                    {parseItems(receiptFor).map((it, i) => (
                      <tr key={i} className="border-b border-dashed">
                        <td className="py-1.5">{it.description} <span className="text-muted-foreground">×{it.quantity}</span></td>
                        <td className="py-1.5 text-right tabular-nums">{money(it.quantity * it.unitPrice)}</td>
                      </tr>
                    ))}
                    <tr><td className="pt-2">Subtotal</td><td className="pt-2 text-right tabular-nums">{money(receiptFor.subtotal)}</td></tr>
                    <tr><td>Tax</td><td className="text-right tabular-nums">{money(receiptFor.tax)}</td></tr>
                    <tr className="font-bold"><td>Total</td><td className="text-right tabular-nums">{money(receiptFor.total)}</td></tr>
                    <tr className="text-teal-600 dark:text-teal-400"><td>Amount paid</td><td className="text-right tabular-nums">{money(receiptFor.amountPaid)}</td></tr>
                    <tr className="font-semibold"><td>Outstanding</td><td className="text-right tabular-nums">{money(Math.max(0, receiptFor.total - receiptFor.amountPaid))}</td></tr>
                  </tbody>
                </table>
                {receiptFor.payments?.length > 0 && (
                  <div className="mt-3 border-t pt-2 text-xs text-muted-foreground">
                    {receiptFor.payments.map((p) => (
                      <p key={p.id}>{fmtDate(p.paidAt)} — {money(p.amount)} via {p.method.replace(/_/g, ' ')} {p.reference && `(${p.reference})`}</p>
                    ))}
                  </div>
                )}
              </div>
              <Button className="w-full" onClick={() => window.print()}><Printer className="mr-2 h-4 w-4" /> Print receipt</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
