'use client'
/**
 * Reports & Analytics: operational charts + CSV exports.
 */
import { useEffect, useState } from 'react'
import { BarChart3, Download, TrendingUp, BedDouble, DollarSign } from 'lucide-react'
import { PageHeader } from '@/components/hms/ui'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ChartCard, RevenueChart, AppointmentsChart, DepartmentPie, PaymentMethodsChart, OccupancyChart } from '@/components/hms/charts'
import { api, money } from '@/lib/client/api'
import { toast } from 'sonner'

export function ReportsView() {
  const [revenue, setRevenue] = useState<any>(null)
  const [appt, setAppt] = useState<any>(null)
  const [wards, setWards] = useState<any[]>([])

  useEffect(() => {
    api('/api/dashboard/revenue').then(({ data }) => setRevenue(data)).catch(() => {})
    api('/api/dashboard/appointments').then(({ data }) => setAppt(data)).catch(() => {})
    api('/api/wards').then(({ data }) => setWards(data)).catch(() => {})
  }, [])

  const exportCsv = async (type: string) => {
    try {
      const token = localStorage.getItem('hms_token')
      const res = await fetch(`/api/export?type=${type}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      if (!res.ok) throw new Error('Export failed')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `medicore-${type}-${new Date().toISOString().slice(0, 10)}.csv`
      a.click()
      URL.revokeObjectURL(url)
      toast.success(`${type} report exported as CSV`)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const occupancyData = wards.map((w) => ({ ward: w.name.length > 12 ? `${w.name.slice(0, 12)}…` : w.name, occupied: w.occupiedBeds, available: w.availableBeds }))
  const occupancyRate = wards.length ? Math.round((wards.reduce((s, w) => s + w.occupiedBeds, 0) / Math.max(1, wards.reduce((s, w) => s + w.totalBeds, 0))) * 100) : 0

  return (
    <div className="space-y-5">
      <PageHeader icon={BarChart3} title="Reports & Analytics" subtitle="Operational insights and exportable reports" />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {['patients', 'appointments', 'invoices', 'payments', 'medicines', 'lab-tests'].map((t) => (
          <Button key={t} variant="outline" className="h-16 flex-col gap-1" onClick={() => exportCsv(t)}>
            <Download className="h-4 w-4 text-primary" />
            <span className="text-xs capitalize">{t.replace('-', ' ')}</span>
          </Button>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        {revenue && (
          <ChartCard title="Revenue trend (12 months)" className="xl:col-span-2">
            <RevenueChart data={revenue.monthly} />
          </ChartCard>
        )}
        {revenue && revenue.paymentMethods?.length > 0 && (
          <ChartCard title="Revenue by payment method">
            <PaymentMethodsChart data={revenue.paymentMethods} />
          </ChartCard>
        )}
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        {appt && (
          <ChartCard title="Appointment volume (21 days)" className="xl:col-span-2">
            <AppointmentsChart data={appt.daily} />
          </ChartCard>
        )}
        {appt && appt.byDepartment?.length > 0 && (
          <ChartCard title="Department distribution">
            <DepartmentPie data={appt.byDepartment} />
          </ChartCard>
        )}
      </div>

      {occupancyData.length > 0 && (
        <Card className="animate-fade-up">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center justify-between text-sm font-semibold text-muted-foreground">
              <span className="flex items-center gap-2"><BedDouble className="h-4 w-4" /> Ward occupancy</span>
              <span className="flex items-center gap-1.5 text-foreground"><DollarSign className="h-4 w-4" /> Facility occupancy: <strong>{occupancyRate}%</strong></span>
            </CardTitle>
          </CardHeader>
          <CardContent className="h-64 pt-0"><OccupancyChart data={occupancyData} /></CardContent>
        </Card>
      )}
    </div>
  )
}
