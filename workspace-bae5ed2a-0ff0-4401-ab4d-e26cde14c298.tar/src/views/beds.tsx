'use client'
/**
 * Ward & bed management: live bed map per ward, admissions with
 * transactional bed assignment, transfers and discharge.
 */
import { useEffect, useState, useCallback } from 'react'
import { BedDouble, Plus, LogIn, ArrowRightLeft, LogOut, Loader2, RefreshCw } from 'lucide-react'
import { PageHeader, StatCard, StatusBadge, TableSkeleton } from '@/components/hms/ui'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/lib/client/store'
import { api, money, fmtDateTime, fullName } from '@/lib/client/api'
import { toast } from 'sonner'

interface BedRow { id: string; bedNumber: string; status: string; dailyRate: number; ward: { id: string; name: string; type: string }; admissions: { id: string; patient: { firstName: string; lastName: string; code: string }; admittedAt: string }[] }
interface WardRow { id: string; name: string; type: string; floor?: string; totalBeds: number; occupiedBeds: number; availableBeds: number; occupancyRate: number }
interface AdmRow { id: string; status: string; reason?: string; admittedAt: string; dischargedAt?: string; notes?: string; patient: { firstName: string; lastName: string; code: string }; bed: { bedNumber: string; ward: { name: string } }; doctor?: { user: { name: string } } }

export function BedsView() {
  const { user } = useAuth()
  const [wards, setWards] = useState<WardRow[]>([])
  const [beds, setBeds] = useState<BedRow[]>([])
  const [admissions, setAdmissions] = useState<AdmRow[]>([])
  const [loading, setLoading] = useState(true)
  const [admitOpen, setAdmitOpen] = useState(false)
  const [admitForm, setAdmitForm] = useState({ patientId: '', bedId: '', doctorId: '', reason: '' })
  const [patients, setPatients] = useState<any[]>([])
  const [doctors, setDoctors] = useState<any[]>([])
  const [busy, setBusy] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [refresh, setRefresh] = useState(0)

  const canAdmit = ['SUPER_ADMIN', 'ADMIN', 'NURSE', 'DOCTOR'].includes(user?.role || '')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [w, b, a] = await Promise.all([
        api('/api/wards'),
        api('/api/beds?pageSize=100'),
        api('/api/admissions?pageSize=20'),
      ])
      setWards(w.data)
      setBeds(b.data)
      setAdmissions(a.data)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }, [refresh])

  useEffect(() => { load() }, [load])

  const openAdmit = async () => {
    setAdmitOpen(true)
    try {
      const [p, d] = await Promise.all([api('/api/patients?pageSize=100'), api('/api/doctors?pageSize=100')])
      setPatients(p.data)
      setDoctors(d.data)
    } catch {}
  }

  const admit = async () => {
    if (!admitForm.patientId) return toast.error('Select a patient')
    if (!admitForm.bedId) return toast.error('Select an available bed')
    setSaving(true)
    try {
      await api('/api/admissions', { method: 'POST', body: JSON.stringify({ ...admitForm, doctorId: admitForm.doctorId || undefined }) })
      toast.success('Patient admitted — bed marked occupied')
      setAdmitOpen(false)
      setAdmitForm({ patientId: '', bedId: '', doctorId: '', reason: '' })
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setSaving(false)
    }
  }

  const transfer = async (a: AdmRow) => {
    const freeBeds = beds.filter((b) => b.status === 'AVAILABLE')
    if (freeBeds.length === 0) return toast.error('No available beds for transfer')
    const label = prompt(`Transfer to bed — available: ${freeBeds.map((b) => `${b.ward.name}/${b.bedNumber}`).join(', ')}\nEnter exact bed number:`)
    if (!label) return
    const bed = freeBeds.find((b) => `${b.ward.name}/${b.bedNumber}` === label.trim() || b.bedNumber === label.trim())
    if (!bed) return toast.error('Bed not found among available beds')
    setBusy(a.id)
    try {
      await api(`/api/admissions/${a.id}`, { method: 'PUT', body: JSON.stringify({ bedId: bed.id }) })
      toast.success(`${fullName(a.patient)} transferred to ${bed.bedNumber}`)
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setBusy(null)
    }
  }

  const discharge = async (a: AdmRow) => {
    if (!confirm(`Discharge ${fullName(a.patient)} from ${a.bed.bedNumber}?`)) return
    setBusy(a.id)
    try {
      await api(`/api/admissions/${a.id}`, { method: 'PUT', body: JSON.stringify({ status: 'DISCHARGED' }) })
      toast.success('Patient discharged — bed available again')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setBusy(null)
    }
  }

  const totalBeds = beds.length
  const occupied = beds.filter((b) => b.status === 'OCCUPIED').length
  const available = beds.filter((b) => b.status === 'AVAILABLE').length
  const activeAdmissions = admissions.filter((a) => a.status === 'ADMITTED')

  return (
    <div className="space-y-5">
      <PageHeader
        icon={BedDouble} title="Wards & Bed Management" subtitle="Live occupancy, admissions, transfers and discharges"
        actions={
          <>
            <Button variant="outline" onClick={load}><RefreshCw className="mr-2 h-4 w-4" /> Refresh</Button>
            {canAdmit && <Button onClick={openAdmit}><LogIn className="mr-2 h-4 w-4" /> Admit patient</Button>}
          </>
        }
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Total beds" value={totalBeds} icon={BedDouble} tone="teal" />
        <StatCard title="Available" value={available} icon={BedDouble} tone="cyan" />
        <StatCard title="Occupied" value={occupied} icon={BedDouble} tone="rose" hint={`${totalBeds ? Math.round((occupied / totalBeds) * 100) : 0}% occupancy`} />
        <StatCard title="Active admissions" value={activeAdmissions.length} icon={LogIn} />
      </div>

      {/* Ward bed map */}
      {loading ? (
        <TableSkeleton rows={6} />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {wards.map((w) => (
            <Card key={w.id} className="animate-fade-up">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center justify-between text-sm">
                  <span>{w.name}</span>
                  <Badge variant="outline" className="font-normal text-muted-foreground">{w.type}{w.floor && ` · F${w.floor}`}</Badge>
                </CardTitle>
                <p className="text-xs text-muted-foreground">{w.occupiedBeds}/{w.totalBeds} occupied · {w.occupancyRate}%</p>
              </CardHeader>
              <CardContent className="grid grid-cols-4 gap-2">
                {beds.filter((b) => b.ward.id === w.id).map((b) => {
                  const occ = b.status === 'OCCUPIED'
                  const maint = b.status === 'MAINTENANCE'
                  return (
                    <div
                      key={b.id}
                      title={`${b.bedNumber} · ${b.status} · ${money(b.dailyRate)}/day${occ && b.admissions[0] ? ` · ${fullName(b.admissions[0].patient)}` : ''}`}
                      className={`rounded-lg border p-2 text-center text-xs transition-transform hover:scale-105 ${
                        occ ? 'border-rose-300 bg-rose-50 text-rose-700 dark:border-rose-500/40 dark:bg-rose-500/10 dark:text-rose-300'
                          : maint ? 'border-slate-300 bg-slate-100 text-slate-600 dark:border-slate-500/40 dark:bg-slate-500/10 dark:text-slate-300'
                            : 'border-emerald-300 bg-emerald-50 text-emerald-700 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-300'
                      }`}
                    >
                      <p className="font-bold">{b.bedNumber}</p>
                      <p className="text-[10px]">{occ ? fullName(b.admissions[0]?.patient).split(' ')[0] || 'Occupied' : b.status === 'AVAILABLE' ? 'Free' : 'Maint.'}</p>
                    </div>
                  )
                })}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Admissions table */}
      <Card className="animate-fade-up">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-semibold text-muted-foreground">Recent admissions</CardTitle></CardHeader>
        <CardContent className="space-y-2 pt-0">
          {admissions.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">No admissions yet</p>}
          {admissions.map((a) => (
            <div key={a.id} className="flex flex-col gap-2 rounded-lg border p-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <p className="font-medium">{fullName(a.patient)} <span className="text-xs text-muted-foreground">{a.patient.code}</span></p>
                <p className="text-xs text-muted-foreground">
                  {a.bed.ward.name} / {a.bed.bedNumber} · Admitted {fmtDateTime(a.admittedAt)}
                  {a.dischargedAt && ` · Discharged ${fmtDateTime(a.dischargedAt)}`}
                  {a.doctor && ` · Dr. ${a.doctor.user.name}`}
                </p>
                {a.reason && <p className="text-xs text-muted-foreground">Reason: {a.reason}</p>}
              </div>
              <div className="flex items-center gap-2">
                <StatusBadge status={a.status} />
                {canAdmit && a.status === 'ADMITTED' && (
                  <>
                    <Button variant="outline" size="sm" onClick={() => transfer(a)} disabled={busy === a.id}>
                      {busy === a.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ArrowRightLeft className="h-3.5 w-3.5" />} Transfer
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => discharge(a)} disabled={busy === a.id}>
                      {busy === a.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <LogOut className="h-3.5 w-3.5" />} Discharge
                    </Button>
                  </>
                )}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Admit dialog */}
      <Dialog open={admitOpen} onOpenChange={setAdmitOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle>Admit patient</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Patient *</label>
              <select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={admitForm.patientId} onChange={(e) => setAdmitForm({ ...admitForm, patientId: e.target.value })}>
                <option value="">Select patient...</option>
                {patients.map((p) => <option key={p.id} value={p.id}>{p.firstName} {p.lastName} ({p.code})</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Available bed *</label>
              <select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={admitForm.bedId} onChange={(e) => setAdmitForm({ ...admitForm, bedId: e.target.value })}>
                <option value="">Select bed...</option>
                {beds.filter((b) => b.status === 'AVAILABLE').map((b) => (
                  <option key={b.id} value={b.id}>{b.ward.name} / {b.bedNumber} — {money(b.dailyRate)}/day</option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Attending doctor</label>
              <select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={admitForm.doctorId} onChange={(e) => setAdmitForm({ ...admitForm, doctorId: e.target.value })}>
                <option value="">Select doctor (optional)...</option>
                {doctors.map((d) => <option key={d.id} value={d.id}>Dr. {d.user.name}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Reason for admission</label>
              <input className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={admitForm.reason} onChange={(e) => setAdmitForm({ ...admitForm, reason: e.target.value })} placeholder="Post-operative care..." />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setAdmitOpen(false)}>Cancel</Button>
              <Button onClick={admit} disabled={saving}>
                {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Admit patient
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
