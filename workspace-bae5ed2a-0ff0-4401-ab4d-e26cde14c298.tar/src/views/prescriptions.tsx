'use client'
/**
 * Prescriptions: doctors issue e-prescriptions with line items;
 * pharmacists dispense (stock decrements atomically server-side).
 */
import { useEffect, useState } from 'react'
import { Pill, Plus, PackageCheck, Ban, Trash2, Loader2 } from 'lucide-react'
import { DataTable, type Column } from '@/components/hms/data-table'
import { FormDialog, type FormField } from '@/components/hms/form-dialog'
import { PageHeader, StatusBadge } from '@/components/hms/ui'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useAuth } from '@/lib/client/store'
import { api, fmtDateTime, fullName, money } from '@/lib/client/api'
import { toast } from 'sonner'

interface ItemRow { id: string; medicineName: string; dosage: string; frequency: string; duration: string; instructions?: string; dispensedQty: number; medicineId?: string }
interface RxRow { id: string; code: string; status: string; notes?: string; createdAt: string; patient: { firstName: string; lastName: string; code: string }; doctor: { user: { name: string } }; items: ItemRow[]; [k: string]: any }

export function PrescriptionsView() {
  const { user } = useAuth()
  const [formOpen, setFormOpen] = useState(false)
  const [refresh, setRefresh] = useState(0)
  const [patients, setPatients] = useState<any[]>([])
  const [medicines, setMedicines] = useState<any[]>([])
  const [detail, setDetail] = useState<RxRow | null>(null)
  const [busy, setBusy] = useState<string | null>(null)

  const role = user?.role
  const isDoctor = ['SUPER_ADMIN', 'ADMIN', 'DOCTOR'].includes(role || '')
  const isPharmacist = ['SUPER_ADMIN', 'ADMIN', 'PHARMACIST'].includes(role || '')

  useEffect(() => {
    if (isDoctor) {
      api('/api/patients?pageSize=100').then(({ data }) => setPatients(data)).catch(() => {})
      api('/api/medicines?pageSize=100').then(({ data }) => setMedicines(data)).catch(() => {})
    }
  }, [isDoctor, refresh])

  const dispense = async (rx: RxRow) => {
    setBusy(rx.id)
    try {
      await api(`/api/prescriptions/${rx.id}/dispense`, { method: 'POST' })
      toast.success(`Prescription ${rx.code} dispensed — inventory updated`)
      setRefresh((r) => r + 1)
      setDetail(null)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setBusy(null)
    }
  }

  const cancelRx = async (rx: RxRow) => {
    if (!confirm(`Cancel prescription ${rx.code}?`)) return
    try {
      await api(`/api/prescriptions/${rx.id}`, { method: 'PUT', body: JSON.stringify({ status: 'CANCELLED' }) })
      toast.success('Prescription cancelled')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const removeRx = async (rx: RxRow) => {
    if (!confirm(`Delete prescription ${rx.code}?`)) return
    try {
      await api(`/api/prescriptions/${rx.id}`, { method: 'DELETE' })
      toast.success('Prescription deleted')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const columns: Column<RxRow>[] = [
    { key: 'code', header: 'Rx ID', render: (r) => <span className="font-mono text-xs">{r.code}</span> },
    { key: 'patient', header: 'Patient', render: (r) => <span className="font-medium">{fullName(r.patient)}</span> },
    { key: 'doctor', header: 'Prescriber', render: (r) => `Dr. ${r.doctor?.user?.name}`, hideOnMobile: true },
    { key: 'items', header: 'Medicines', render: (r) => r.items.map((i) => i.medicineName).join(', ') },
    { key: 'createdAt', header: 'Issued', render: (r) => fmtDateTime(r.createdAt), hideOnMobile: true },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
  ]

  return (
    <div className="space-y-5">
      <PageHeader
        icon={Pill} title="Prescriptions" subtitle="E-prescriptions with dispensing workflow"
        actions={isDoctor && (
          <Button onClick={() => setFormOpen(true)}><Plus className="mr-2 h-4 w-4" /> New prescription</Button>
        )}
      />
      <DataTable
        endpoint="/api/prescriptions"
        columns={columns}
        searchPlaceholder="Search Rx ID..."
        refreshKey={refresh}
        emptyTitle="No prescriptions"
        emptyIcon={Pill}
        onRowClick={(r) => setDetail(r)}
        rowActions={(r) => (
          <>
            {isPharmacist && r.status === 'PENDING' && (
              <Button variant="ghost" size="icon" title="Dispense" onClick={() => dispense(r)}>
                <PackageCheck className="h-4 w-4 text-emerald-600" />
              </Button>
            )}
            {r.status === 'PENDING' && (
              <Button variant="ghost" size="icon" title="Cancel" onClick={() => cancelRx(r)}><Ban className="h-4 w-4 text-amber-600" /></Button>
            )}
            {['SUPER_ADMIN', 'ADMIN'].includes(role || '') && (
              <Button variant="ghost" size="icon" title="Delete" onClick={() => removeRx(r)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
            )}
          </>
        )}
      />

      {/* Detail dialog */}
      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between gap-2">
              Prescription {detail?.code} <StatusBadge status={detail?.status} />
            </DialogTitle>
          </DialogHeader>
          {detail && (
            <div className="space-y-3 text-sm">
              <p><span className="font-medium">Patient:</span> {fullName(detail.patient)} ({detail.patient.code}) · <span className="font-medium">By</span> Dr. {detail.doctor?.user?.name}</p>
              <div className="rounded-lg border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
                      <th className="px-3 py-2">Medicine</th>
                      <th className="px-3 py-2">Dosage</th>
                      <th className="px-3 py-2">Frequency</th>
                      <th className="px-3 py-2">Duration</th>
                    </tr>
                  </thead>
                  <tbody>
                    {detail.items.map((it) => (
                      <tr key={it.id} className="border-b last:border-0">
                        <td className="px-3 py-2 font-medium">{it.medicineName}</td>
                        <td className="px-3 py-2">{it.dosage}</td>
                        <td className="px-3 py-2">{it.frequency}</td>
                        <td className="px-3 py-2">{it.duration}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {detail.notes && <p className="text-muted-foreground">{detail.notes}</p>}
              {isPharmacist && detail.status === 'PENDING' && (
                <Button className="w-full" onClick={() => dispense(detail)} disabled={busy === detail.id}>
                  {busy === detail.id ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PackageCheck className="mr-2 h-4 w-4" />}
                  Dispense & decrement stock
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {isDoctor && (
        <PrescriptionForm
          open={formOpen}
          onOpenChange={setFormOpen}
          patients={patients}
          medicines={medicines}
          onDone={() => setRefresh((r) => r + 1)}
        />
      )}
    </div>
  )
}

/** Prescription builder with dynamic medicine line items. */
function PrescriptionForm({ open, onOpenChange, patients, medicines, onDone }: {
  open: boolean
  onOpenChange: (o: boolean) => void
  patients: any[]
  medicines: any[]
  onDone: () => void
}) {
  const [patientId, setPatientId] = useState('')
  const [doctorId, setDoctorId] = useState('')
  const [notes, setNotes] = useState('')
  const [items, setItems] = useState([{ medicineId: '', medicineName: '', dosage: '1 tablet', frequency: 'Twice daily', duration: '5 days', instructions: '' }])
  const [doctors, setDoctors] = useState<any[]>([])
  const [saving, setSaving] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (open) {
      api('/api/doctors?pageSize=100').then(({ data }) => setDoctors(data)).catch(() => {})
      setItems([{ medicineId: '', medicineName: '', dosage: '1 tablet', frequency: 'Twice daily', duration: '5 days', instructions: '' }])
      setPatientId(''); setDoctorId(''); setNotes(''); setErrors({})
    }
  }, [open])

  const addItem = () => setItems((v) => [...v, { medicineId: '', medicineName: '', dosage: '', frequency: '', duration: '', instructions: '' }])
  const removeItem = (idx: number) => setItems((v) => v.filter((_, i) => i !== idx))
  const setItem = (idx: number, patch: Partial<(typeof items)[0]>) =>
    setItems((v) => v.map((it, i) => (i === idx ? { ...it, ...patch } : it)))

  const submit = async () => {
    const errs: Record<string, string> = {}
    if (!patientId) errs.patientId = 'Patient is required'
    if (!doctorId) errs.doctorId = 'Prescriber is required'
    if (items.length === 0) errs.items = 'At least one medicine is required'
    items.forEach((it, i) => {
      if (!it.medicineId) errs[`item-${i}`] = 'Select a medicine'
      if (!it.dosage) errs[`dosage-${i}`] = 'Required'
      if (!it.frequency) errs[`frequency-${i}`] = 'Required'
      if (!it.duration) errs[`duration-${i}`] = 'Required'
    })
    if (Object.keys(errs).length) {
      setErrors(errs)
      return
    }
    setSaving(true)
    try {
      const payloadItems = items.map((it) => ({
        medicineId: it.medicineId,
        medicineName: medicines.find((m) => m.id === it.medicineId)?.name || it.medicineName,
        dosage: it.dosage, frequency: it.frequency, duration: it.duration, instructions: it.instructions || '',
      }))
      await api('/api/prescriptions', {
        method: 'POST',
        body: JSON.stringify({ patientId, doctorId, notes, items: payloadItems }),
      })
      toast.success('Prescription issued — pharmacy notified')
      onOpenChange(false)
      onDone()
    } catch (e: any) {
      toast.error(e.message || 'Save failed')
    } finally {
      setSaving(false)
    }
  }

  const err = (k: string) => errors[k] && <p className="text-xs font-medium text-destructive">{errors[k]}</p>

  return (
    <Dialog open={open} onOpenChange={(o) => !saving && onOpenChange(o)}>
      <DialogContent className="scrollbar-thin max-h-[85vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>New prescription</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Patient *</label>
              <select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={patientId} onChange={(e) => setPatientId(e.target.value)}>
                <option value="">Select patient...</option>
                {patients.map((p) => <option key={p.id} value={p.id}>{p.firstName} {p.lastName} ({p.code})</option>)}
              </select>
              {err('patientId')}
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Prescriber *</label>
              <select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={doctorId} onChange={(e) => setDoctorId(e.target.value)}>
                <option value="">Select doctor...</option>
                {doctors.map((d) => <option key={d.id} value={d.id}>Dr. {d.user.name}</option>)}
              </select>
              {err('doctorId')}
            </div>
          </div>

          <div className="space-y-3">
            {items.map((it, idx) => (
              <div key={idx} className="grid grid-cols-2 gap-2 rounded-lg border p-3 sm:grid-cols-12">
                <div className="col-span-2 space-y-1 sm:col-span-4">
                  <label className="text-xs font-medium text-muted-foreground">Medicine *</label>
                  <select
                    className="w-full rounded-md border bg-transparent px-2 py-1.5 text-sm"
                    value={it.medicineId}
                    onChange={(e) => {
                      const med = medicines.find((m) => m.id === e.target.value)
                      setItem(idx, { medicineId: e.target.value, medicineName: med?.name || '' })
                    }}
                  >
                    <option value="">Select...</option>
                    {medicines.map((m) => <option key={m.id} value={m.id}>{m.name} ({m.stockQty} in stock)</option>)}
                  </select>
                  {err(`item-${idx}`)}
                </div>
                <div className="space-y-1 sm:col-span-2">
                  <label className="text-xs font-medium text-muted-foreground">Dosage *</label>
                  <input className="w-full rounded-md border bg-transparent px-2 py-1.5 text-sm" value={it.dosage} onChange={(e) => setItem(idx, { dosage: e.target.value })} placeholder="1 tablet" />
                  {err(`dosage-${idx}`)}
                </div>
                <div className="space-y-1 sm:col-span-2">
                  <label className="text-xs font-medium text-muted-foreground">Frequency *</label>
                  <input className="w-full rounded-md border bg-transparent px-2 py-1.5 text-sm" value={it.frequency} onChange={(e) => setItem(idx, { frequency: e.target.value })} placeholder="Twice daily" />
                  {err(`frequency-${idx}`)}
                </div>
                <div className="space-y-1 sm:col-span-2">
                  <label className="text-xs font-medium text-muted-foreground">Duration *</label>
                  <input className="w-full rounded-md border bg-transparent px-2 py-1.5 text-sm" value={it.duration} onChange={(e) => setItem(idx, { duration: e.target.value })} placeholder="5 days" />
                  {err(`duration-${idx}`)}
                </div>
                <div className="space-y-1 sm:col-span-1">
                  <label className="text-xs font-medium text-muted-foreground">Instructions</label>
                  <input className="w-full rounded-md border bg-transparent px-2 py-1.5 text-sm" value={it.instructions} onChange={(e) => setItem(idx, { instructions: e.target.value })} placeholder="After food" />
                </div>
                <div className="flex items-end justify-end sm:col-span-1">
                  {items.length > 1 && (
                    <Button variant="ghost" size="icon" onClick={() => removeItem(idx)} title="Remove item">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" onClick={addItem}><Plus className="mr-1.5 h-3.5 w-3.5" /> Add medicine</Button>
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium">Notes</label>
            <textarea className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Take after meals unless directed otherwise" />
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>Cancel</Button>
            <Button onClick={submit} disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Issue prescription
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
