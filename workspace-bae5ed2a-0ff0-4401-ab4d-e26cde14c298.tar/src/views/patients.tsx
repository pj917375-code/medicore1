'use client'
/**
 * Patient management: registry with search/filter, register & edit,
 * 360° detail drawer (profile, appointments, records, Rx, labs,
 * invoices, documents with upload/download).
 */
import { useState } from 'react'
import { Users, Plus, Eye, Pencil, Trash2, FileText, Download, Upload, Loader2, Phone, Mail, MapPin, Droplets, ShieldAlert } from 'lucide-react'
import { DataTable, type Column } from '@/components/hms/data-table'
import { FormDialog, type FormField } from '@/components/hms/form-dialog'
import { PageHeader, StatusBadge, EmptyState } from '@/components/hms/ui'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { useAuth } from '@/lib/client/store'
import { api, money, fmtDate, fmtDateTime, fullName } from '@/lib/client/api'
import { toast } from 'sonner'

interface Patient { id: string; code: string; firstName: string; lastName: string; gender: string; phone?: string; email?: string; dob?: string; bloodGroup?: string; allergies?: string; chronicConditions?: string; address?: string; emergencyContactName?: string; emergencyContactPhone?: string; status: string; createdAt: string; [k: string]: any }

export function PatientsView() {
  const { user } = useAuth()
  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState<Patient | null>(null)
  const [selected, setSelected] = useState<Patient | null>(null)
  const [detail, setDetail] = useState<any>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [refresh, setRefresh] = useState(0)
  const [uploadOpen, setUploadOpen] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [docCategory, setDocCategory] = useState('REPORT')

  const canWrite = ['SUPER_ADMIN', 'ADMIN', 'RECEPTIONIST', 'DOCTOR'].includes(user?.role || '')

  const openDetail = async (p: Patient) => {
    setSelected(p)
    setDetailLoading(true)
    try {
      const { data } = await api(`/api/patients/${p.id}`)
      setDetail(data)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setDetailLoading(false)
    }
  }

  const fields: FormField[] = editing
    ? [
        { name: 'firstName', label: 'First name', type: 'text', required: true, defaultValue: editing.firstName },
        { name: 'lastName', label: 'Last name', type: 'text', required: true, defaultValue: editing.lastName },
        { name: 'dob', label: 'Date of birth', type: 'date', defaultValue: editing.dob?.slice(0, 10) },
        { name: 'gender', label: 'Gender', type: 'select', defaultValue: editing.gender, options: [{ value: 'MALE', label: 'Male' }, { value: 'FEMALE', label: 'Female' }, { value: 'OTHER', label: 'Other' }] },
        { name: 'bloodGroup', label: 'Blood group', type: 'select', defaultValue: editing.bloodGroup, options: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((v) => ({ value: v, label: v })) },
        { name: 'phone', label: 'Phone', type: 'text', defaultValue: editing.phone },
        { name: 'email', label: 'Email', type: 'email', defaultValue: editing.email },
        { name: 'address', label: 'Address', type: 'textarea', colSpan: 2, defaultValue: editing.address },
        { name: 'emergencyContactName', label: 'Emergency contact', type: 'text', defaultValue: editing.emergencyContactName },
        { name: 'emergencyContactPhone', label: 'Emergency phone', type: 'text', defaultValue: editing.emergencyContactPhone },
        { name: 'allergies', label: 'Allergies', type: 'textarea', colSpan: 2, defaultValue: editing.allergies, placeholder: 'Penicillin, latex...' },
        { name: 'chronicConditions', label: 'Chronic conditions', type: 'textarea', colSpan: 2, defaultValue: editing.chronicConditions },
        { name: 'insuranceProvider', label: 'Insurance provider', type: 'text', defaultValue: editing.insuranceProvider },
        { name: 'insuranceNumber', label: 'Insurance number', type: 'text', defaultValue: editing.insuranceNumber },
      ]
    : [
        { name: 'firstName', label: 'First name', type: 'text', required: true },
        { name: 'lastName', label: 'Last name', type: 'text', required: true },
        { name: 'dob', label: 'Date of birth', type: 'date' },
        { name: 'gender', label: 'Gender', type: 'select', required: true, defaultValue: 'MALE', options: [{ value: 'MALE', label: 'Male' }, { value: 'FEMALE', label: 'Female' }, { value: 'OTHER', label: 'Other' }] },
        { name: 'bloodGroup', label: 'Blood group', type: 'select', options: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((v) => ({ value: v, label: v })) },
        { name: 'phone', label: 'Phone', type: 'text' },
        { name: 'email', label: 'Email', type: 'email' },
        { name: 'address', label: 'Address', type: 'textarea', colSpan: 2 },
        { name: 'emergencyContactName', label: 'Emergency contact', type: 'text' },
        { name: 'emergencyContactPhone', label: 'Emergency phone', type: 'text' },
        { name: 'allergies', label: 'Allergies', type: 'textarea', colSpan: 2, placeholder: 'Penicillin, latex...' },
        { name: 'chronicConditions', label: 'Chronic conditions', type: 'textarea', colSpan: 2 },
      ]

  const submit = async (values: Record<string, any>) => {
    try {
      if (editing) {
        await api(`/api/patients/${editing.id}`, { method: 'PUT', body: JSON.stringify(values) })
        toast.success('Patient updated')
      } else {
        await api('/api/patients', { method: 'POST', body: JSON.stringify(values) })
        toast.success('Patient registered — unique ID generated')
      }
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message || 'Save failed')
      throw e
    }
  }

  const remove = async (p: Patient) => {
    if (!confirm(`Delete patient ${p.firstName} ${p.lastName} (${p.code})? This cannot be undone.`)) return
    try {
      await api(`/api/patients/${p.id}`, { method: 'DELETE' })
      toast.success('Patient deleted')
      setRefresh((r) => r + 1)
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const uploadDoc = async () => {
    if (!file || !selected) return toast.error('Please choose a file first')
    if (file.size > 5 * 1024 * 1024) return toast.error('File exceeds the 5 MB limit')
    setUploading(true)
    try {
      const reader = new FileReader()
      const base64 = await new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve((reader.result as string).split(',')[1])
        reader.onerror = reject
        reader.readAsDataURL(file)
      })
      await api('/api/documents', {
        method: 'POST',
        body: JSON.stringify({ patientId: selected.id, name: file.name, category: docCategory, mimeType: file.type || 'application/octet-stream', dataBase64: base64 }),
      })
      toast.success('Document uploaded')
      setUploadOpen(false)
      setFile(null)
      openDetail(selected)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setUploading(false)
    }
  }

  const columns: Column<Patient>[] = [
    {
      key: 'name', header: 'Patient',
      render: (p) => (
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9">
            <AvatarFallback className="bg-teal-600 text-xs font-bold text-white">{(p.firstName[0] + p.lastName[0]).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div>
            <p className="font-semibold">{fullName(p)}</p>
            <p className="text-xs text-muted-foreground">{p.code}</p>
          </div>
        </div>
      ),
    },
    { key: 'gender', header: 'Gender', render: (p) => <StatusBadge status={p.gender} />, hideOnMobile: true },
    { key: 'bloodGroup', header: 'Blood', render: (p) => (p.bloodGroup ? <span className="font-medium text-rose-600 dark:text-rose-400">{p.bloodGroup}</span> : '—'), hideOnMobile: true },
    { key: 'phone', header: 'Phone', render: (p) => p.phone || '—', hideOnMobile: true },
    { key: 'createdAt', header: 'Registered', render: (p) => fmtDate(p.createdAt), hideOnMobile: true },
    { key: 'status', header: 'Status', render: (p) => <StatusBadge status={p.status} /> },
  ]

  return (
    <div className="space-y-5">
      <PageHeader
        icon={Users} title="Patient Management" subtitle="Register, search and manage patient records"
        actions={canWrite && (
          <Button onClick={() => { setEditing(null); setFormOpen(true) }}>
            <Plus className="mr-2 h-4 w-4" /> Register patient
          </Button>
        )}
      />
      <DataTable
        endpoint="/api/patients"
        columns={columns}
        searchPlaceholder="Search by name, ID, phone, email..."
        refreshKey={refresh}
        emptyTitle="No patients found"
        emptyDescription="Register your first patient to get started"
        emptyIcon={Users}
        onRowClick={openDetail}
        rowActions={(p) => (
          <>
            <Button variant="ghost" size="icon" title="View 360° profile" onClick={() => openDetail(p)}><Eye className="h-4 w-4" /></Button>
            {canWrite && (
              <>
                <Button variant="ghost" size="icon" title="Edit" onClick={() => { setEditing(p); setFormOpen(true) }}><Pencil className="h-4 w-4" /></Button>
                {['SUPER_ADMIN', 'ADMIN'].includes(user?.role || '') && (
                  <Button variant="ghost" size="icon" title="Delete" onClick={() => remove(p)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                )}
              </>
            )}
          </>
        )}
      />

      <FormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editing ? `Edit ${fullName(editing)}` : 'Register new patient'}
        description={editing ? 'Update patient demographics and medical flags.' : 'A unique patient ID (P-XXXXXX) is generated automatically.'}
        fields={fields}
        initial={editing || undefined}
        submitLabel={editing ? 'Save changes' : 'Register patient'}
        onSubmit={submit}
      />

      {/* Patient 360° drawer */}
      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent className="scrollbar-thin w-full max-w-2xl overflow-y-auto sm:max-w-2xl">
          <SheetHeader className="pb-0">
            <SheetTitle className="flex items-center gap-3">
              <Avatar className="h-11 w-11">
                <AvatarFallback className="bg-teal-600 font-bold text-white">
                  {selected && (selected.firstName[0] + selected.lastName[0]).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                {fullName(selected)}
                <p className="text-xs font-normal text-muted-foreground">{selected?.code} · <StatusBadge status={selected?.gender} /></p>
              </div>
            </SheetTitle>
          </SheetHeader>
          {detailLoading || !detail ? (
            <div className="flex justify-center py-16"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : (
            <div className="mt-4 space-y-4">
              {/* Vitals summary */}
              <div className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-3">
                <InfoChip icon={Droplets} label="Blood group" value={detail.bloodGroup || '—'} />
                <InfoChip icon={Phone} label="Phone" value={detail.phone || '—'} />
                <InfoChip icon={Mail} label="Email" value={detail.email || '—'} />
                <InfoChip icon={MapPin} label="Address" value={detail.address || '—'} />
                <InfoChip icon={Phone} label="Emergency" value={detail.emergencyContactName ? `${detail.emergencyContactName} (${detail.emergencyContactPhone})` : '—'} />
                <InfoChip icon={ShieldAlert} label="Insurance" value={detail.insuranceProvider || 'Self-pay'} />
              </div>
              {(detail.allergies || detail.chronicConditions) && (
                <div className="rounded-xl border border-amber-300/60 bg-amber-50 p-3 text-sm dark:border-amber-500/30 dark:bg-amber-500/10">
                  {detail.allergies && <p><span className="font-semibold">Allergies:</span> {detail.allergies}</p>}
                  {detail.chronicConditions && <p><span className="font-semibold">Chronic conditions:</span> {detail.chronicConditions}</p>}
                </div>
              )}

              <Tabs defaultValue="records">
                <TabsList className="w-full flex-wrap">
                  <TabsTrigger value="records">Records</TabsTrigger>
                  <TabsTrigger value="appointments">Appointments</TabsTrigger>
                  <TabsTrigger value="prescriptions">Rx</TabsTrigger>
                  <TabsTrigger value="labs">Labs</TabsTrigger>
                  <TabsTrigger value="invoices">Invoices</TabsTrigger>
                  <TabsTrigger value="docs">Documents</TabsTrigger>
                </TabsList>

                <TabsContent value="records" className="space-y-2">
                  {detail.medicalRecords?.length === 0 && <p className="py-4 text-sm text-muted-foreground">No medical records yet</p>}
                  {detail.medicalRecords?.map((r: any) => (
                    <div key={r.id} className="rounded-lg border p-3 text-sm">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-semibold">{r.diagnosis}</p>
                        <StatusBadge status={r.visitType} />
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">Dr. {r.doctor?.user?.name} · {fmtDateTime(r.createdAt)}</p>
                      {r.symptoms && <p className="mt-1 text-xs">Symptoms: {r.symptoms}</p>}
                      {r.treatmentPlan && <p className="text-xs">Plan: {r.treatmentPlan}</p>}
                      <p className="mt-1 text-xs text-muted-foreground">
                        BP {r.bloodPressure || '—'} · HR {r.heartRate || '—'} bpm · Temp {r.temperature || '—'}°C · Wt {r.weight || '—'} kg
                      </p>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="appointments" className="space-y-2">
                  {detail.appointments?.length === 0 && <p className="py-4 text-sm text-muted-foreground">No appointments yet</p>}
                  {detail.appointments?.map((a: any) => (
                    <div key={a.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                      <div>
                        <p className="font-medium">Dr. {a.doctor?.user?.name}</p>
                        <p className="text-xs text-muted-foreground">{fmtDateTime(a.scheduledAt)} · {a.reason || '—'}</p>
                      </div>
                      <StatusBadge status={a.status} />
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="prescriptions" className="space-y-2">
                  {detail.prescriptions?.length === 0 && <p className="py-4 text-sm text-muted-foreground">No prescriptions yet</p>}
                  {detail.prescriptions?.map((rx: any) => (
                    <div key={rx.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                      <div>
                        <p className="font-medium">{rx.code}</p>
                        <p className="text-xs text-muted-foreground">{fmtDateTime(rx.createdAt)}</p>
                      </div>
                      <StatusBadge status={rx.status} />
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="labs" className="space-y-2">
                  {detail.labTests?.length === 0 && <p className="py-4 text-sm text-muted-foreground">No lab tests yet</p>}
                  {detail.labTests?.map((l: any) => (
                    <div key={l.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                      <div>
                        <p className="font-medium">{l.testName}</p>
                        <p className="text-xs text-muted-foreground">{l.code} · {fmtDate(l.requestedAt)}</p>
                      </div>
                      <StatusBadge status={l.status} />
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="invoices" className="space-y-2">
                  {detail.invoices?.length === 0 && <p className="py-4 text-sm text-muted-foreground">No invoices yet</p>}
                  {detail.invoices?.map((inv: any) => (
                    <div key={inv.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                      <div>
                        <p className="font-medium">{inv.invoiceNo}</p>
                        <p className="text-xs text-muted-foreground">{fmtDate(inv.createdAt)} · Total {money(inv.total)}</p>
                      </div>
                      <StatusBadge status={inv.status} />
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="docs" className="space-y-2">
                  <Button variant="outline" size="sm" onClick={() => setUploadOpen(true)}>
                    <Upload className="mr-2 h-4 w-4" /> Upload document
                  </Button>
                  {(detail.documents || []).length === 0 && <p className="py-2 text-sm text-muted-foreground">No documents uploaded yet</p>}
                  {detail.documents?.map((d: any) => (
                    <div key={d.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{d.name}</p>
                          <p className="text-xs text-muted-foreground">{d.category} · {(d.size / 1024).toFixed(0)} KB · {fmtDate(d.createdAt)}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" asChild>
                        <a href={`/api/documents/${d.id}`} target="_blank" rel="noreferrer" title="Download"><Download className="h-4 w-4" /></a>
                      </Button>
                    </div>
                  ))}
                </TabsContent>
              </Tabs>
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Upload dialog */}
      <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Upload medical document</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <select
              className="w-full rounded-md border bg-transparent px-3 py-2 text-sm"
              value={docCategory}
              onChange={(e) => setDocCategory(e.target.value)}
              aria-label="Document category"
            >
              {['REPORT', 'SCAN', 'PRESCRIPTION', 'OTHER'].map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <input
              type="file" accept=".pdf,.png,.jpg,.jpeg,.webp"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              className="w-full text-sm"
              aria-label="Choose file"
            />
            <p className="text-xs text-muted-foreground">PDF, PNG, JPEG or WebP — up to 5 MB</p>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setUploadOpen(false)}>Cancel</Button>
            <Button onClick={uploadDoc} disabled={uploading}>
              {uploading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Upload
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function InfoChip({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="rounded-lg border p-2.5">
      <p className="flex items-center gap-1.5 text-[11px] uppercase tracking-wide text-muted-foreground"><Icon className="h-3.5 w-3.5" /> {label}</p>
      <p className="mt-0.5 truncate text-sm font-medium">{value}</p>
    </div>
  )
}
