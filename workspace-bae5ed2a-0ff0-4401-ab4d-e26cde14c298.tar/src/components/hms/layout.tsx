'use client'
/**
 * HMS application shell: responsive sidebar navigation, topbar with
 * notifications (real-time via Socket.IO), theme toggle and user menu.
 */
import { useEffect, useState, useCallback } from 'react'
import { io, Socket } from 'socket.io-client'
import {
  LayoutDashboard, Users, Stethoscope, CalendarDays, ClipboardList, Pill,
  FlaskConical, Package, Receipt, BedDouble, UserCog, BarChart3, Bell,
  ShieldCheck, BookOpen, Settings, LogOut, Menu, Moon, Sun, HeartPulse,
} from 'lucide-react'
import { useTheme } from 'next-themes'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useAuth, type AuthUser } from '@/lib/client/store'
import { api, fmtDateTime } from '@/lib/client/api'
import { ROLE_PERMISSIONS, ROLE_LABELS, type Module } from '@/lib/rbac'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

const NAV: { key: Module; label: string; icon: any; href: string }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, href: 'dashboard' },
  { key: 'patients', label: 'Patients', icon: Users, href: 'patients' },
  { key: 'doctors', label: 'Doctors', icon: Stethoscope, href: 'doctors' },
  { key: 'appointments', label: 'Appointments', icon: CalendarDays, href: 'appointments' },
  { key: 'emr', label: 'Medical Records', icon: ClipboardList, href: 'emr' },
  { key: 'prescriptions', label: 'Prescriptions', icon: Pill, href: 'prescriptions' },
  { key: 'pharmacy', label: 'Pharmacy', icon: Package, href: 'pharmacy' },
  { key: 'laboratory', label: 'Laboratory', icon: FlaskConical, href: 'laboratory' },
  { key: 'billing', label: 'Billing & Payments', icon: Receipt, href: 'billing' },
  { key: 'beds', label: 'Wards & Beds', icon: BedDouble, href: 'beds' },
  { key: 'staff', label: 'Staff', icon: UserCog, href: 'staff' },
  { key: 'reports', label: 'Reports', icon: BarChart3, href: 'reports' },
  { key: 'notifications', label: 'Notifications', icon: Bell, href: 'notifications' },
  { key: 'users', label: 'User Accounts', icon: ShieldCheck, href: 'users' },
  { key: 'audit', label: 'Audit Logs', icon: ShieldCheck, href: 'audit' },
  { key: 'docs', label: 'API Docs', icon: BookOpen, href: 'docs' },
  { key: 'profile', label: 'My Profile', icon: Settings, href: 'profile' },
]

interface Notif { id: string; title: string; message: string; type: string; isRead: boolean; createdAt: string }

export function AppShell({ active, onNavigate, children }: { active: string; onNavigate: (view: string) => void; children: React.ReactNode }) {
  const { user, logout } = useAuth()
  const { theme, setTheme } = useTheme()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [notifs, setNotifs] = useState<Notif[]>([])
  const [bellOpen, setBellOpen] = useState(false)

  const loadNotifs = useCallback(async () => {
    try {
      const { data, meta } = await api<Notif[]>('/api/notifications')
      setNotifs(data)
    } catch {}
  }, [])

  useEffect(() => {
    const initial = setTimeout(loadNotifs, 0)
    const t = setInterval(loadNotifs, 30000)
    return () => {
      clearTimeout(initial)
      clearInterval(t)
    }
  }, [loadNotifs, active])

  // Real-time notifications (Socket.IO service on port 3003 via gateway)
  useEffect(() => {
    if (!user) return
    const socket: Socket = io('/?XTransformPort=3003', {
      path: '/',
      auth: { userId: user.id, role: user.role },
      transports: ['websocket', 'polling'],
    })
    socket.on('notification', (n: Notif) => {
      toast(n.title, { description: n.message })
      setNotifs((prev) => [n, ...prev].slice(0, 50))
    })
    return () => {
      socket.disconnect()
    }
  }, [user?.id])

  if (!user) return null
  const allowed = ROLE_PERMISSIONS[user.role] || []
  const items = NAV.filter((n) => allowed.includes(n.key))
  const unread = notifs.filter((n) => !n.isRead).length

  const markAllRead = async () => {
    try {
      await api(`/api/notifications/all`, { method: 'PUT', body: JSON.stringify({ markAllRead: true }) })
      loadNotifs()
    } catch {}
  }

  const navList = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-5 py-5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground">
          <HeartPulse className="h-5 w-5" />
        </div>
        <div>
          <p className="text-base font-bold tracking-tight text-sidebar-foreground">MediCore</p>
          <p className="text-[10px] font-medium uppercase tracking-widest text-sidebar-foreground/60">Health Suite</p>
        </div>
      </div>
      <ScrollArea className="scrollbar-thin flex-1 px-3 pb-4">
        <nav className="space-y-0.5" aria-label="Main navigation">
          {items.map((n) => (
            <button
              key={n.key}
              onClick={() => {
                onNavigate(n.href)
                setMobileOpen(false)
              }}
              className={cn(
                'flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                active === n.href
                  ? 'bg-sidebar-primary/20 text-sidebar-primary-foreground shadow-sm'
                  : 'text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-foreground'
              )}
              aria-current={active === n.href ? 'page' : undefined}
            >
              <n.icon className={cn('h-4 w-4', active === n.href && 'text-sidebar-primary')} />
              {n.label}
            </button>
          ))}
        </nav>
      </ScrollArea>
      <div className="border-t border-sidebar-border px-4 py-3">
        <p className="text-xs text-sidebar-foreground/60">Demo environment — seeded sample data</p>
      </div>
    </div>
  )

  return (
    <div className="flex min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 border-r border-sidebar-border bg-sidebar lg:block">
        {navList}
      </aside>

      {/* Mobile sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-64 border-sidebar-border bg-sidebar p-0 [&>button]:text-sidebar-foreground">
          <SheetTitle className="sr-only">Navigation menu</SheetTitle>
          {navList}
        </SheetContent>
      </Sheet>

      <div className="flex min-w-0 flex-1 flex-col lg:pl-60">
        {/* Topbar */}
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b bg-background/80 px-4 backdrop-blur sm:px-6">
          <div className="flex items-center gap-2">
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open navigation">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
            </Sheet>
            <span className="text-sm font-semibold text-muted-foreground">
              {items.find((i) => i.href === active)?.label || 'Dashboard'}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Theme toggle */}
            <Button
              variant="ghost" size="icon"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              aria-label="Toggle dark mode"
            >
              {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>

            {/* Notifications */}
            <Popover open={bellOpen} onOpenChange={(o) => { setBellOpen(o); if (o) loadNotifs() }}>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="relative" aria-label={`Notifications (${unread} unread)`}>
                  <Bell className="h-5 w-5" />
                  {unread > 0 && (
                    <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-teal-500 px-1 text-[10px] font-bold text-white">
                      {unread > 9 ? '9+' : unread}
                    </span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-80 p-0">
                <div className="flex items-center justify-between border-b px-4 py-2.5">
                  <p className="text-sm font-semibold">Notifications</p>
                  {unread > 0 && (
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={markAllRead}>
                      Mark all read
                    </Button>
                  )}
                </div>
                <ScrollArea className="scrollbar-thin max-h-80">
                  {notifs.length === 0 ? (
                    <p className="px-4 py-8 text-center text-sm text-muted-foreground">You are all caught up</p>
                  ) : (
                    notifs.map((n) => (
                      <div key={n.id} className={cn('border-b px-4 py-3 text-sm', !n.isRead && 'bg-accent/50')}>
                        <div className="flex items-start justify-between gap-2">
                          <p className="font-medium">{n.title}</p>
                          {!n.isRead && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-teal-500" />}
                        </div>
                        <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{n.message}</p>
                        <p className="mt-1 text-[11px] text-muted-foreground/70">{fmtDateTime(n.createdAt)}</p>
                      </div>
                    ))
                  )}
                </ScrollArea>
                <button
                  className="w-full border-t py-2 text-center text-xs font-medium text-primary hover:bg-accent"
                  onClick={() => { onNavigate('notifications'); setBellOpen(false) }}
                >
                  View all notifications
                </button>
              </PopoverContent>
            </Popover>

            {/* User menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className="flex items-center gap-2 rounded-full pl-1 pr-2 py-1 hover:bg-accent transition-colors"
                  aria-label="User menu"
                >
                  <span
                    className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold text-white"
                    style={{ background: user.avatarColor || 'var(--primary)' }}
                  >
                    {user.name.split(' ').map((s) => s[0]).slice(0, 2).join('')}
                  </span>
                  <span className="hidden text-left sm:block">
                    <span className="block max-w-32 truncate text-sm font-semibold leading-tight">{user.name}</span>
                    <span className="block text-[11px] leading-tight text-muted-foreground">{ROLE_LABELS[user.role]}</span>
                  </span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuLabel>
                  <p>{user.name}</p>
                  <p className="text-xs font-normal text-muted-foreground">{user.email}</p>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => onNavigate('profile')}>
                  <Settings className="mr-2 h-4 w-4" /> My profile
                </DropdownMenuItem>
                <DropdownMenuItem variant="destructive" onClick={() => logout()}>
                  <LogOut className="mr-2 h-4 w-4" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 sm:p-6">
          <div className="mx-auto w-full max-w-7xl space-y-5">{children}</div>
        </main>

        <footer className="mt-auto border-t px-6 py-3 text-center text-xs text-muted-foreground">
          MediCore HMS — Premium Health Management System · Demo environment with seeded data
        </footer>
      </div>
    </div>
  )
}
