'use client'
/**
 * Config-driven FormDialog: renders validated inputs from a field spec,
 * handles submit state and server-side validation errors (422 details).
 */
import { ReactNode, useEffect, useState } from 'react'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Loader2 } from 'lucide-react'

export type FieldType = 'text' | 'email' | 'number' | 'password' | 'textarea' | 'select' | 'date' | 'datetime' | 'checkbox' | 'file' | 'static'

export interface FormField {
  name: string
  label: string
  type: FieldType
  required?: boolean
  placeholder?: string
  options?: { value: string; label: string }[]
  optionsFrom?: () => { value: string; label: string }[]
  min?: number
  max?: number
  step?: string
  help?: string
  defaultValue?: any
  colSpan?: 1 | 2
  accept?: string
  disabled?: boolean
  validate?: (value: any, values: Record<string, any>) => string | null
}

export interface FormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  description?: string
  fields: FormField[]
  initial?: Record<string, any>
  submitLabel?: string
  onSubmit: (values: Record<string, any>) => Promise<void>
}

function validateField(f: FormField, value: any, values: Record<string, any>): string | null {
  const empty = value === undefined || value === null || value === '' || (f.type === 'file' && !value)
  if (f.required && empty) return `${f.label} is required`
  if (empty) return null
  if (f.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return 'Please enter a valid email address'
  if (f.type === 'number') {
    const n = Number(value)
    if (Number.isNaN(n)) return `${f.label} must be a number`
    if (f.min !== undefined && n < f.min) return `${f.label} must be at least ${f.min}`
    if (f.max !== undefined && n > f.max) return `${f.label} must be at most ${f.max}`
  }
  if (f.type === 'password') {
    if (value.length < 8) return 'Password must be at least 8 characters'
    if (!/[A-Z]/.test(value)) return 'Password must contain an uppercase letter'
    if (!/[0-9]/.test(value)) return 'Password must contain a number'
  }
  return f.validate ? f.validate(value, values) : null
}

export function FormDialog({
  open, onOpenChange, title, description, fields, initial, submitLabel = 'Save', onSubmit,
}: FormDialogProps) {
  const buildDefaults = () => {
    const v: Record<string, any> = {}
    for (const f of fields) {
      v[f.name] = initial?.[f.name] ?? f.defaultValue ?? (f.type === 'checkbox' ? false : '')
    }
    return v
  }
  const [values, setValues] = useState<Record<string, any>>(buildDefaults)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (open) {
      setValues(buildDefaults())
      setErrors({})
    }
  }, [open, initial])

  const setField = (name: string, value: any) => {
    setValues((v) => ({ ...v, [name]: value }))
    setErrors((e) => ({ ...e, [name]: '' }))
  }

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault()
    const nextErrors: Record<string, string> = {}
    for (const f of fields) {
      const err = validateField(f, values[f.name], values)
      if (err) nextErrors[f.name] = err
    }
    if (Object.keys(nextErrors).length) {
      setErrors(nextErrors)
      return
    }
    setSubmitting(true)
    try {
      await onSubmit(values)
      onOpenChange(false)
    } catch (err: any) {
      // Server-side validation (422) maps field paths to errors
      if (err?.details && Array.isArray(err.details)) {
        const serverErrors: Record<string, string> = {}
        for (const d of err.details) serverErrors[d.path] = d.message
        setErrors((e) => ({ ...e, ...serverErrors }))
      }
      throw err
    } finally {
      setSubmitting(false)
    }
  }

  const renderInput = (f: FormField) => {
    const err = errors[f.name]
    const common = 'aria-invalid={!!err}'
    switch (f.type) {
      case 'textarea':
        return (
          <Textarea
            value={values[f.name] || ''}
            onChange={(e) => setField(f.name, e.target.value)}
            placeholder={f.placeholder}
            rows={3}
            aria-invalid={!!err}
          />
        )
      case 'select': {
        const opts = f.options || f.optionsFrom?.() || []
        return (
          <Select value={String(values[f.name] ?? '')} onValueChange={(v) => setField(f.name, v)}>
            <SelectTrigger aria-invalid={!!err}>
              <SelectValue placeholder={f.placeholder || `Select ${f.label.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {opts.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      }
      case 'checkbox':
        return (
          <div className="flex items-center gap-2 py-1.5">
            <Checkbox
              id={`chk-${f.name}`}
              checked={!!values[f.name]}
              onCheckedChange={(v) => setField(f.name, !!v)}
            />
            <Label htmlFor={`chk-${f.name}`} className="font-normal cursor-pointer">{f.placeholder || f.label}</Label>
          </div>
        )
      case 'datetime':
        return (
          <Input
            type="datetime-local"
            value={values[f.name] || ''}
            onChange={(e) => setField(f.name, e.target.value)}
            aria-invalid={!!err}
          />
        )
      case 'date':
        return (
          <Input
            type="date"
            value={values[f.name]?.slice?.(0, 10) || values[f.name] || ''}
            onChange={(e) => setField(f.name, e.target.value)}
            aria-invalid={!!err}
          />
        )
      case 'file':
        return (
          <Input
            type="file"
            accept={f.accept}
            onChange={(e) => setField(f.name, e.target.files?.[0] || null)}
            aria-invalid={!!err}
          />
        )
      case 'number':
        return (
          <Input
            type="number"
            min={f.min}
            max={f.max}
            step={f.step}
            value={values[f.name] ?? ''}
            onChange={(e) => setField(f.name, e.target.value === '' ? '' : Number(e.target.value))}
            placeholder={f.placeholder}
            aria-invalid={!!err}
          />
        )
      case 'static':
        return <p className="text-sm text-muted-foreground py-1">{values[f.name] || f.placeholder || '—'}</p>
      default:
        return (
          <Input
            type={f.type === 'email' ? 'email' : f.type === 'password' ? 'password' : 'text'}
            value={values[f.name] || ''}
            onChange={(e) => setField(f.name, e.target.value)}
            placeholder={f.placeholder}
            aria-invalid={!!err}
          />
        )
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !submitting && onOpenChange(o)}>
      <DialogContent className="scrollbar-thin max-h-[85vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2" noValidate>
          {fields.map((f) => (
            <div
              key={f.name}
              className={`space-y-1.5 ${f.type === 'checkbox' ? 'sm:col-span-2' : f.colSpan === 2 ? 'sm:col-span-2' : ''}`}
            >
              {f.type !== 'checkbox' && (
                <Label htmlFor={`fld-${f.name}`}>
                  {f.label} {f.required && <span className="text-destructive">*</span>}
                </Label>
              )}
              {renderInput(f)}
              {f.help && !errors[f.name] && <p className="text-xs text-muted-foreground">{f.help}</p>}
              {errors[f.name] && <p className="text-xs font-medium text-destructive">{errors[f.name]}</p>}
            </div>
          ))}
          <DialogFooter className="col-span-full flex gap-2 pt-2 sm:justify-end">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {submitting ? 'Saving...' : submitLabel}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
