'use client'
/**
 * HMS shared UI primitives: stat cards, status badges, page headers,
 * empty states and search inputs.
 */
import { ReactNode } from 'react'
import { LucideIcon } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

export function PageHeader({
  title, subtitle, actions, icon: Icon,
}: { title: string; subtitle?: string; actions?: ReactNode; icon?: LucideIcon }) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        {Icon && (
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Icon className="h-5 w-5" />
          </div>
        )}
        <div>
          <h1 className="text-xl font-bold tracking-tight sm:text-2xl">{title}</h1>
          {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}

export function StatCard({
  title, value, icon: Icon, trend, hint, tone = 'default',
}: {
  title: string
  value: ReactNode
  icon: LucideIcon
  trend?: string
  hint?: string
  tone?: 'default' | 'teal' | 'amber' | 'rose' | 'cyan'
}) {
  const tones: Record<string, string> = {
    default: 'bg-primary/10 text-primary',
    teal: 'bg-teal-500/10 text-teal-600 dark:text-teal-400',
    cyan: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400',
    amber: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
    rose: 'bg-rose-500/10 text-rose-600 dark:text-rose-400',
  }
  return (
    <Card className="animate-fade-up transition-shadow hover:shadow-md">
      <CardContent className="flex items-start justify-between p-5">
        <div className="min-w-0">
          <p className="truncate text-xs font-medium uppercase tracking-wide text-muted-foreground">{title}</p>
          <p className="mt-1.5 truncate text-2xl font-bold tabular-nums">{value}</p>
          {trend && <p className="mt-1 text-xs font-medium text-teal-600 dark:text-teal-400">{trend}</p>}
          {hint && <p className="mt-1 truncate text-xs text-muted-foreground">{hint}</p>}
        </div>
        <div className={cn('flex h-11 w-11 shrink-0 items-center justify-center rounded-xl', tones[tone])}>
          <Icon className="h-5 w-5" />
        </div>
      </CardContent>
    </Card>
  )
}

const STATUS_STYLES: Record<string, string> = {
  // generic lifecycle
  SCHEDULED: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  CONFIRMED: 'bg-teal-100 text-teal-700 dark:bg-teal-500/15 dark:text-teal-300',
  COMPLETED: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  CANCELLED: 'bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300',
  NO_SHOW: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
  PENDING: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  DISPENSED: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  REQUESTED: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  SAMPLE_COLLECTED: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300',
  PROCESSING: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  REVIEWED: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  UNPAID: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
  PARTIALLY_PAID: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  PAID: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  AVAILABLE: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  OCCUPIED: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
  MAINTENANCE: 'bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300',
  ADMITTED: 'bg-teal-100 text-teal-700 dark:bg-teal-500/15 dark:text-teal-300',
  DISCHARGED: 'bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300',
  ACTIVE: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  INACTIVE: 'bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300',
  ON_LEAVE: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  TERMINATED: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
  PRESENT: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  ABSENT: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
  LEAVE: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  NORMAL: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
  HIGH: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
  LOW: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  CRITICAL: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
  URGENT: 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
  ROUTINE: 'bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300',
  MORNING: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  EVENING: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300',
  NIGHT: 'bg-slate-200 text-slate-700 dark:bg-slate-500/25 dark:text-slate-200',
  MALE: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300',
  FEMALE: 'bg-pink-100 text-pink-700 dark:bg-pink-500/15 dark:text-pink-300',
  OTHER: 'bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300',
}

export function StatusBadge({ status, className }: { status?: string | null; className?: string }) {
  if (!status) return <span className="text-muted-foreground">—</span>
  const style = STATUS_STYLES[status] || 'bg-slate-100 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300'
  return (
    <Badge variant="secondary" className={cn('font-medium', style, className)}>
      {status.replace(/_/g, ' ')}
    </Badge>
  )
}

export function EmptyState({ icon: Icon, title, description, action }: { icon?: LucideIcon; title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-14 text-center">
      {Icon && (
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-muted">
          <Icon className="h-7 w-7 text-muted-foreground" />
        </div>
      )}
      <div>
        <p className="font-semibold">{title}</p>
        {description && <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>}
      </div>
      {action}
    </div>
  )
}

export function TableSkeleton({ rows = 6, cols = 5 }: { rows?: number; cols?: number }) {
  return (
    <div className="space-y-2.5 p-4">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex gap-4">
          {Array.from({ length: cols }).map((_, j) => (
            <Skeleton key={j} className="h-9 flex-1" />
          ))}
        </div>
      ))}
    </div>
  )
}

export function CardSkeleton({ className }: { className?: string }) {
  return <Skeleton className={cn('h-28 rounded-xl', className)} />
}
