'use client'
/**
 * Generic DataTable: server-driven search, pagination, sorting hooks,
 * custom row actions, loading skeletons and empty states.
 */
import { ReactNode, useState, useCallback, useEffect, useRef } from 'react'
import { Search, RefreshCw, ChevronLeft, ChevronRight } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { TableSkeleton, EmptyState } from './ui'
import { api, qs, ApiMeta } from '@/lib/client/api'
import { toast } from 'sonner'

export interface Column<T> {
  key: string
  header: string
  render?: (row: T) => ReactNode
  className?: string
  hideOnMobile?: boolean
}

export interface DataTableProps<T> {
  endpoint: string
  columns: Column<T>[]
  rowKey?: (row: T) => string
  rowActions?: (row: T) => ReactNode
  onRowClick?: (row: T) => void
  searchPlaceholder?: string
  extraQuery?: Record<string, string | number | undefined>
  toolbar?: ReactNode
  emptyTitle?: string
  emptyDescription?: string
  emptyIcon?: any
  refreshKey?: number
  onData?: (rows: T[], meta?: ApiMeta) => void
  pageSize?: number
}

export function DataTable<T>({
  endpoint, columns, rowKey = (r: any) => r.id, rowActions, onRowClick,
  searchPlaceholder = 'Search...', extraQuery, toolbar, emptyTitle = 'No records found',
  emptyDescription, emptyIcon, refreshKey = 0, onData, pageSize = 10,
}: DataTableProps<T>) {
  const [rows, setRows] = useState<T[]>([])
  const [meta, setMeta] = useState<ApiMeta | undefined>()
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [debounced, setDebounced] = useState('')
  const [page, setPage] = useState(1)
  const timer = useRef<ReturnType<typeof setTimeout>>()

  useEffect(() => {
    timer.current = setTimeout(() => setDebounced(search), 350)
    return () => clearTimeout(timer.current)
  }, [search])

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const { data, meta: m } = await api<T[]>(`${endpoint}${qs({ page, pageSize, search: debounced || undefined, ...extraQuery })}`)
      setRows(data)
      setMeta(m)
      onData?.(data, m)
    } catch (e: any) {
      setError(e.message)
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }, [endpoint, page, pageSize, debounced, JSON.stringify(extraQuery || {}), refreshKey])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    setPage(1)
  }, [debounced])

  return (
    <Card className="overflow-hidden">
      <div className="flex flex-col gap-3 border-b p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={searchPlaceholder}
            className="pl-9"
            aria-label="Search table"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {toolbar}
          <Button variant="outline" size="icon" onClick={load} aria-label="Refresh" title="Refresh">
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {loading ? (
        <TableSkeleton cols={Math.min(columns.length, 6)} />
      ) : error ? (
        <EmptyState title="Failed to load data" description={error} />
      ) : rows.length === 0 ? (
        <EmptyState icon={emptyIcon} title={emptyTitle} description={emptyDescription} />
      ) : (
        <div className="scrollbar-thin overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                {columns.map((c) => (
                  <TableHead key={c.key} className={c.hideOnMobile ? 'hidden md:table-cell' : ''}>
                    {c.header}
                  </TableHead>
                ))}
                {rowActions && <TableHead className="text-right">Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((row) => (
                <TableRow
                  key={rowKey(row)}
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                  className={onRowClick ? 'cursor-pointer' : ''}
                >
                  {columns.map((c) => (
                    <TableCell key={c.key} className={c.className || (c.hideOnMobile ? 'hidden md:table-cell' : '')}>
                      {c.render ? c.render(row) : ((row as any)[c.key] ?? '—')}
                    </TableCell>
                  ))}
                  {rowActions && (
                    <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex justify-end gap-1">{rowActions(row)}</div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {meta && meta.totalPages > 1 && (
        <div className="flex flex-col items-center justify-between gap-2 border-t px-4 py-3 text-sm text-muted-foreground sm:flex-row">
          <span>
            Page {meta.page} of {meta.totalPages} · {meta.total} records
          </span>
          <div className="flex gap-1.5">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>
              <ChevronLeft className="h-4 w-4" /> Prev
            </Button>
            <Button variant="outline" size="sm" disabled={page >= meta.totalPages} onClick={() => setPage(page + 1)}>
              Next <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </Card>
  )
}
