/**
 * MediCore HMS — Real-time notification service (Socket.IO)
 *
 * Polls the shared SQLite database for new Notification rows and pushes
 * them to connected clients over WebSockets. Clients identify themselves
 * in the handshake (userId + role) and only receive notifications
 * addressed to them (personal or role broadcast).
 *
 * Port: 3003 (frontend connects via /?XTransformPort=3003)
 */
import { createServer } from 'http'
import { Server } from 'socket.io'
import { Database } from 'bun:sqlite'

const PORT = 3003
const DB_PATH = '/home/z/my-project/db/custom.db'

const httpServer = createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'application/json' })
  res.end(JSON.stringify({ ok: true, service: 'medicore-notification-service' }))
})

const io = new Server(httpServer, {
  // DO NOT change the path, Caddy forwards / to this service via XTransformPort
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// -- SQLite polling (readonly; Prisma owns writes) --
let sqlite: InstanceType<typeof Database> | null = null
try {
  sqlite = new Database(DB_PATH, { readonly: true })
  console.log('[notify-service] SQLite opened at', DB_PATH)
} catch (e) {
  console.error('[notify-service] Failed to open SQLite', e)
}

// Track high-water mark so we never replay old notifications
let lastSeen = new Date().toISOString()
try {
  if (sqlite) {
    const row: any = sqlite.prepare('SELECT MAX(createdAt) as m FROM Notification').get()
    if (row?.m) lastSeen = row.m
  }
} catch {}

interface ClientInfo { userId: string; role: string }

io.on('connection', (socket) => {
  const hs: any = socket.handshake.auth || {}
  const q: any = socket.handshake.query || {}
  const userId = hs.userId || q.userId
  const role = hs.role || q.role
  console.log('[notify-service] client connected', socket.id, userId, role)
  if (userId) socket.join(`user:${userId}`)
  if (role) socket.join(`role:${role}`)

  socket.on('disconnect', () => {
    console.log('[notify-service] client disconnected', socket.id)
  })
})

function emitNotification(n: any) {
  const payload = { ...n, isRead: !!n.isRead, createdAt: n.createdAt }
  if (n.userId) {
    io.to(`user:${n.userId}`).emit('notification', payload)
  }
  if (n.targetRoles) {
    for (const role of String(n.targetRoles).split(',')) {
      if (role.trim()) io.to(`role:${role.trim()}`).emit('notification', payload)
    }
  }
  if (!n.userId && !n.targetRoles) {
    io.emit('notification', payload)
  }
}

setInterval(() => {
  if (!sqlite) return
  try {
    const rows: any[] = sqlite
      .prepare('SELECT * FROM Notification WHERE createdAt > ? ORDER BY createdAt ASC LIMIT 50')
      .all(lastSeen)
    for (const row of rows) {
      emitNotification(row)
      lastSeen = row.createdAt > lastSeen ? row.createdAt : lastSeen
    }
    if (rows.length) console.log(`[notify-service] pushed ${rows.length} notification(s)`)
  } catch (e) {
    console.error('[notify-service] poll error', e)
  }
}, 2000)

httpServer.listen(PORT, () => {
  console.log(`[notify-service] Socket.IO notification service listening on :${PORT}`)
})
