#!/bin/bash
# Comprehensive API smoke test for MediCore HMS
BASE=http://localhost:3000
PASS=0; FAIL=0
check() { # name, expected_status, actual_status
  if [ "$2" == "$3" ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); echo "FAIL: $1 (expected $2, got $3)"; fi
}
token_for() {
  curl -s $BASE/api/auth/login -X POST -H 'Content-Type: application/json' -d "{\"email\":\"$1\",\"password\":\"Demo@1234\"}" | python3 -c "import sys,json;print(json.load(sys.stdin)['data']['token'])"
}
req() { # method path token [body]
  local code
  if [ -n "$4" ]; then
    code=$(curl -s -o /dev/null -w "%{http_code}" -X "$1" "$BASE$2" -H "Authorization: Bearer $3" -H 'Content-Type: application/json' -d "$4")
  else
    code=$(curl -s -o /dev/null -w "%{http_code}" -X "$1" "$BASE$2" -H "Authorization: Bearer $3")
  fi
  echo "$code"
}

ADMIN=$(token_for admin@medicore.com)
DOCTOR=$(token_for doctor@medicore.com)
NURSE=$(token_for nurse@medicore.com)
PHARM=$(token_for pharmacist@medicore.com)
LAB=$(token_for lab@medicore.com)
RECEPTION=$(token_for reception@medicore.com)
PATIENT=$(token_for patient@medicore.com)
echo "tokens: admin=${ADMIN:0:10}... patient=${PATIENT:0:10}..."

# --- Auth ---
check "login-bad-password" 401 $(curl -s -o /dev/null -w "%{http_code}" $BASE/api/auth/login -X POST -H 'Content-Type: application/json' -d '{"email":"admin@medicore.com","password":"wrong"}')
check "me" 200 $(req GET /api/auth/me $ADMIN)
check "unauthed-patients" 401 $(curl -s -o /dev/null -w "%{http_code}" $BASE/api/patients)

# --- Resources ---
check "patients-list" 200 $(req GET "/api/patients?pageSize=5" $ADMIN)
check "patients-search" 200 $(req GET "/api/patients?search=John" $ADMIN)
check "patient-create" 201 $(req POST /api/patients $ADMIN '{"firstName":"Test","lastName":"Case","gender":"MALE","phone":"+1 555 9999","dob":"1990-01-01"}')
check "doctors-list" 200 $(req GET /api/doctors $ADMIN)
check "doctor-create-forbidden-nurse" 403 $(req POST /api/doctors $NURSE '{"email":"x@x.com","name":"X","specialization":"A","qualification":"B","licenseNo":"LIC-9999","experienceYears":1,"consultationFee":10,"departmentId":"na"}')
check "appointments-list" 200 $(req GET /api/appointments $ADMIN)
check "appointments-patient-scoped" 200 $(req GET /api/appointments $PATIENT)
check "medical-records-list" 200 $(req GET /api/medical-records $DOCTOR)
check "prescriptions-list" 200 $(req GET /api/prescriptions $PHARM)
check "medicines-list" 200 $(req GET /api/medicines $ADMIN)
check "lab-tests-list" 200 $(req GET /api/lab-tests $LAB)
check "invoices-list" 200 $(req GET /api/invoices $RECEPTION)
check "payments-list" 200 $(req GET /api/payments $ADMIN)
check "wards-list" 200 $(req GET /api/wards $NURSE)
check "beds-list" 200 $(req GET /api/beds $ADMIN)
check "admissions-list" 200 $(req GET /api/admissions $ADMIN)
check "staff-list" 200 $(req GET /api/staff $ADMIN)
check "staff-forbidden-patient" 403 $(req GET /api/staff $PATIENT)
check "users-list" 200 $(req GET /api/users $ADMIN)
check "users-forbidden-doctor" 403 $(req GET /api/users $DOCTOR)
check "departments-list" 200 $(req GET /api/departments $ADMIN)
check "notifications-list" 200 $(req GET /api/notifications $PATIENT)
check "audit-list" 200 $(req GET /api/audit-logs $ADMIN)
check "audit-forbidden-doctor" 403 $(req GET /api/audit-logs $DOCTOR)
check "dashboard-stats" 200 $(req GET /api/dashboard/statistics $ADMIN)
check "dashboard-stats-patient-scope" 200 $(req GET /api/dashboard/statistics $PATIENT)
check "dashboard-revenue-forbidden-nurse" 403 $(req GET /api/dashboard/revenue $NURSE)
check "dashboard-appointments" 200 $(req GET /api/dashboard/appointments $ADMIN)
check "export-csv" 200 $(req GET "/api/export?type=patients" $ADMIN)
check "openapi" 200 $(curl -s -o /dev/null -w "%{http_code}" $BASE/api/openapi.json)

# --- Workflow: book appointment as patient ---
DOCID=$(curl -s "$BASE/api/doctors?pageSize=1" -H "Authorization: Bearer $PATIENT" | python3 -c "import sys,json;print(json.load(sys.stdin)['data'][0]['id'])")
NEWAPT=$(curl -s $BASE/api/appointments -X POST -H "Authorization: Bearer $PATIENT" -H 'Content-Type: application/json' -d "{\"doctorId\":\"$DOCID\",\"scheduledAt\":\"2026-11-15T10:00:00.000Z\",\"reason\":\"Test booking\"}")
APTCODE=$(echo $NEWAPT | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['success'])")
check "patient-books-appointment" True "$APTCODE"

# --- Validation errors ---
check "validation-422" 422 $(req POST /api/patients $ADMIN '{"firstName":"","lastName":""}')
check "login-rate-limit-ok" 401 $(curl -s -o /dev/null -w "%{http_code}" $BASE/api/auth/login -X POST -H 'Content-Type: application/json' -d '{"email":"nobody@x.com","password":"nope12AA"}')

echo ""
echo "RESULTS: $PASS passed, $FAIL failed"
