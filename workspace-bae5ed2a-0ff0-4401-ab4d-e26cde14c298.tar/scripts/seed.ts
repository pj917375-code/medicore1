/**
 * MediCore HMS — Database seed script (demo environment)
 * Run: bun run scripts/seed.ts
 */
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const db = new PrismaClient()

const DAY = 24 * 60 * 60 * 1000
const now = new Date()
const daysFromNow = (d: number, hour = 10, min = 0) => {
  const t = new Date(now.getTime() + d * DAY)
  t.setHours(hour, min, 0, 0)
  return t
}
const code = (prefix: string, n: number) => `${prefix}-${String(n).padStart(6, '0')}`

let seq = 100000
const nextCode = (prefix: string) => code(prefix, ++seq)

async function main() {
  console.log('Clearing existing data...')
  await db.auditLog.deleteMany()
  await db.notification.deleteMany()
  await db.passwordResetToken.deleteMany()
  await db.staffAttendance.deleteMany()
  await db.staff.deleteMany()
  await db.medicalDocument.deleteMany()
  await db.payment.deleteMany()
  await db.invoice.deleteMany()
  await db.labResult.deleteMany()
  await db.labTest.deleteMany()
  await db.prescriptionItem.deleteMany()
  await db.prescription.deleteMany()
  await db.medicalRecord.deleteMany()
  await db.appointment.deleteMany()
  await db.admission.deleteMany()
  await db.bed.deleteMany()
  await db.ward.deleteMany()
  await db.medicine.deleteMany()
  await db.doctor.deleteMany()
  await db.patient.deleteMany()
  await db.department.deleteMany()
  await db.user.deleteMany()

  const password = await bcrypt.hash('Demo@1234', 10)

  const mkUser = (email: string, name: string, role: string, phone: string, avatarColor: string) =>
    db.user.create({ data: { email, name, role, phone, avatarColor, passwordHash: password } })

  console.log('Creating users & departments...')
  const admin = await mkUser('admin@medicore.com', 'Alexandra Reed', 'ADMIN', '+1 555-0100', '#0f172a')
  await mkUser('super@medicore.com', 'Victor Hale', 'SUPER_ADMIN', '+1 555-0101', '#1e293b')
  await mkUser('nurse@medicore.com', 'Grace Bennett', 'NURSE', '+1 555-0102', '#0d9488')
  await mkUser('reception@medicore.com', 'Sofia Martinez', 'RECEPTIONIST', '+1 555-0103', '#7c3aed')
  await mkUser('pharmacist@medicore.com', 'Daniel Cho', 'PHARMACIST', '+1 555-0104', '#b45309')
  await mkUser('lab@medicore.com', 'Priya Nair', 'LAB_TECHNICIAN', '+1 555-0105', '#0369a1')

  const departments: any[] = []
  const deptData = [
    { name: 'Cardiology', description: 'Heart and vascular care', location: 'Building A, Floor 2' },
    { name: 'General Medicine', description: 'Primary and internal medicine', location: 'Building A, Floor 1' },
    { name: 'Pediatrics', description: 'Child healthcare', location: 'Building B, Floor 1' },
    { name: 'Orthopedics', description: 'Bone and joint care', location: 'Building B, Floor 2' },
    { name: 'Neurology', description: 'Brain and nervous system', location: 'Building C, Floor 1' },
    { name: 'Dermatology', description: 'Skin care', location: 'Building C, Floor 2' },
  ]
  for (const d of deptData) departments.push(await db.department.create({ data: d }))

  console.log('Creating doctors...')
  const doctorsData = [
    ['doctor@medicore.com', 'Evelyn Carter', 'Cardiology', 'MD, FACC', 14, 150, 0],
    ['james@medicore.com', 'James Okafor', 'General Medicine', 'MBBS, MRCGP', 9, 80, 1],
    ['mei@medicore.com', 'Mei Tanaka', 'Pediatrics', 'MD, FAAP', 11, 95, 2],
    ['robert@medicore.com', 'Robert Hayes', 'Orthopedics', 'MS Ortho', 17, 130, 3],
    ['lisa@medicore.com', 'Lisa Andersson', 'Neurology', 'MD, PhD', 12, 160, 4],
    ['ahmed@medicore.com', 'Ahmed Khan', 'Dermatology', 'MD Derm', 7, 90, 5],
    ['sofia.doc@medicore.com', 'Sofia Rossi', 'General Medicine', 'MBBS', 6, 75, 1],
  ]
  const doctors: any[] = []
  let docSeq = 0
  for (const [email, name, spec, qual, exp, fee, deptIdx] of doctorsData as any[]) {
    const u = await mkUser(email, name, 'DOCTOR', `+1 555-02${String(docSeq).padStart(2, '0')}`, '#0e7490')
    const d = await db.doctor.create({
      data: {
        userId: u.id, code: `D-${String(1001 + docSeq)}`,
        specialization: spec, qualification: qual,
        licenseNo: `LIC-${1000 + docSeq}`, experienceYears: exp,
        consultationFee: fee, departmentId: departments[deptIdx].id,
        availability: ['Mon,Tue,Wed,Thu,Fri', 'Mon,Wed,Fri', 'Tue,Thu,Sat', 'Mon,Tue,Thu,Fri'][docSeq % 4],
        shiftTime: docSeq % 2 === 0 ? '09:00-17:00' : '11:00-19:00',
        rating: 4.2 + (docSeq % 5) * 0.15,
      },
    })
    doctors.push(d)
    docSeq++
  }

  console.log('Creating patients...')
  const patientsData = [
    ['patient@medicore.com', 'John', 'Murray', 'MALE', 'A+', '1985-03-22', 'Hypertension', 'Penicillin'],
    [null, 'Emma', 'Sullivan', 'FEMALE', 'O+', '1992-07-14', 'Asthma', null],
    [null, 'Michael', 'Chen', 'MALE', 'B+', '1978-11-02', 'Type 2 Diabetes', 'Sulfa drugs'],
    [null, 'Olivia', 'Brown', 'FEMALE', 'AB+', '2001-01-30', null, 'Latex'],
    [null, 'David', 'Kimani', 'MALE', 'O-', '1969-09-12', 'Arthritis', null],
    [null, 'Sophia', 'Garcia', 'FEMALE', 'A-', '1995-05-18', 'Migraine', null],
    [null, 'William', 'Novak', 'MALE', 'B-', '1958-02-25', 'COPD', 'Aspirin'],
    [null, 'Ava', 'Thompson', 'FEMALE', 'O+', '1988-12-08', null, null],
    [null, 'Ethan', 'Walker', 'MALE', 'A+', '2010-06-21', null, 'Peanuts'],
    [null, 'Isabella', 'Fischer', 'FEMALE', 'AB-', '1974-04-03', 'Hypothyroidism', null],
    [null, 'Noah', 'Silva', 'MALE', 'O+', '1999-08-17', null, null],
    [null, 'Mia', 'Laurent', 'FEMALE', 'B+', '1983-10-11', 'Anemia', 'Iodine'],
  ]
  const patients: any[] = []
  let pSeq = 0
  for (const [email, fn, ln, gender, bg, dob, chronic, allergy] of patientsData as any[]) {
    let userId: string | null = null
    if (email) {
      const u = await mkUser(email, `${fn} ${ln}`, 'PATIENT', `+1 555-03${String(pSeq).padStart(2, '0')}`, '#0d9488')
      userId = u.id
    }
    const p = await db.patient.create({
      data: {
        userId, firstName: fn, lastName: ln, gender, bloodGroup: bg,
        dob: new Date(dob), code: `P-${String(pSeq + 1).padStart(6, '0')}`,
        phone: `+1 555-03${String(pSeq).padStart(2, '0')}`,
        email: email || `${fn.toLowerCase()}.${ln.toLowerCase()}@example.com`,
        address: `${100 + pSeq} ${['Maple St', 'Oak Ave', 'Cedar Rd', 'Elm Dr'][pSeq % 4]}, Springfield`,
        emergencyContactName: ['Sarah Murray', 'Tom Sullivan', 'Wei Chen', 'Anna Brown'][pSeq % 4],
        emergencyContactPhone: `+1 555-04${String(pSeq).padStart(2, '0')}`,
        allergies: allergy, chronicConditions: chronic,
        insuranceProvider: pSeq % 3 === 0 ? 'BlueShield Health' : pSeq % 3 === 1 ? 'MediCare Plus' : null,
        insuranceNumber: pSeq % 3 === 2 ? null : `INS-${5000 + pSeq}`,
      },
    })
    patients.push(p)
    pSeq++
  }

  console.log('Creating medicines...')
  const medData = [
    ['Paracetamol 500mg', 'Analgesic', 'PharmaCorp', 3.5, 480, 100, 200],
    ['Amoxicillin 250mg', 'Antibiotic', 'BioMed Labs', 8.0, 62, 60, 260],
    ['Ibuprofen 400mg', 'Analgesic', 'PharmaCorp', 4.25, 350, 80, 190],
    ['Metformin 850mg', 'Antidiabetic', 'GlucoHealth', 6.5, 45, 50, 120],
    ['Lisinopril 10mg', 'Antihypertensive', 'CardioPure', 7.0, 28, 40, 300],
    ['Salbutamol Inhaler', 'Bronchodilator', 'RespiCare', 18.0, 15, 15, 420],
    ['Omeprazole 20mg', 'Antacid', 'GastroWell', 5.5, 210, 50, 210],
    ['Atorvastatin 20mg', 'Statin', 'CardioPure', 9.75, 88, 40, 150],
    ['Cetirizine 10mg', 'Antihistamine', 'AllerFree', 3.0, 260, 60, 95],
    ['Insulin Glargine', 'Antidiabetic', 'GlucoHealth', 42.0, 22, 10, 75],
    ['Ceftriaxone 1g Injection', 'Antibiotic', 'BioMed Labs', 14.5, 35, 20, 60],
    ['Vitamin D3 60000IU', 'Supplement', 'NutriLife', 6.0, 140, 30, 45],
    ['Amlodipine 5mg', 'Antihypertensive', 'CardioPure', 5.25, 18, 25, 240],
    ['Diazepam 5mg', 'Sedative', 'NeuroCalm', 7.5, 40, 15, 180],
    ['ORS Sachet', 'Rehydration', 'NutriLife', 1.5, 500, 120, 400],
    ['Prednisolone 5mg', 'Corticosteroid', 'PharmaCorp', 4.75, 75, 30, 330],
  ]
  const medicines: any[] = []
  let mSeq = 0
  for (const [name, category, manufacturer, price, qty, reorder, expiryInDays] of medData as any[]) {
    const m = await db.medicine.create({
      data: {
        name, category, manufacturer, unitPrice: price, stockQty: qty,
        reorderLevel: reorder, unit: ['strip', 'bottle', 'box', 'vial'][mSeq % 4],
        batchNo: `BATCH-${2400 + mSeq}`, expiryDate: daysFromNow(expiryInDays),
      },
    })
    medicines.push(m)
    mSeq++
  }

  console.log('Creating wards & beds...')
  const wardData = [
    ['General Ward', 'GENERAL', '1'], ['Intensive Care Unit', 'ICU', '2'],
    ['Maternity Ward', 'MATERNITY', '2'], ['Surgical Ward', 'SURGICAL', '3'],
    ['Pediatric Ward', 'PEDIATRIC', '1'],
  ]
  const wards: any[] = []
  for (const [name, type, floor] of wardData as any[]) {
    wards.push(await db.ward.create({ data: { name, type, floor } }))
  }
  const wardSpec = [[100, 6], [320, 4], [180, 4], [220, 5], [120, 4]]
  const beds: any[] = []
  let bSeq = 101
  for (let wi = 0; wi < wards.length; wi++) {
    const [rate, count] = wardSpec[wi]
    for (let bi = 1; bi <= count; bi++) {
      beds.push(await db.bed.create({
        data: {
          wardId: wards[wi].id,
          bedNumber: `${wards[wi].name.split(' ')[0].slice(0, 3).toUpperCase()}-${bSeq++}`,
          dailyRate: rate,
        },
      }))
    }
  }

  console.log('Creating appointments...')
  const apptStatuses = ['COMPLETED', 'COMPLETED', 'COMPLETED', 'CANCELLED', 'NO_SHOW']
  const reasons = [
    'Chest pain evaluation', 'Routine check-up', 'Fever and sore throat', 'Follow-up visit',
    'Persistent headache', 'Joint pain consultation', 'Skin rash examination',
    'Diabetes management', 'Blood pressure review', 'Abdominal pain', 'Annual physical exam',
    'Child immunization', 'Back pain assessment', 'Dizziness and fatigue',
  ]
  const appointments: any[] = []
  let aSeq = 0
  for (let day = -60; day <= 7; day++) {
    const perDay = day < 0 ? 1 + (((day * 7919) % 3 + 3) % 3) : 1 + ((day * 31) % 3)
    for (let k = 0; k < perDay; k++) {
      const doc = doctors[(aSeq * 7 + k) % doctors.length]
      const pat = patients[(aSeq * 5 + k * 3) % patients.length]
      const status = day < 0 ? apptStatuses[(aSeq + k) % 5] : day === 0 ? (k === 0 ? 'CONFIRMED' : 'SCHEDULED') : 'SCHEDULED'
      const apt = await db.appointment.create({
        data: {
          code: `APT-${String(aSeq + 1).padStart(6, '0')}`, patientId: pat.id, doctorId: doc.id,
          departmentId: doc.departmentId,
          scheduledAt: daysFromNow(day, 9 + ((k * 3) % 8), (k % 2) * 30),
          durationMinutes: 30, reason: reasons[aSeq % reasons.length],
          status, createdBy: admin.name,
        },
      })
      appointments.push(apt)
      aSeq++
    }
  }

  console.log('Creating medical records, prescriptions, lab tests...')
  const completedAppts = appointments.filter((a) => a.status === 'COMPLETED')
  const diagnoses = [
    ['Essential hypertension', 'Continue Lisinopril 10mg daily', 'Stable; monitor BP'],
    ['Acute upper respiratory infection', 'Rest, hydration, symptomatic care', 'Self-limiting'],
    ['Type 2 Diabetes Mellitus', 'Metformin 850mg twice daily', 'HbA1c in 3 months'],
    ['Tension headache', 'Analgesia, stress management', 'Revisit if persistent'],
    ['Osteoarthritis of knee', 'Physiotherapy, NSAIDs', 'Improved mobility'],
    ['Allergic rhinitis', 'Cetirizine 10mg at night', 'Avoid allergens'],
    ['Gastroesophageal reflux', 'Omeprazole 20mg before breakfast', 'Diet modification'],
    ['Pediatric viral fever', 'Paracetamol syrup as per weight', 'Guarded; improving'],
  ]
  let rxSeq = 0, labSeq = 0
  for (let i = 0; i < completedAppts.length; i++) {
    const appt = completedAppts[i]
    const [dx, tx, note] = diagnoses[i % diagnoses.length]
    const rec = await db.medicalRecord.create({
      data: {
        patientId: appt.patientId, doctorId: appt.doctorId, appointmentId: appt.id,
        visitType: ['CONSULTATION', 'CONSULTATION', 'FOLLOW_UP', 'EMERGENCY'][i % 4],
        symptoms: ['Chest discomfort on exertion', 'Fever 3 days, sore throat', 'Increased thirst and urination', 'Headache, blurred vision', 'Knee pain on stairs', 'Sneezing, itchy eyes', 'Heartburn after meals', 'High fever in child'][i % 8],
        diagnosis: dx, treatmentPlan: tx, clinicalNotes: note,
        bloodPressure: `${110 + (i % 5) * 10}/${70 + (i % 3) * 5}`,
        heartRate: 60 + (i % 30), temperature: +(36.2 + (i % 18) / 10).toFixed(1),
        weight: 45 + (i % 50), followUpDate: i % 3 === 0 ? daysFromNow(7 + (i % 20)) : null,
        createdAt: appt.scheduledAt,
      },
    })
    if (i % 2 === 0) {
      const rx = await db.prescription.create({
        data: {
          code: `RX-${String(++rxSeq).padStart(6, '0')}`, patientId: appt.patientId, doctorId: appt.doctorId,
          medicalRecordId: rec.id,
          status: i % 4 === 0 ? 'DISPENSED' : i % 10 === 6 ? 'CANCELLED' : 'PENDING',
          notes: 'Take after meals unless directed otherwise.',
          createdAt: appt.scheduledAt,
        },
      })
      const medChoices = [medicines[i % medicines.length], medicines[(i * 3 + 1) % medicines.length]]
      for (let j = 0; j < medChoices.length; j++) {
        await db.prescriptionItem.create({
          data: {
            prescriptionId: rx.id, medicineId: medChoices[j].id, medicineName: medChoices[j].name,
            dosage: ['1 tablet', '2 tablets', '1 capsule', '5ml syrup'][j % 4],
            frequency: ['Once daily', 'Twice daily', 'Three times daily', 'Every 8 hours'][j % 4],
            duration: ['5 days', '7 days', '14 days', '1 month'][j % 4],
            instructions: j === 0 ? 'After food' : 'Before food',
            dispensedQty: rx.status === 'DISPENSED' ? 10 : 0,
          },
        })
      }
    }
    if (i % 3 === 0) {
      const statusCycle = ['REVIEWED', 'COMPLETED', 'PROCESSING', 'SAMPLE_COLLECTED', 'REQUESTED']
      const lt = await db.labTest.create({
        data: {
          code: `LAB-${String(++labSeq).padStart(6, '0')}`, patientId: appt.patientId, doctorId: appt.doctorId,
          testName: ['Complete Blood Count', 'Lipid Panel', 'HbA1c', 'Liver Function Test', 'Thyroid Profile', 'Urinalysis', 'Chest X-Ray', 'Blood Glucose Fasting'][i % 8],
          category: ['HEMATOLOGY', 'BIOCHEMISTRY', 'BIOCHEMISTRY', 'BIOCHEMISTRY', 'BIOCHEMISTRY', 'MICROBIOLOGY', 'RADIOLOGY', 'BIOCHEMISTRY'][i % 8],
          sampleType: ['Venous blood', 'Venous blood', 'Venous blood', 'Venous blood', 'Venous blood', 'Urine', 'Imaging', 'Venous blood'][i % 8],
          priority: i % 7 === 0 ? 'URGENT' : 'ROUTINE',
          status: statusCycle[i % 5], requestedAt: appt.scheduledAt,
        },
      })
      if (['COMPLETED', 'REVIEWED'].includes(lt.status)) {
        const reviewed = lt.status === 'REVIEWED'
        await db.labResult.create({
          data: {
            labTestId: lt.id,
            resultSummary: 'All parameters within normal limits unless flagged. No acute abnormalities detected.',
            values: JSON.stringify([
              { parameter: 'Hemoglobin', value: (12 + (i % 4)).toFixed(1), unit: 'g/dL', referenceRange: '12-16', flag: 'NORMAL' },
              { parameter: 'WBC', value: (5 + (i % 4)).toFixed(1), unit: '10^3/uL', referenceRange: '4-11', flag: 'NORMAL' },
              { parameter: 'Platelets', value: String(200 + (i % 100)), unit: '10^3/uL', referenceRange: '150-450', flag: 'NORMAL' },
            ]),
            technologist: 'Priya Nair',
            completedAt: new Date(appt.scheduledAt.getTime() + 2 * 60 * 60 * 1000),
            reviewedBy: reviewed ? 'Evelyn Carter' : null,
            reviewedAt: reviewed ? new Date(appt.scheduledAt.getTime() + 5 * 60 * 60 * 1000) : null,
          },
        })
      }
    }
  }

  console.log('Creating invoices & payments (revenue history)...')
  let invSeq = 0
  const paidStatuses = ['PAID', 'PAID', 'PAID', 'PARTIALLY_PAID', 'UNPAID']
  for (let i = 0; i < appointments.length; i++) {
    const appt = appointments[i]
    if (appt.status === 'CANCELLED') continue
    const doc = doctors.find((d) => d.id === appt.doctorId)!
    invSeq++
    const consultation = doc.consultationFee
    const labCharge = i % 3 === 0 ? 45 + (i % 5) * 15 : 0
    const pharmacyCharge = i % 2 === 0 ? 12 + (i % 9) * 6 : 0
    const subtotal = consultation + labCharge + pharmacyCharge
    const tax = +(subtotal * 0.05).toFixed(2)
    const total = +(subtotal + tax).toFixed(2)
    const st = appt.status === 'COMPLETED' ? paidStatuses[i % 5] : 'UNPAID'
    const amountPaid = st === 'PAID' ? total : st === 'PARTIALLY_PAID' ? +(total * 0.5).toFixed(2) : 0
    const inv = await db.invoice.create({
      data: {
        invoiceNo: `INV-${String(invSeq).padStart(6, '0')}`, patientId: appt.patientId,
        items: JSON.stringify([
          { description: `Consultation — ${doc.specialization}`, type: 'CONSULTATION', quantity: 1, unitPrice: consultation, amount: consultation },
          ...(labCharge ? [{ description: 'Laboratory tests', type: 'LABORATORY', quantity: 1, unitPrice: labCharge, amount: labCharge }] : []),
          ...(pharmacyCharge ? [{ description: 'Pharmacy supplies', type: 'PHARMACY', quantity: 1, unitPrice: pharmacyCharge, amount: pharmacyCharge }] : []),
        ]),
        subtotal, tax, total, amountPaid, status: st,
        dueDate: new Date(appt.scheduledAt.getTime() + 14 * DAY),
        createdAt: appt.scheduledAt,
      },
    })
    if (amountPaid > 0) {
      await db.payment.create({
        data: {
          invoiceId: inv.id, amount: amountPaid,
          method: ['CASH', 'CARD', 'BANK_TRANSFER', 'INSURANCE', 'MOBILE_MONEY'][i % 5],
          reference: `TXN-${90000 + i}`, receivedBy: 'Sofia Martinez', paidAt: appt.scheduledAt,
        },
      })
    }
  }

  // Historical revenue: 12 months of paid invoices so analytics charts are full
  console.log('Creating 12-month revenue history...')
  let histSeq = 9000
  for (let m = 12; m >= 1; m--) {
    const invoicesThisMonth = 14 + ((m * 7) % 6)
    for (let k = 0; k < invoicesThisMonth; k++) {
      const doc = doctors[(m * 3 + k) % doctors.length]
      const pat = patients[(m * 5 + k * 2) % patients.length]
      const day = new Date(now.getFullYear(), now.getMonth() - m, 2 + ((k * 2) % 26), 10)
      const consultation = doc.consultationFee
      const labCharge = k % 3 === 0 ? 40 + ((k * 13) % 120) : 0
      const pharmacyCharge = k % 2 === 0 ? 10 + ((k * 7) % 80) : 0
      const subtotal = consultation + labCharge + pharmacyCharge
      const tax = +(subtotal * 0.05).toFixed(2)
      const total = +(subtotal + tax).toFixed(2)
      const st = k % 9 === 4 ? 'PARTIALLY_PAID' : k % 9 === 7 ? 'UNPAID' : 'PAID'
      const amountPaid = st === 'PAID' ? total : st === 'PARTIALLY_PAID' ? +(total * 0.5).toFixed(2) : 0
      histSeq++
      const inv = await db.invoice.create({
        data: {
          invoiceNo: `INV-${String(histSeq).padStart(6, '0')}`, patientId: pat.id,
          items: JSON.stringify([
            { description: `Consultation — ${doc.specialization}`, type: 'CONSULTATION', quantity: 1, unitPrice: consultation, amount: consultation },
            ...(labCharge ? [{ description: 'Laboratory tests', type: 'LABORATORY', quantity: 1, unitPrice: labCharge, amount: labCharge }] : []),
            ...(pharmacyCharge ? [{ description: 'Pharmacy supplies', type: 'PHARMACY', quantity: 1, unitPrice: pharmacyCharge, amount: pharmacyCharge }] : []),
          ]),
          subtotal, tax, total, amountPaid, status: st,
          dueDate: new Date(day.getTime() + 14 * DAY),
          createdAt: day,
        },
      })
      if (amountPaid > 0) {
        await db.payment.create({
          data: {
            invoiceId: inv.id, amount: amountPaid,
            method: ['CASH', 'CARD', 'BANK_TRANSFER', 'INSURANCE', 'MOBILE_MONEY'][k % 5],
            reference: `TXN-8${5000 + histSeq}`, receivedBy: 'Sofia Martinez', paidAt: new Date(day.getTime() + DAY),
          },
        })
      }
    }
  }

  console.log('Creating admissions...')
  const occupiedBeds = beds.slice(0, 9)
  for (let i = 0; i < occupiedBeds.length; i++) {
    const discharged = i >= 6
    await db.admission.create({
      data: {
        patientId: patients[i + 1].id, bedId: occupiedBeds[i].id,
        doctorId: doctors[i % doctors.length].id,
        reason: ['Post-operative care', 'Severe hypertensive episode', 'Pneumonia management', 'Uncontrolled diabetes', 'Fracture immobilization', 'Observation after ER visit', 'Childhood asthma exacerbation', 'Migraine admission', 'Cardiac monitoring'][i],
        status: discharged ? 'DISCHARGED' : 'ADMITTED',
        admittedAt: daysFromNow(discharged ? -(10 + i) : -(1 + i * 2), 9),
        dischargedAt: discharged ? daysFromNow(-(2 + i), 11) : null,
        notes: discharged ? 'Recovered; follow-up scheduled.' : 'Responding well to treatment.',
      },
    })
    await db.bed.update({ where: { id: occupiedBeds[i].id }, data: { status: discharged ? 'AVAILABLE' : 'OCCUPIED' } })
  }
  await db.bed.update({ where: { id: beds[beds.length - 1].id }, data: { status: 'MAINTENANCE' } })

  console.log('Creating staff...')
  const staffData = [
    ['nurse@medicore.com', 'Grace Bennett', 'N-2001', 'Senior Nurse', 'General Medicine', 'MORNING'],
    ['reception@medicore.com', 'Sofia Martinez', 'R-3001', 'Front Desk Lead', 'Administration', 'MORNING'],
    ['pharmacist@medicore.com', 'Daniel Cho', 'PH-4001', 'Chief Pharmacist', 'Pharmacy', 'EVENING'],
    ['lab@medicore.com', 'Priya Nair', 'LT-5001', 'Senior Lab Technologist', 'Laboratory', 'MORNING'],
  ]
  for (const [email, name, empCode, title, dept, shift] of staffData as any[]) {
    const u = await db.user.findUnique({ where: { email } })
    const s = await db.staff.create({
      data: { userId: u!.id, employeeCode: empCode, title, department: dept, shift, joinedAt: daysFromNow(-500 - Math.random() * 400) },
    })
    for (let d = 1; d <= 7; d++) {
      await db.staffAttendance.create({
        data: {
          staffId: s.id, date: daysFromNow(-d).toISOString().slice(0, 10),
          status: d % 6 === 0 ? 'LEAVE' : d % 7 === 0 ? 'ABSENT' : 'PRESENT',
          checkIn: '08:55', checkOut: '17:10',
        },
      })
    }
  }

  console.log('Creating notifications & audit logs...')
  await db.notification.createMany({
    data: [
      { targetRoles: 'ADMIN,RECEPTIONIST', title: 'New patient registered', message: 'Mia Laurent has been registered as a new patient.', type: 'PATIENT', createdAt: new Date(now.getTime() - 30 * 60000) },
      { targetRoles: 'DOCTOR', title: 'Appointments today', message: 'You have confirmed appointments scheduled today.', type: 'APPOINTMENT', createdAt: new Date(now.getTime() - 2 * 60 * 60000) },
      { targetRoles: 'PHARMACIST', title: 'Low stock alert', message: 'Amlodipine 5mg has fallen below the reorder level (18/25).', type: 'PRESCRIPTION', createdAt: new Date(now.getTime() - 45 * 60000) },
      { targetRoles: 'LAB_TECHNICIAN', title: 'New lab request', message: 'Urgent lab request requires sample collection.', type: 'LAB', createdAt: new Date(now.getTime() - 15 * 60000) },
      { targetRoles: 'ADMIN', title: 'Payment received', message: 'Invoice payment of $320.00 recorded via card.', type: 'PAYMENT', createdAt: new Date(now.getTime() - 3 * 60 * 60000) },
    ],
  })
  await db.auditLog.createMany({
    data: [
      { userId: admin.id, userName: admin.name, action: 'LOGIN', entity: 'Auth', details: 'Signed in to admin dashboard', ip: '10.0.0.2' },
      { userId: admin.id, userName: admin.name, action: 'CREATE', entity: 'Patient', entityId: patients[11].id, details: 'Registered patient Mia Laurent', ip: '10.0.0.2' },
      { userId: doctors[0].userId, userName: 'Evelyn Carter', action: 'CREATE', entity: 'MedicalRecord', details: 'Added consultation record', ip: '10.0.0.15' },
      { userId: admin.id, userName: admin.name, action: 'UPDATE', entity: 'Bed', details: 'Marked bed PED-113 under maintenance', ip: '10.0.0.2' },
    ],
  })

  console.log('Done seeding!')
  console.log(JSON.stringify({
    users: await db.user.count(), patients: await db.patient.count(),
    doctors: await db.doctor.count(), appointments: await db.appointment.count(),
    medicalRecords: await db.medicalRecord.count(), prescriptions: await db.prescription.count(),
    medicines: await db.medicine.count(), labTests: await db.labTest.count(),
    invoices: await db.invoice.count(), payments: await db.payment.count(),
    beds: await db.bed.count(), admissions: await db.admission.count(),
  }, null, 2))
}

main().catch((e) => { console.error(e); process.exit(1) }).finally(() => db.$disconnect())
